<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, specimAddSpecID.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/

session_start(); 
$testStg=md5('salt'.microtime());
$_SESSION['testStore']=$testStg;
include_once '../configUser.inc';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Specimen Info</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li ><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSpecimen.php">Update</a></li> 
<li><a href="consultSpecimen.php">Consult</a></li>
<li><a href="helpSpecimen.php">Help</a></li>  
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 

</ul> 
</div> 
<style type="text/css"><!--
#other{
    display: none;
}
--></style>
<script type="text/javascript"><!--
function checkOther(select){
    if( select[select.selectedIndex].value=="other" ){
        document.getElementById("other").style.display = "inline";
    }else{
        document.getElementById("other").style.display = "none";
    }
}
//--></script>

<?php 
$string = $_GET['id'];
$error = array();
if (!empty($string)){
    $data = trim($string);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $Specimen_UID_req = htmlspecialchars($data);
 
 if (empty($error)) { 

include_once '../config.inc'; //data for the connection
$db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//Using the correct database
 $db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));
$query1 = 'SELECT COUNT(Specimen_UID_req) AS Uid FROM HPMB_SpecimenInfo WHERE Specimen_UID_req="' . $data . '" '; 

 $result1 = mysql_query($query1,$db) or die(mysql_error($db));
  if (!$result1)
  {
    echo '<div id="error">' . 'Error no such record exist from database.';
    exit();
  }
    $row = mysql_fetch_array($result1);
    $total =mysql_result($result1, 0, 0);
if ($total == 0)
{
echo '<div id="error">' . 'Error no such record exist from database.';
exit();
}

$query2 = 'SELECT * FROM HPMB_SpecimenInfo WHERE Specimen_UID_req = "' . $data . '" AND track_spec = "'
 . $total .'"'; 

 $result2 = mysql_query($query2,$db) or die(mysql_error());
  if (!$result2)
  {
    echo 'Error selecting records from database.';
    exit();
  }
   
    $row2 = mysql_fetch_array($result2);
    $Specimen_Alias_req = "$row2[Specimen_Alias_req]"; 
     if ($row2['Date_Acquired_req'] == '0000-00-00' ) {$Date_Acquired_req='00-00-0000'; }
    else {   $Date_Acquired_req = change_date_format( $row2['Date_Acquired_req']);}
    $Acquired_By_req = "$row2[Acquired_By_req]";
    $Storage_Location_req = "$row2[Storage_Location_req]";
    $Source_req           = "$row2[Source_req]";
    $Specimen_Type_req    = "$row2[Specimen_Type_req]";
    $Host_ID_req          = "$row2[Host_ID_req]";
    $Host_Organism_req    = "$row2[Host_Organism_req]";
    $Host_Ploidy          = "$row2[Host_Ploidy]";
    $Host_Gender          = "$row2[Host_Gender]";
    $Host_Age             = "$row2[Host_Age]";
    $Host_Ethnicity       = "$row2[Host_Ethnicity]";
    $Tissue_Sampled_req   = "$row2[Tissue_Sampled_req]";
    $Diagnostic_Screen    = "$row2[Diagnostic_Screen]";
    $Pathogen_Type        = "$row2[Pathogen_Type]";
    $Pathogen_Dose        = "$row2[Pathogen_Dose]";
    $Pathogen_Delivery    = "$row2[Pathogen_Delivery]";
    $Specimen_Collection_Timing = "$row2[Specimen_Collection_Timing]";
    $Experimentalists_notes_upload = "$row2[Experimentalists_notes_upload]";
    $fileuploaded         =  "$row2[fileuploaded]";
    $filetype             = "$row2[filetype]";
    $Remarks              = "$row2[Remarks]";
 


mysql_close($db);


}//empty errors array
} //else no empty UID
?>

<title> Create Specimen </title>
</head>

<body>
       <BR>&nbsp;<BR>
         <form id="form2" action="createSpecim.php" method="post" enctype="multipart/form-data">     

             

              <h3><span> Create Specimen</span></h3>

         

                <fieldset><legend>Create Specimen</legend>

                   <p class="first">
                        <label for="Specimen_Alias_req" >Specimen Alias </label>
                        <input type="text" size="100" maxlength="100" name="Specimen_Alias_req" id="Specimen_Alias_req" value= <?php $one = substr($Specimen_Alias_req, 0, 100);  echo "'$one'";?> />
                   </p>

                  <p>
                        <label for="Acquired_By_req">Acquired By (*). (*) REQUIRED</label>
                        <input type="text" size="100" maxlength="100" name="Acquired_By_req" id="Acquired_By_req" value= <?php  $three = substr($Acquired_By_req,0,100); echo "'$three'";?> />
                   </p>  

		   <p>
                       <select name=Specimen_Type_req onchange="checkOther(this)">
                       <option VALUE=<?php  $four = substr($Specimen_Type_req,0,100); echo "'$four'"; ?>>Specimen Type (*): <?php echo $four; ?> 
                       <option value="other">Other</option>
                       </select>
                       <input id="other" type="text" size="100" maxlength="100" name="other_type" />
                   </p>  

		   <p>

                        <label for="Source_req">Source (*)</label>

                        <input type="text" size="100" maxlength="100" name="Source_req" id="Source_req" value= <?php $five= substr($Source_req,0,100) ;  echo "'$five'"; ?> />

                   </p>    


		   <p>

                        <label for="Host_ID_req">Host ID (*)</label>

                        <input type="text" size="100" maxlength="100" name="Host_ID_req" id="Host_ID_req" value= <?php $seven = substr($Host_ID_req,0,100);  echo "'$seven'";?> />

                   </p>     
		   <p>

                        <label for="Host_Organism_req">Host Species (*). Needed to generate Specimen ID</label>

                        <input type="text" size="100" maxlength="100" name="Host_Organism_req" id="Host_Organism_req" value= <?php $eight= substr($Host_Organism_req,0,100);  echo "'$eight'";?> />

                   </p>     

		   <p>

                        <label for="Tissue_Sampled_req">Tissue Sampled (*). Needed to generate Specimen ID</label>

                        <input type="text" size="100" maxlength="100" name="Tissue_Sampled_req" id="Tissue_Sampled_req" value= <?php $thirteen=substr($Tissue_Sampled_req,0,100);   echo "'$thirteen'";?> />

                   </p> 

                   <p>
                        <label for="Date_Acquired_req">Date Acquired. Format (mm-dd-yyyy)</label>

                        <input type="text" size="10" maxlength="10" name="Date_Acquired_req" id="Date_Acquired_req" value= <?php if ($Date_Acquired_req !='') echo $Date_Acquired_req ; else echo "&nbsp;"; ?> />
 		  </p>                                                                                                                                

                   <p>
                        <label for="Storage_Location_req">Storage Location </label>

                        <input type="text" size="100" maxlength="100" name="Storage_Location_req" id="Storage_Location_req" value= <?php $four=substr($Storage_Location_req,0,100);  echo "'$four'";?> />

                   </p>     

 
 
		   <p>
                        <label for="Host_Ploidy">Host Ploidy </label>

                        <input type="text" size="100" maxlength="100" name="Host_Ploidy" id="Host_Ploidy" value= <?php $nine= 
substr($Host_Ploidy,0,100);  echo "'$nine'"; ?> />

                   </p>

                   <p>
                      <select name=Host_Gender>
                       <option VALUE=<?php echo $Host_Gender;?>>Host Gender : <?php echo $Host_Gender;?>
                       <option value="male">male</option>
                       <option value="female">female</option>
                      </select>
                   </p>    
   
		   <p>
                        <label for="Host_Age">Host Age</label>
                        <input type="text" size="3" maxlength="3" name="Host_Age" id="Host_Age" value= <?php $eleven =substr($Host_Age,0,3); if ($eleven!=0) echo "'$eleven'"; else echo 0;  ?> />
                   </p>     

		   <p>

                        <label for="Host_Ethnicity">Host Ethnicity</label>
                        <input type="text" size="30" maxlength="30" name="Host_Ethnicity" id="Host_Ethnicity" value= <?php $twelve=substr($Host_Ethnicity,0,30);  echo "'$twelve'"; ?> />
                   </p>     
    
<p>
 <tr>
      <th><label for="Diagnostic_Screen">Additional Host MetaData</label></th>
      <td><textarea name="Diagnostic_Screen" id="Diagnostic_Screen"maxlength="5000"  wrap="hard" value= <?php  echo '<textarea>'.$Diagnostic_Screen.'</textarea>'; ?>  </textarea></td>
    </tr>
</p>  
  
		    <p>
                        <label for="Pathogen_Type">Pathogen Species</label>
                        <input type="text" size="100" maxlength="100" name="Pathogen_Type" id="Pathogen_Type" value= <?php $fifteen=substr($Pathogen_Type,0,100); echo "'$fifteen'"; ?> />
                   </p>     

		   <p>
                        <label for="Pathogen_Dose">Pathogen Dose/Tite</label>
                        <input type="text" size="100" maxlength="100" name="Pathogen_Dose" id="Pathogen_Dose" value= <?php $sixteen =substr($Pathogen_Dose,0,100); echo "'$sixteen'"; ?> />
                   </p>    
 
		   <p>
                        <label for="Pathogen_Delivery">Pathogen Delivery</label>
                        <input type="text" size="100" maxlength="100" name="Pathogen_Delivery" id="Pathogen_Delivery" value= <?php  $seventeen =substr($Pathogen_Delivery,0,100); echo "'$seventeen'"; ?> />
                   </p>     

		   <p>

                        <label for="Specimen_Collection_Timing">Specimen Collection Timing</label>
                        <input type="text" size="100" maxlength="100" name="Specimen_Collection_Timing" id="Specimen_Collection_Timing" value= <?php $eighteen=substr($Specimen_Collection_Timing,0,100); echo "'$eighteen'"; ?>/>
                   </p>     

<p>
 <tr>
      <th><label for="Remarks">Additional Pathogen MetaData</label></th>
      <td><textarea name="Remarks" id="Remarks" maxlength="5000"  wrap="hard" value= <?php  echo '<textarea>'.$Remarks.'</textarea>'; ?>  </textarea></td>
    </tr>
</p>

		   <p>
                        <label for="Experimentalists_notes_upload">Upload notes: </label>

                        <input type="file" accept="text/txt" name="Experimentalists_notes_upload" id="Experimentalists_notes_upload" value= <?php $twenty=substr($Experimentalists_notes_upload,0,200); echo "'$twenty'"; ?>/>
                   </p>
    

<p>
                <input type="hidden" name="Specimen_UID_req" value=<?php echo $Specimen_UID_req ;?> />   <input type="hidden" name="createdby" value=<?php echo $createdby ;?> /> <input type="hidden" name="timecreation" value=<?php echo $timecreation ;?> />  <input type="hidden" name="track_id" value=<?php echo $track_id ;?> /> <input type="hidden" name="track_spec" value=<?php echo $track_spec  ;?> />
    <input type="hidden" name="testStore" value=<?php echo $testStg ;?> />     
</p>
                       
                    <p class="submit"><button type="submit">Create Specimen</button></p>   
                          
                   <input type="hidden" name="submit" value="1"/>
                   

              </fieldset>                         
         </form>     
</div>
</body>

</html>


<?php

function change_date_format($data){

       list($year,$month,$day) = explode("-",$data);
       $newdata = $month."-".$day."-".$year;
       return $newdata;
}
?>
