<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, cons2new.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Specimen Info</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSpecimen.php">Update</a></li> 
<li><a href="consultSpecimen.php">Consult</a></li>
<li><a href="helpSpecimen.php">Help</a></li>  
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 

</ul> 
</div> 
<BR>&nbsp;<BR>

<?php 
$string = $_GET['id'];
$error = array();
if (!empty($string)){
    $data = trim($string);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $Specimen_UID_req = htmlspecialchars($data);
   
 if (empty($error)) { 

   include_once '../config.inc'; //data for the connection
   $db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

   //Using the correct database
   $db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));

   $query2 = 'SELECT * FROM HPMB_SpecimenInfo WHERE Specimen_UID_req = "' . $data . '" ORDER BY timemodified desc LIMIT 1'; 

   $result2 = mysql_query($query2,$db) or die(mysql_error());
   if (!$result2)
   {
     echo '<div id="error">' . 'Error no such record exist from database.';
     exit();
   }

     $total =mysql_num_rows($result2);
  if ($total == 0)
 {
  echo '<div id="error">' . 'Error no such record exist from database.';
  exit();
 }
 $message = "<a href=\"generateSpecimIdCsv.php?id=$Specimen_UID_req\">Spreadsheet for full Specimen history</a>";
 echo $message;

echo "<table border='1'>
<tr>
</tr>";

while($row = mysql_fetch_array($result2))
  {
  echo "<tr>";
  echo "<th>Specimen UID </th>";
  echo "<td>" . $row['Specimen_UID_req'] . "</td>";
  echo "<tr>";
  echo "<th>Specimen Alias </th>";
  echo "<td>" . $row['Specimen_Alias_req'] . "</td>";
  echo "<tr>";
  echo "<th>Date Acquired </th>";
  echo "<td>" . change_date_format( $row['Date_Acquired_req']) . "</td>";
  echo "<tr>";
  echo "<th>Acquired By </th>"; 
  echo "<td>" . $row['Acquired_By_req'] . "</td>";
  echo "<tr>";
  echo "<th>Storage Location </th>"; 
  echo "<td>" . $row['Storage_Location_req'] . "</td>";
  echo "<tr>";
  echo "<th>Source </th>";
  echo "<td>" . $row['Source_req'] . "</td>";
  echo "<tr>";
  echo "<th>Specimen Type </th>";
  echo "<td>" . $row['Specimen_Type_req'] . "</td>";
  echo "<tr>";
  echo "<th>Host ID </th>";
  echo "<td>" . $row['Host_ID_req'] . "</td>";
  echo "<tr>";
  echo "<th>Host Species </th>"; 
  echo "<td>" . $row['Host_Organism_req'] . "</td>";
  echo "<tr>";
  //echo "<th>Host Ploidy </th>";
  //echo "<td>" . $row['Host_Ploidy'] . "</td>";
  //echo "<tr>"; 
  echo "<th>Host Gender </th>";
  echo "<td>" . $row['Host_Gender'] . "</td>";
  echo "<tr>";
  echo "<th>Host Age </th>";
  echo "<td>" . $row['Host_Age'] . "</td>";
  echo "<tr>";
  echo "<th>Host Ethnicity </th>";
  echo "<td>" . $row['Host_Ethnicity'] . "</td>";
  echo "<tr>";
  echo "<th>Tissue Sampled </th>";
  echo "<td>" . $row['Tissue_Sampled_req'] . "</td>";
  echo "<tr>";
  echo "<th>Pathogen Species </th>";
  echo "<td>" . $row['Pathogen_Type'] . "</td>";
  echo "<tr>";
  echo "<th>Additional Host MetaData </th>";
  echo "<td>" . $row['Diagnostic_Screen'] . "</td>";
  echo "<tr>";
  echo "<th>Additional Pathogen Metadata </th>";
  echo "<td>" . $row['Remarks'] . "</td>";
  echo "<tr>";
  echo "<th>Experimentalist Notes</th>";
  echo "<td><a href='consNotes.php?id=" . $row['Specimen_UID_req'] ."'>". $row['Experimentalists_notes_upload'] ."</a></td>";
  echo "<tr>";
  echo "<th>Created By </th>";
  echo "<td>" . $row['createdby'] . "</td>";
  echo "<tr>";
  echo "<th>Time Creation </th>";
  echo "<td>" . $row['timecreation'] . "</td>";
  echo "<tr>";
  echo "<th>Modified By </th>";
  echo "<td>" . $row['modifiedby'] . "</td>";
  echo "<tr>";
  echo "<th>Time Modified </th>";
  echo "<td>" . $row['timemodified'] . "</td>";
  echo "<tr>";
  //echo "<th>Specimen track </th>";
  //echo "<td>" . $row['track_spec'] . "</td>";
  //echo "</tr>";
  //echo "<tr>";
  }
echo "</table>";


mysql_close($db);

}//empty errors array
} //else no empty UID

function change_date_format($data){

       list($year,$month,$day) = explode("-",$data);
       $newdata = $month."-".$day."-".$year;
       return $newdata;
}
?>


