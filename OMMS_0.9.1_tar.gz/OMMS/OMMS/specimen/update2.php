<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, update2.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Specimen Info</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li ><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSpecimen.php">Update</a></li> 
<li><a href="consultSpecimen.php">Consult</a></li>
<li><a href="helpSpecimen.php">Help</a></li>  
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<BR>&nbsp;<BR>
<BR>&nbsp;<BR>
<BR>&nbsp;<BR>

<?php
session_start();
if ($_SESSION['testStore'] != $_POST['testStore']) {
   echo '<div id="error">'. "Not allowed to duplicate the information.";
}
else
{
 $_SESSION['testStore'] = null;
include_once '../configUser.inc';

if (valid_info()) 
{ 
  
$Specimen_UID_req1 = ($_POST['Specimen_UID_req']);
$createdby1 = check_input($_POST['createdby']);
$timecreation1 = check_input($_POST['timecreation']);
$track_id1 = $_POST['track_id'];
$track_spec1 = $_POST['track_spec'];
$Acquired_By_req1 = check_input($_POST['Acquired_By_req']);
$Source_req1 = check_input($_POST['Source_req']);

$Specimen_Type_req1 = check_input($_POST['Specimen_Type_req']);
if ($Specimen_Type_req1=="other")
 {
  $Specimen_Type_req1=check_input($_POST['other_type']);
  }

$Host_ID_req1 = check_input($_POST['Host_ID_req']);

$Host_Organism_req1 = check_input($_POST['Host_Organism_req']);

$Tissue_Sampled_req1 = check_input($_POST['Tissue_Sampled_req']);

if(!empty($_POST['Specimen_Alias_req'])){
$Specimen_Alias_req1 = ($_POST['Specimen_Alias_req']);}
else $Specimen_Alias_req1 = '';

if(!empty($_POST['Date_Acquired_req']) && ($_POST['Date_Acquired_req'] != '00-00-0000')){
$Date_Acquired_req1 = check_input($_POST['Date_Acquired_req']);}
else $Date_Acquired_req1 ='';

if(!empty($_POST['Storage_Location_req'])){
$Storage_Location_req1 = ($_POST['Storage_Location_req']);}
else $Storage_Location_req1 = '';

if(!empty($_POST['Host_Ploidy'])){
$Host_Ploidy1 = check_input($_POST['Host_Ploidy']);}
else $Host_Ploidy1 ='';

if(!empty($_POST['Host_Gender'])){
$Host_Gender1 = check_input($_POST['Host_Gender']);}
else $Host_Gender1 ='';

if(!empty($_POST['Host_Age'])){
$Host_Age1 = ($_POST['Host_Age']);}
else $Host_Age1 = '';

if(!empty($_POST['Host_Ethnicity'])){
$Host_Ethnicity1 =  check_input($_POST['Host_Ethnicity']);}
else $Host_Ethnicity1 = '';


if(!empty($_POST['Diagnostic_Screen'])){
$Diagnostic_Screen1 = check_inputS($_POST['Diagnostic_Screen']);}
else $Diagnostic_Screen1 = '';

if(!empty($_POST['Pathogen_Type'])){
$Pathogen_Type1 = check_input($_POST['Pathogen_Type']);}
else $Pathogen_Type1 = '';

if(!empty($_POST['Pathogen_Dose'])){
$Pathogen_Dose1 = check_input($_POST['Pathogen_Dose']);}
else $Pathogen_Dose1 = '';

if(!empty($_POST['Pathogen_Delivery'])){
$Pathogen_Delivery1 = check_input($_POST['Pathogen_Delivery']);}
else $Pathogen_Delivery1 = '';

if(!empty($_POST['Specimen_Collection_Timing'])){
$Specimen_Collection_Timing1 = check_input($_POST['Specimen_Collection_Timing']);}
else $Specimen_Collection_Timing1 = '';

if(!empty($_POST['Remarks'])){
$Remarks1 =  check_inputS($_POST['Remarks']);}
else $Remarks1 = '';

//start upload
if(!empty($_FILES['Experimentalists_notes_upload']['name']))
{  
  if ($_FILES["Experimentalists_notes_upload"]["size"] < 100000 && $_FILES["Experimentalists_notes_upload"]["type"]=="text/plain")
    { 
   
     if ($_FILES["Experimentalists_notes_upload"]["error"] > 0)
  {
   $error[12] = urlencode('Please enter a valid file.');
   echo '<div id="error">' . $error[12];
   echo '<div id="error">' . $_FILES["Experimentalists_notes_upload"]["error"] . "<br />";
  }

 else
   {
     $uploadfile1 = $_FILES['Experimentalists_notes_upload']['tmp_name'];   //tmp name selected in directory
     $Experimentalists_notes_upload1 = $_FILES['Experimentalists_notes_upload']['name'];       //name selected in directory
     $filetype1  = $_FILES['Experimentalists_notes_upload']['type'];       // type of file
     $fileuploaded1 = file_get_contents($uploadfile1);  
    
     // Prepare user-submitted values for safe database insert
     $fileuploaded1 = check_input($fileuploaded1);
     $filetype1 = check_input($filetype1);
     $Experimentalists_notes_upload1 =check_input($Experimentalists_notes_upload1);
   }       
  } //if - test size
  else {echo '<div id="error">' . "No file uploaded: size or file type incorrect.";}
}//if - non empty
else 
{
$Experimentalists_notes_upload1='';
$fileuploaded1 = '';
$filetype1 = '';
}
//end upload


if (empty($error)) {

include_once '../config.inc'; //data for the connection

 $db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//Using the correct database
 $db1 = mysql_select_db($dbname, $db) or die(mysql_error($db));

 $query = 'INSERT INTO HPMB_SpecimenInfo SET
   Specimen_UID_req     ="' . $Specimen_UID_req1 . '",
   Specimen_Alias_req   ="' . $Specimen_Alias_req1 . '",
   Date_Acquired_req    ="' . $Date_Acquired_req1 . '",
   Acquired_By_req      ="' . $Acquired_By_req1 . '",
   Storage_Location_req ="' . $Storage_Location_req1 . '",
   Source_req           ="' . $Source_req1  . '",
   Specimen_Type_req    ="' . $Specimen_Type_req1 . '",
   Host_ID_req          ="' . $Host_ID_req1  . '",
   Host_Organism_req    ="' . $Host_Organism_req1 . '",
   Host_Ploidy          ="' . $Host_Ploidy1 . '",
   Host_Gender          ="' . $Host_Gender1 . '",
   Host_Age             ="' . $Host_Age1 . '",
   Host_Ethnicity       ="' . $Host_Ethnicity1 . '",
   Tissue_Sampled_req   ="' . $Tissue_Sampled_req1 . '",
   Diagnostic_Screen    ="' . $Diagnostic_Screen1  . '",
   Pathogen_Type        ="' . $Pathogen_Type1  . '",
   Pathogen_Dose        ="' . $Pathogen_Dose1 . '",
   Pathogen_Delivery    ="' . $Pathogen_Delivery1 . '",
   Specimen_Collection_Timing = "' . $Specimen_Collection_Timing1 . '",
   Experimentalists_notes_upload = "' . $Experimentalists_notes_upload1 . '",
   fileuploaded         = "' . $fileuploaded1 . '",
   filetype             = "' . $filetype1 . '",
   Remarks              = "' . $Remarks1  . '",
   createdby            = "' . $createdby1 . '",  
   timecreation         = "' . $timecreation1 . '", 
   modifiedby           ="' . $_SESSION['usernam'] . '", 
   timemodified         = NOW(),
   track_id             ="' . $track_id1 .'",
   track_spec           ="' . $track_spec1.'"';

$result = mysql_query($query, $db) or die(mysql_error($db));

echo '<div id="messages">' . 'Specimen Data updated for Specimen UID = ' . "'$Specimen_UID_req1'";
} //if no error
}//else if valid
} //no duplicate

function valid_info() //required
{
$error = array();

if(empty($_POST['Source_req'])){
 $error[4] = urlencode('Please enter a Source.');
 echo '<div id="error">' . $error[4];
}

if(empty($_POST['Specimen_Type_req'])){
 $error[5] = urlencode('Please enter a Specimen Type.');
 echo '<div id="error">' . $error[5];
}

if ($_POST['Specimen_Type_req']=="other")
 {
  if(empty($_POST['other_type'])){
  $error[5] = urlencode('Please enter Other Specimen Type.');
 echo '<div id="error">' . $error[5];
  }
}

if(empty($_POST['Host_ID_req'])){
 $error[6] = urlencode('Please enter Host ID.');
 echo '<div id="error">' . $error[6];
}

if(empty($_POST['Host_Organism_req'])){
 $error[7] =  urlencode('Please enter Host Organism.');
 echo '<div id="error">' . $error[7];
}

 if(empty($_POST['Tissue_Sampled_req'])){
 $error[8] = urlencode('Please enter Tissue Sampled.');
 echo '<div id="error">' . $error[8];
}

 if(!empty($_POST['Host_Age'])){
     if (check_input_age($_POST['Host_Age']) =="FALSO")
     $error[11] = urlencode('Please enter a valid Host Age.');
     echo '<div id="error">' . $error[11];
 }

if(!empty($_POST['Date_Acquired_req']) && ($_POST['Date_Acquired_req'] != '00-00-0000')){
 if (check_date($_POST['Date_Acquired_req']) == "FALSO"){
 $error = urlencode('Please enter a valid date .');
 echo '<div id="error">' . $error;
}
 else $Date_Acquired_req=check_date($_POST['Date_Acquired_req']);
}

if(!empty($_POST['Specimen_Alias_req']))
     $Specimen_Alias_req1 = check_input($_POST['Specimen_Alias_req']);


 if(!empty($_POST['Storage_Location_req'])){
     $Storage_Location_req1= check_input($_POST['Storage_Location_req']);
 }


if (empty($error)) 
     return TRUE;
else 
   return FALSE;


}// valid_info


function check_date($data)
{

    if(!preg_match('/^(\d\d?)-(\d\d?)-(\d\d\d\d)$/', $data, $matches))
     return "FALSO";
    
    elseif (($matches[1]>=1 && $matches[1]<=12) and  ($matches[2]>=1 && $matches[2]<=31) and ($matches[3]>=1970 && $matches[2]<=2030)) 
   {
   $dob1=trim($data);
   list($m, $d, $y) = explode('-', $dob1);
   $mk=mktime(0, 0, 0, $m, $d, $y);
   $data=strftime('%Y-%m-%d',$mk);
   return $data; 
   }
   return "FALSO";
} //function


function check_input_age($data)
{
  $data = (int)$data;
  if(!is_int($data))
    return "FALSO";
  else
    return $data;
}

function check_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data);
    return $data;
}

function check_inputS($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data);

if (strlen($data) > 5000) {
    $stringCut = substr($data, 0, 5000);
    $data= $stringCut;
}   
    return $data;
}


?>

</div>
</body>

</html>
