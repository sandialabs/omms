<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, specimAdd.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/

session_start(); 
$testStg=md5('salt'.microtime());
$_SESSION['testStore']=$testStg;

include_once '../configUser.inc';

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Specimen Info</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li ><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSpecimen.php">Update</a></li> 
<li><a href="consultSpecimen.php">Consult</a></li>
<li><a href="helpSpecimen.php">Help</a></li>  
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 

</ul> 
</div> 
<style type="text/css"><!--
#other{
    display: none;
}
--></style>
<script type="text/javascript"><!--
function checkOther(select){
    if( select[select.selectedIndex].value=="other" ){
        document.getElementById("other").style.display = "inline";
    }else{
        document.getElementById("other").style.display = "none";
    }
}
//--></script>
<?php

if ( ($_SESSION['new']=="1")){
$specAlias = $_SESSION['Specimen_Alias_req'];
$dateAq    = $_SESSION['Date_Acquired_req'];
$acqBy     = $_SESSION['Acquired_By_req'];
$stgLoc    = $_SESSION['Storage_Location_req'] ;
$src       = $_SESSION['Source_req'];
$specT     = $_SESSION['Specimen_Type_req'] ;
$hostId    = $_SESSION['Host_ID_req'];
$hostOr    = $_SESSION['Host_Organism_req'] ;
$hostPl    = $_SESSION['Host_Ploidy'] ;
$hostGn    = $_SESSION['Host_Gender'] ;
$hostAg    = $_SESSION['Host_Age'] ;
$hostEt    = $_SESSION['Host_Ethnicity'] ;
$tissue    = $_SESSION['Tissue_Sampled_req'];
$diagSc    = $_SESSION['Diagnostic_Screen'];
$pathT    = $_SESSION['Pathogen_Type'] ;
$pathDo    = $_SESSION['Pathogen_Dose'] ;
$pathDe    = $_SESSION['Pathogen_Delivery'] ;
$specC    = $_SESSION['Specimen_Collection_Timing'];
$remk    = $_SESSION['Remarks'];

} 
 else 
 {
$specAlias =  '';
$dateAq    = '';
$acqBy     = '';
$stgLoc    = '';
$src    = '';
$specT     = '';
$hostId    = '';
$hostOr    = '';
$hostPl    = '';
$hostGn    = '';
$hostAg    = '';
$hostEt    = '';
$tissue    = '';
$diagSc    = '';
$pathT    = '';
$pathDo    = '';
$pathDe    = '';
$specC    = '';
$remk    = '';

}



?>



<title> Add Specimen </title>
</head>

<body>
       <BR>&nbsp;<BR>

         <form id="form2" action="createSpecim.php" method="post" enctype="multipart/form-data">     

         

              <h3><span> Add Specimen</span></h3>

         

              <fieldset><legend>Create Specimen</legend>

                   <p class="first">
                        <label for="Specimen_Alias_req" >Specimen Alias </label>

                        <input type="text" size="100" maxlength="100" name="Specimen_Alias_req" id="Specimen_Alias_req" value="<?php  echo $specAlias ; ?>" />
                   </p>

                   <p>
                        <label for="Acquired_By_req">Acquired By (*). (*) REQUIRED</label>
                        <input type="text" size="100" maxlength="100" name="Acquired_By_req" id="Acquired_By_req" value="<?php  echo $acqBy ; ?>"/>
                   </p> 
                      <p>

                       <select name=Specimen_Type_req onchange="checkOther(this)">
                       <option VALUE="<?php  echo $specT ; ?>">Specimen Type (*) Required : <?php  echo $specT ; ?>
                       <option value="other">Other</option>
                       </select>
                       <input id="other" type="text" size="100" maxlength="100" name="other_type" />
                   </p>         


		   <p>
                        <label for="Source_req">Source (*)</label>
                        <input type="text" size="100" maxlength="100" name="Source_req" id="Source_req" value="<?php  echo $src ; ?>" />
                   </p>     

  
		   <p>
                        <label for="Host_ID_req">Host ID (*)</label>
                        <input type="text" size="100" maxlength="100" name="Host_ID_req" id="Host_ID_req" value="<?php  echo $hostId ; ?>"/>
                   </p>
     
		   <p>
                        <label for="Host_Organism_req">Host Species (*). Needed to generate Specimen ID</label>
                        <input type="text" size="100" maxlength="100" name="Host_Organism_req" id="Host_Organism_req" value="<?php  echo $hostOr ; ?>"/>
                   </p>

		   <p>
                        <label for="Tissue_Sampled_req">Tissue Sampled (*). Needed to generate Specimen ID</label>
                        <input type="text" size="100" maxlength="100" name="Tissue_Sampled_req" id="Tissue_Sampled_req" value="<?php  echo $tissue ; ?>"/>
	          </p>   

                   <p>
                        <label for="Date_Acquired_req">Date Acquired Format (mm-dd-yyyy)</label>
                        <input type="text" size="10" maxlength="10" name="Date_Acquired_req" id="Date_Acquired_req" value='<?php echo $dateAq ?>'/>
                   <p>                                                                                                         
                      
                   <p>
                        <label for="Storage_Location_req">Storage Location </label>
                        <input type="text" size="100" maxlength="100" name="Storage_Location_req" id="Storage_Location_req" value="<?php  echo $stgLoc ; ?>" />
                   </p>     

		<p>
                        <label for="Host_Ploidy">Host Ploidy</label>
                        <input type="text" size="100" maxlength="100" name="Host_Ploidy" id="Host_Ploidy" value="<?php  echo $hostPl; ?>"/>
                   </p>

                   <p>
                      <select name=Host_Gender>
                       <option VALUE=<?php  echo $hostGn ; ?>>Host Gender: <?php  echo $hostGn ; ?>
                       <option value="male">male</option>
                       <option value="female">female</option>
                      </select>
                   </p>     
		   <p>
                        <label for="Host_Age">Host Age</label>
                        <input type="text" size="3" maxlength="3" name="Host_Age" id="Host_Age" value="<?php  echo $hostAg; ?>"/>
                   </p>     

		   <p>
                        <label for="Host_Ethnicity">Host Ethnicity</label>
                        <input type="text" size="100" maxlength="100" name="Host_Ethnicity" id="Host_Ethnicity" value="<?php  echo $hostEt; ?>"/>
                   </p>     
  
 <p>
 <tr>
      <th><label for="Diagnostic_Screen">Additional Host MetaData</label></th>
      <td><textarea name="Diagnostic_Screen" id="Diagnostic_Screen"maxlength="5000" wrap="hard"  value= <?php  echo '<textarea>'.$diagSc.'</textarea>'; ?>  </textarea></td>
    </tr>
</p>
         
		   <p>
                        <label for="Pathogen_Type">Pathogen Species</label>
                        <input type="text" size="100" maxlength="100" name="Pathogen_Type" id="Pathogen_Type" value="<?php  echo $pathT ; ?>"/>
		   </p>     

		   <p>
                        <label for="Pathogen_Dose">Pathogen Dose/Titer</label>
                        <input type="text" size="100" maxlength="100" name="Pathogen_Dose" id="Pathogen_Dose" value="<?php  echo $pathDo ; ?>"/>
                   </p>     

		   <p>
                        <label for="Pathogen_Delivery">Pathogen Delivery</label>
                        <input type="text" size="100" maxlength="100" name="Pathogen_Delivery" id="Pathogen_Delivery" value="<?php  echo $pathDe; ?>"/>
                   </p>     

		   <p>
                        <label for="Specimen_Collection_Timing">Specimen Collection Timing</label>
                        <input type="text" size="100" maxlength="100" name="Specimen_Collection_Timing" id="Specimen_Collection_Timing" value="<?php  echo $specC ; ?>"/>
                   </p>     
 
	<p>
	 <tr>
      <th><label for="Remarks">Additional Pathogen MetaData</label></th>
      <td><textarea name="Remarks" id="Remarks"  maxlength="5000"  wrap="hard" value= <?php  echo '<textarea>'.$remk.'</textarea>'; ?>  </textarea></td>
    </tr>
	</p>


		   <p>
                        <label for="Experimentalists_notes_upload">Upload notes: </label>
                        <input type="file" accept="text/txt" name="Experimentalists_notes_upload" id="Experimentalists_notes_upload" />            
                   </p>     

		<p>
                  <input type="hidden" name="testStore" value=<?php echo $testStg ;?> />     
		</p>

                   
                    <p class="submit"><button type="submit">Add Specimen</button></p>   
                          
                   <input type="hidden" name="submit" value="1"/>
                   

              </fieldset>                         
                             
         </form>     
  
  </body>
</html>





