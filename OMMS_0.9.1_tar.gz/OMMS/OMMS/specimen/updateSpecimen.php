<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, updateSpecimen.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Specimen Info</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li ><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSpecimen.php">Update</a></li> 
<li><a href="consultSpecimen.php">Consult</a></li>
<li><a href="helpSpecimen.php">Help</a></li>  
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 

</ul> 
</div> 
<BR>&nbsp;<BR>

<?php
session_start();
include_once '../configUser.inc';

if(isset($_POST['Specimen_UID_req']) )
{
$_SESSION['Specimen_UID_req'] = $_POST['Specimen_UID_req'];

} 
 else 
 {
$_SESSION['Specimen_UID_req'] ='';
}

    
echo "<h3><span>Update Specimen</span></h3>";
echo '<div id="messages2">' . 'Select the Specimen Unique ID to Update ';
echo "<table border='1'>
<tr>
  <th>Specimen UID </th>
  <th>Specimen Alias </th>
  <th>Date Acquired </th>
  <th>Acquired By </th>
  <th>Storage Location </th>
  <th>Source          </th>
  <th>Specimen Type </th>
</tr>";

include_once '../config.inc'; //data for the connection
$db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//Using the correct database
$db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));

$result = mysql_query("SELECT Specimen_UID_req, Specimen_Alias_req, Date_Acquired_req, Acquired_By_req, Storage_Location_req, Source_req, Specimen_Type_req, track_id FROM (SELECT Specimen_UID_req, Specimen_Alias_req, Date_Acquired_req, Acquired_By_req, Storage_Location_req, Source_req, Specimen_Type_req, track_id, track_spec FROM HPMB_SpecimenInfo WHERE Specimen_Alias_req != 'HIDDEN' ORDER BY track_id, track_spec DESC) AS temp1 GROUP by track_id", $db);

while (list($Specimen_UID_req, $Specimen_Alias_req, $Date_Acquired_req, $Acquired_By_req, $Storage_Location_req, $Source_req, $Specimen_Type_req) = mysql_fetch_row($result)) {
    echo " <tr>\n" ;
      echo "  <td><a href=\"upd2.php?id=$Specimen_UID_req\">$Specimen_UID_req</a></td>\n" .
          "   <td>$Specimen_Alias_req</td>\n" .
          "   <td>$Date_Acquired_req</td>\n" .
          "   <td>$Acquired_By_req</td>\n" .
          "   <td>$Storage_Location_req</td>\n" .
          "   <td>$Source_req</td>\n" .
          "   <td>$Specimen_Type_req</td>\n" .
          " </tr>\n";
}

?>



