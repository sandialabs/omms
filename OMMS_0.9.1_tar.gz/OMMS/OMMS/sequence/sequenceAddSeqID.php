<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, sequenceAddSeqID.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/

session_start();
$testStg=md5('salt'.microtime());
$_SESSION['testStore']=$testStg;
$_SESSION['form2']= $_POST; 
include_once('../configUser.inc');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Sequence MetaInfo</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSequence.php">Update</a></li> 
<li><a href="consultSequence.php">Consult</a></li> 
<li><a href="helpSequence.php">Help</a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<?php

$string = $_GET['id'];

if (!empty($string)){
    $data = trim($string);
    $data = stripslashes($data);
    $data = strip_tags($data);


   include_once '../config.inc'; //data for the connection
   $db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

   //Using the correct database
   $db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));
   $query1 = 'SELECT COUNT(SequenceRun_ID_req) AS Uid FROM HPMB_SequenceMetaInfo WHERE SequenceRun_ID_req="' . $data . '" '; 

   $result1 = mysql_query($query1,$db) or die(mysql_error($db));
  if (!$result1)
  {
    echo '<div id="error">' . 'Error no such record exist from database.';
    exit();
  }
  else
   {
    $row = mysql_fetch_array($result1);
    $total =mysql_result($result1, 0, 0);
   }
 if ($total == 0)
 {
 echo '<div id="error">' . 'Error no such record exist from database.';
 exit();
 }

 $query2 = 'SELECT * FROM HPMB_SequenceMetaInfo WHERE SequenceRun_ID_req = "' . $data . '" AND track_sequence = "'
 . $total .'"'; 

 $result2 = mysql_query($query2,$db) or die(mysql_error());
  if (!$result2)
  {
    echo 'Error selecting records from database.';
    exit();
  }
    
    $row2 = mysql_fetch_array($result2);
    $Experiment_Name_req = "$row2[Experiment_Name_req]"; 
    $Specimen_UID_req = "$row2[Specimen_UID_req]"; 
    $Specimen_UID_sec = "$row2[Specimen_UID_sec]"; 
    $Sample_UID_req = "$row2[Sample_UID_req]"; 
    $Sample_Alias_req = "$row2[Sample_Alias_req]";
    $Sequence_Lane_req ="$row2[Sequence_Lane_req]";
    $Sequence_Data     ="$row2[Sequence_Data]";
    if ($row2['Date_Sample_Submitted'] == '0000-00-00' ) {$Date_Sample_Submitted='0000-00-00'; }
    else { $Date_Sample_Submitted = change_date_format( $row2['Date_Sample_Submitted']);}
    $Specimen_UID_sec = "$row2[Specimen_UID_sec]";
    $Sequencing_Provider = "$row2[Sequencing_Provider]";
    $ProviderSeqDirName  = "$row2[ProviderSeqDirName]";
    $fastqMatePair1 	 = "$row2[fastqMatePair1]";
    $fastqMatePair2      = "$row2[fastqMatePair2]";
    $Sequencing_Platform = "$row2[Sequencing_Platform]";
    $Project    = "$row2[Project]";
    $Run_Plexing    = "$row2[Run_Plexing]";
    if ($row2['Date_Run_Performed'] == '0000-00-00' ) {$Date_Run_Performed ='0000-00-00' ;}
    else { $Date_Run_Performed = change_date_format( $row2['Date_Run_Performed']);}
    $Run_Number          = "$row2[Run_Number]";
    if ($row2['Date_Run_Performed'] == '0000-00-00' ) {$Date_Data_Received ='0000-00-00';}
    else { $Date_Data_Received = change_date_format( $row2['Date_Data_Received']);}
    $Total_Reads_Millions = "$row2[Total_Reads_Millions]";
    $Read_Type            = "$row2[Read_Type]";
    $Read_Length_Bases    = "$row2[Read_Length_Bases]";
    $Total_Bases_Billions             = "$row2[Total_Bases_Billions]";
    $Experimentalists_notes_upload = "$row2[Experimentalists_notes_upload]";
    $fileuploaded         =  "$row2[fileuploaded]";
    $filetype             = "$row2[filetype]";
    $Remarks              = "$row2[Remarks]";
    $createdby            = $row2['createdby'] ;
    $timecreation         = $row2['timecreation']; 
    $modifiedby           = $row2['modifiedby'];
    $timemodified         = $row2['timemodified'];
    $track_id             = $row2['track_id'];
    $track_sequence       = $row2['track_sequence'] + 1; 
    $track_exp           = $row2['track_exp'];


$sql="SELECT Sample_UID_req, Sample_Alias_req FROM (SELECT Sample_UID_req, Sample_Alias_req, timemodified FROM HPMB_SampleProcessing ORDER BY timemodified desc) AS temp GROUP BY Sample_UID_req";
$result3=mysql_query($sql);



$sql1="SELECT Specimen_UID_req FROM HPMB_SpecimenInfo GROUP by Specimen_UID_req";
$result=mysql_query($sql1);
$result5=mysql_query($sql1);

mysql_free_result($result1);
mysql_free_result($result2);


} //else no empty UID
?>



<title> Add Sequence </title>
</head>

<body>
         <BR>&nbsp;<BR>
         <form id="form2" action="createSequence.php" method="post" enctype="multipart/form-data">     
         
         

              <h3><span> Add Sequence</span></h3>

         

              <fieldset><legend>Create Sequence</legend>
 

       <p>
        <select name=Sample_UID_req>
	<option value="<?php echo "$Sample_UID_req=$Sample_Alias_req";?>">Sample UID = Sample Alias (*) : <?php echo "$Sample_UID_req=$Sample_Alias_req";?></option>
	<?php
	while ($row3 = mysql_fetch_array($result3)) {
	?>
	<option value="<?php echo $row3['Sample_UID_req']. "=" .$row3['Sample_Alias_req'] ; ?>"><?php echo $row3['Sample_UID_req']. "=" .$row3['Sample_Alias_req']; ?></option>
<?php } ?> 
</select>
</p>

<p>
  <select name=Specimen_UID_req>
 <option value=<?php echo $Specimen_UID_req;?>>Specimen UID (*) : <?php echo $Specimen_UID_req;?></option>
<?php
while ($row = mysql_fetch_array($result)) {
?>
<option value=<?php echo $row['Specimen_UID_req']; ?>><?php echo $row['Specimen_UID_req']; ?></option>
<?php } ?> 
</select>
</p>

   
 
<p>
  <select name=Specimen_UID_sec>
 <option value=<?php echo $Specimen_UID_sec ;?>>Specimen UID secondary : <?php echo $Specimen_UID_sec;?></option>
<?php
while ($row5 = mysql_fetch_array($result5)) {
?>
<option value=<?php echo $row5['Specimen_UID_req']; ?>><?php echo $row5['Specimen_UID_req']; ?></option>
<?php } ?> 
</select>
</p>  
                     <p>
                       <select name=Sequencing_Provider>
                       <option VALUE=<?php echo $Sequencing_Provider; ?>>Sequencing Provider (*): <?php echo $Sequencing_Provider; ?>
                       <option value="Other">Other</option>
                       </select>
                   </p>                         

                  
                     <p>
                       <select name=Sequencing_Platform>
                       <option VALUE=<?php echo $Sequencing_Platform; ?>>Sequencing Platform (*): <?php echo $Sequencing_Platform; ?>
                       <option value="HiSeq2000">HiSeq2000</option>
                       <option value="GAllx">GAllx</option>
                       <option value="MiSeq">MiSeq</option>
                       <option value="Sanger">Sanger</option>
                       <option value="454">454</option>
                       <option value="Ion Torrent">Ion Torrent</option>
                       <option value="PacBio">PacBio</option>
                       <option value="SOLiD">SOLiD</option>
                       </select>
                   </p>  
                        
		   <p>
                       <select name=Project>
                       <option VALUE=<?php echo $Project; ?>>Project (*): <?php echo $Project; ?>
                       <option value="Other">Other</option>
                       </select>
                   </p>   


		   <p>
                        <label for="ProviderSeqDirName">Provider Sequence Directory Name </label>
                        <input type="text" size="100" maxlength="100" name="ProviderSeqDirName" id="ProviderSeqDirName" value="<?php  echo $ProviderSeqDirName; ?>"  />
                   </p>

                   <p>
                        <label for="fastqMatePair1">Fastq file Mate Pair 1</label>
                        <input type="text" size="50" maxlength="50" name="fastqMatePair1" id="fastqMatePair1" value="<?php  echo $fastqMatePair1; ?>"  />
                   </p>

                   <p>
                        <label for="fastqMatePair2">Fastq file Mate Pair 2</label>
                        <input type="text" size="50" maxlength="50" name="fastqMatePair2" id="fastqMatePair2" value="<?php echo $fastqMatePair2; ?>"  />
                   </p>

                   <p>
                        <label for="Sequence_Lane_req">Sequence Lane  </label>
                       <input type="text" size="11" maxlength="11" name="Sequence_Lane_req" id="Sequence_Lane_req"value= <?php $sixteen = substr($Sequence_Lane_req, 0, 11); if ($sixteen!=0) echo $sixteen ; else echo 0; ?> />
                   </p>   

                   <p>
                        <label for="Date_Sample_Submitted">Date Sample Submitted. Format (mm-dd-yyyy)</label>
                        <input type="text" size="10" maxlength="10" name="Date_Sample_Submitted" id="Date_Sample_Submitted"  value= <?php if ($Date_Sample_Submitted !='') echo $Date_Sample_Submitted ; else echo "&nbsp;";
 ?> />                        
                   <p>                                                                                                         


                   <p>
                        <label for="Run_Plexing">Run Plexing</label>
                       <input type="text" size="100" maxlength="100" name="Run_Plexing" id="Run_Plexing" value= <?php $six = substr($Run_Plexing, 0, 100); if ($six!='') echo $six ; else echo "&nbsp;";?> />
                   </p>


                    <p>
                        <label for="Date_Run_Performed">Date Run Performed. Format (mm-dd-yyyy)</label>
                        <input type="text" size="10" maxlength="10" name="Date_Run_Performed" id="Date_Run_Performed" value= <?php if ($Date_Run_Performed !='') echo $Date_Run_Performed ; else echo "&nbsp;"; ?> />
                   </p>     
		 
		    <p>
                        <label for="Run_Number">Run Number</label>
                        <input type="text" size="11" maxlength="11" name="Run_Number" id="Run_Number" value= <?php $seven = substr($Run_Number, 0, 11); if ($seven!=0) echo $seven; else echo 0; ?> />
                   </p>     

		   <p>
                        <label for="Date_Data_Received">Date Data Received. Format (mm-dd-yyyy)</label>
                        <input type="text" size="10" maxlength="10" name="Date_Data_Received" id="Date_Data_Received" value= <?php if ($Date_Data_Received !='') echo $Date_Data_Received ; else echo "&nbsp;"; ?> />
                   </p>  

		   <p>
                        <label for="Total_Reads_Millions">Total Reads Millions</label>
                        <input type="text" size="10" maxlength="10" name="Total_Reads_Millions" id="Total_Reads_Millions" value= <?php $eight = substr($Total_Reads_Millions, 0, 10); if ($eight!=0.0) echo $eight ; else echo 0.0; ?> />
                   </p>

                   <p>
                     <select name=Read_Type>
                       <option VALUE=<?php echo $Read_Type; ?>>Read Type: <?php echo $Read_Type; ?> 
                       <option value="single-end">single-end</option>
                       <option value="paired-end">paired-end</option>
                     </select>
                   </p>     

                     <p>
                       <select name=Read_Length_Bases>
                       <option VALUE=<?php echo $Read_Length_Bases; ?>>Read Length Bases: <?php echo $Read_Length_Bases; ?>
                       <option value="35">35</option>
                       <option value="51">51</option>
                       <option value="75">75</option>
                       <option value="100">100</option>
                       <option value="150">150</option>
		       <option value="Other">Other</option>
                       </select>
                   </p>      

                  
		   <p>
                        <label for="Total_Bases_Billions">Total Bases Billions</label>
 <input type="text" size="11" maxlength="11" name="Total_Bases_Billions" id="Total_Bases_Billions" value= <?php $eleven = substr($Total_Bases_Billions, 0, 11); if ($eleven!=0) echo $eleven; else echo 0; ?>
                   </p>      

		   <p>
                        <label for="Experimentalists_notes_upload">Upload notes: </label>
<input type="file" accept="text/txt" name="Experimentalists_notes_upload" id="Experimentalists_notes_upload" value= <?php $twenty=substr($Experimentalists_notes_upload,0,200);  if ($twenty !='') echo $twenty ; else echo "&nbsp;"; ?>/>
                   </p>     

		<p>
                <input type="hidden" name="testStore" value=<?php echo $testStg ;?> />     
		</p>
    
                   
                 <p class="submit"><button type="submit">Add Sequence</button></p>   
                          
                 <input type="hidden" name="submit" value="1"/>
                   

              </fieldset>                                             

         </form>     

  </body>
</html>

<?php

function change_date_format($data){

       list($year,$month,$day) = explode("-",$data);
       $newdata = $month."-".$day."-".$year;
       return $newdata;
}

?>

