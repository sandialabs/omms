<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, rgenCSVtables.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/

    session_start();
    include_once('../configUser.inc');
    include_once('../config.inc');

	   $table1='HPMB_SpecimenInfo';
   	   $table2='HPMB_SampleProcessing';	   
	   $table3='HPMB_SequenceMetaInfo';

   if ($_POST['Specimen_UID_req']=='yes')
           {
           $arrayLab[]="Specimen UID";
           $arrayVar[]="t1.Specimen_UID_req";
           }

   if ($_POST['Specimen_Alias_req']=='yes')
           {
           $arrayLab[]="Specimen Alias";
           $arrayVar[]="t1.Specimen_Alias_req";
           }
   if ($_POST['Date_Acquired']=='yes')
           {
           $arrayLab[]="Date Acquired";
           $arrayVar[]="t1.Date_Acquired_req";
           }

   if ($_POST['Acquired_By']=='yes')
           {
           $arrayLab[]="Acquired By";
           $arrayVar[]="t1.Acquired_By_req";
           }
   if ($_POST['Storage_Location']=='yes')
           {
           $arrayLab[]="Storage Location";
           $arrayVar[]="t1.Storage_Location_req";
           }

   if ($_POST['Source']=='yes')
           {
           $arrayLab[]="Source";
           $arrayVar[]="t1.Source_req";
           }
   if ($_POST['Specimen_Type_req']=='yes')
           {
           $arrayLab[]="Specimen Type";
           $arrayVar[]="t1.Specimen_Type_req";
           $table1='HPMB_SpecimenInfo';
           }

//Sample fields

   if ($_POST['Sample_UID_req']=='yes')
           {
           $arrayLab[]="Sample UID";
	   $arrayVar[]="t2.Sample_UID_req";
           }

   if ($_POST['Sample_Alias_req']=='yes')
           {
           $arrayLab[]="Sample Alias";
           $arrayVar[]="t2.Sample_Alias_req";
           }

   if ($_POST['Library_Preparation_ID_req']=='yes')
           {
           $arrayLab[]="Library Preparation";
	   $arrayVar[]="t2.Library_Preparation_ID_req";
           }

   if ($_POST['Barcode']=='yes')
           {
           $arrayLab[]="Barcode";
           $arrayVar[]="t2.Barcode";
           }

   if ($_POST['Primer_Set']=='yes')
           {
           $arrayLab[]="Primer Set";
	   $arrayVar[]="t2.Primer_Set";
           }

   if ($_POST['Target_Nucleic_Acid_req']=='yes')
           {
           $arrayLab[]="Target Nucleic Acid";
           $arrayVar[]="t2.Target_Nucleic_Acid_req";
           }

   if ($_POST['Purification_Nucleic_Acid_Method_req']=='yes')
           {
           $arrayLab[]="Purification Nucleic Acid Method";
	   $arrayVar[]="t2.Purification_Nucleic_Acid_Method_req";
           }

   if ($_POST['Purified_By_req']=='yes')
           {
           $arrayLab[]="Purified By";
           $arrayVar[]="t2.Purified_By_req";
           }

   if ($_POST['Suppression_Method']=='yes')
           {
           $arrayLab[]="Suppression Method";
	   $arrayVar[]="t2.Suppression_Method";
           }

//Sequence fields
 if ($_POST['SequenceRun_ID_req']=='yes')
           {
           $arrayLab[]="Sequence Run ID";
	   $arrayVar[]="t3.SequenceRun_ID_req";
           }

 if ($_POST['Experiment_Name_req']=='yes')
           {
           $arrayLab[]="Experiment Name";
	   $arrayVar[]="t3.Experiment_Name_req";
           }

 if ($_POST['Date_Sample_Submitted']=='yes')
           {
           $arrayLab[]="Date Sample Submitted";
	   $arrayVar[]="t3.Date_Sample_Submitted";
           }

 if ($_POST['Library_Preparation_ID_req']=='yes')
           {
           $arrayLab[]="Library Preparation";
	   $arrayVar[]="t3.Library_Preparation_ID_req";
           }

 if ($_POST['fastqMatePair1']=='yes')
           {
           $arrayLab[]="fastq Mate Pair 1";
	   $arrayVar[]="t3.fastqMatePair1";
           }

 if ($_POST['fastqMatePair2']=='yes')
           {
           $arrayLab[]="fastq Mate Pair 2";
	   $arrayVar[]="t3.fastqMatePair2";
           }

 if ($_POST['Sequencing_Provider']=='yes')
           {
           $arrayLab[]="Sequencing Provider";
	   $arrayVar[]="t3.Sequencing_Provider";
           }

 if ($_POST['Run_Plexing']=='yes')
           {
           $arrayLab[]="Run Plexing";
	   $arrayVar[]="t3.Run_Plexing";
           }

 if ($_POST['Received']=='yes')
           {
           $arrayLab[]="Received";
	   $arrayVar[]="t3.Received";
           }


$field_arr = array_values($arrayLab);
foreach($field_arr as $val){   
  $header .= $val . ',';
}



    $field_arr = array_values($arrayVar);
    $i=1;     
    $val2 = "SELECT ";   
foreach($field_arr as $val){
        if ($i == count($arrayLab))
        	{$val2 = $val2." ". $val;
		}
	else {$val2 = $val2. $val.", ";
	       }
	$i=$i+1;
        }
   
$query1 .= $val2 ." FROM $table1 t1
JOIN $table2 t2 ON ( t1.Specimen_UID_req = t2.Specimen_UID_req )
JOIN $table3 t3 ON ( t2.Sample_UID_req = t3.Sample_UID_req )
GROUP by t3.SequenceRun_ID_req";

$db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');


//Using the correct database
 $db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));

$result1 = mysql_query($query1,$db) or die(mysql_error());

  if (!$result1)
  {
    echo '<div id="error">' . 'Error no records exist from database.';
    exit();
  }


while( $row = mysql_fetch_row( $result1 ) )
{
    $line = '';
    foreach( $row as $val  )
    {                                            
        if ( ( !isset( $val  ) ) || ( $val  == "" ) )
        {
            $val  = "\t";
        }
        else
        {
            $val  = str_replace( '"' , '""' , $val );
            $val  = '"' . $val  . '"' . ',';
        }
        $line .= $val ;
    }
    $data .= trim( $line ) . "\n";
}
$data = str_replace( "\r" , "" , $data );

if ( $data == "" )
{
    $data = "\n(0) Records Found!\n";                        
}

$filename = date("Ymd")."_reportSequences.csv";
header("Content-type: application/csv");
header("Content-Disposition: attachment; filename=$filename");
header("Pragma: no-cache");
header("Expires: 0");
print "$header\n$data";

?>




