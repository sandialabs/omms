<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, generateCSV.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Sequence MetaInfo</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSequence.php">Update</a></li> 
<li><a href="consultSequence.php">Consult</a></li> 
<li><a href="helpSequence.php">Help</a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<BR>&nbsp;<BR>

<title> Report Configuration </title>
</head>

<body>
         <form id="form2" action="genCSVtables.php" method="post" enctype="multipart/form-data">     

         

              <h3><span> Spreadsheet Generation</span></h3>

              <fieldset><legend>Select fields to generate report</legend>
                <p>
                   <label for="specimen"> __________________________________ Specimen Info ________________________________ </label>
                 </p>
		<p>

                        <label for="Specimen_UID_req">Specimen UID </label>
                        <input type="checkbox" name="Specimen_UID_req" value="yes"> 
                        
                   </p>
		   <p>

                        <label for="Specimen_Alias_req">Specimen Alias </label>
                        <input type="checkbox" name="Specimen_UID_req" value="yes"> 
                        
                   </p>
		   <p>

                        <label for="Date_Acquired">Date Acquired </label>
                        <input type="checkbox" name="Date_Acquired" value="yes"> 
                        
                   </p>
		   <p>

                        <label for="Acquired_By">Acquired By </label>
                        <input type="checkbox" name="Acquired_By" value="yes"> 
                        
                   </p>
		   <p>

                        <label for="Storage_Location">Storage Location </label>
                        <input type="checkbox" name="Storage_Location" value="yes"> 
                        
                   </p>
		   <p>

                        <label for="Source">Source </label>
                        <input type="checkbox" name="Source" value="yes"> 
                        
                   </p>	
                     <p>

                        <label for="Specimen_Type_req">Specimen Type </label>
                        <input type="checkbox" name="Specimen_Type_req" value="yes"> 
                        
                   </p>

  		 <p>
                   <label for="sample">  ________________________________ Sample Processing ______________________________ </label>
                 </p>
                    <p>

                        <label for="Sample_UID_req">Sample UID </label>
                        <input type="checkbox" name="Sample_UID_req" value="yes">      
                   </p>
           
                     <p>
                        <label for="Sample_Alias_req">Sample Alias </label>
                        <input type="checkbox" name="Sample_Alias_req" value="yes">                        
                   </p>
                                                       
  		     <p>
                        <label for="Library_Preparation_ID_req">Library Preparation </label>
                        <input type="checkbox" name="Library_Preparation_ID_req" value="yes"> 
                   </p>
           
                     <p>
                        <label for="Barcode">Barcode </label>
                        <input type="checkbox" name="Barcode" value="yes"> 
                   </p>  
		
		    <p>
                        <label for="Primer_Set">Primer Set </label>
                        <input type="checkbox" name="Primer_Set" value="yes">  
                   </p>
           
                     <p>
                        <label for="Target_Nucleic_Acid_req">Target Nucleic Acid </label>
                        <input type="checkbox" name="Target_Nucleic_Acid_req" value="yes"> 
                   </p>  

		    <p>

                        <label for="Purification_Nucleic_Acid_Method_req">Purification Nucleic Acid Method </label>
                        <input type="checkbox" name="Purification_Nucleic_Acid_Method_req" value="yes"> 
                        
                   </p>
           
                     <p>
                        <label for="Purified_By_req">Purified By</label>
                        <input type="checkbox" name="Purified_By_req" value="yes"> 
                   </p>
                              
  		   <p>
                        <label for="Suppression_Method">Suppression Method </label>
                        <input type="checkbox" name="Suppression_Method" value="yes">      
                   </p>

  		 <p>
                   <label for="sequence">  ________________________________ Sequence MetaInfo ______________________________ </label>
                 </p>

		   <p>
                        <label for="SequenceRun_ID_req">Sequence Run ID </label>
                        <input type="checkbox" name="SequenceRun_ID_req" value="yes">        
                </p>
           
                                                             
  		<p>
                        <label for="Experiment_Name_req">Experiment Name </label>
                        <input type="checkbox" name="Experiment_Name_req" value="yes">      
                </p>
           
                <p>
                        <label for="Date_Sample_Submitted">Date Sample Submitted </label>
                        <input type="checkbox" name="Date_Sample_Submitted" value="yes">                       
                </p>  

		<p>
                        <label for="Library_Preparation_ID_req">Library Preparation ID </label>
                        <input type="checkbox" name="Library_Preparation_ID_req" value="yes">      
                </p>
           
                     <p>
                        <label for="fastqMatePair1">Fastq Mate Pair 1</label>
                        <input type="checkbox" name="fastqMatePair1" value="yes"> 
                   </p>
                              
  		<p>
                        <label for="fastqMatePair2">Fastq Mate Pair 2 </label>
                        <input type="checkbox" name="fastqMatePair2" value="yes">      
                   </p>

		   <p>
                        <label for="Sequencing_Provider">Sequencing Provider </label>
                        <input type="checkbox" name="Sequencing_Provider" value="yes">   
                   </p>
           
                   <p>
                        <label for="Run_Plexing">Run Plexing </label>
                        <input type="checkbox" name="Run_Plexing" value="yes">   
                   </p>
                              
 		   <p>
                        <label for="Received">Received </label>
                        <input type="checkbox" name="Received" value="yes">     
                   </p>
           
                   <p class="submit"><button type="submit">Generate</button></p>   
                          
                   <input type="hidden" name="submit" value="1"/>
                   

              </fieldset> 
         </form>     

  </body>
</html>


