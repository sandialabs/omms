<?php
/*
This file is part of OMICS METADATA MANAGEMENT SOFTWARE (OMMS).
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, update2.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Sequence MetaInfo</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSequence.php">Update</a></li> 
<li><a href="consultSequence.php">Consult</a></li> 
<li><a href="helpSequence.php">Help</a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<BR>&nbsp;<BR>
<BR>&nbsp;<BR>
<BR>&nbsp;<BR>
<?php
session_start();
if ($_SESSION['testStore'] != $_POST['testStore']) {
   echo '<div id="error">'. "Not allowed to duplicate the information.";
}
else
{
 $_SESSION['testStore'] = null;
 include_once '../configUser.inc';


if (valid_info()) 
{   

$SequenceRun_ID_req1 = ($_POST['SequenceRun_ID_req']);
$Specimen_UID_req1 = check_input($_POST['Specimen_UID_req']);
$Sample_UID_req1 = check_input($_POST['Sample_UID_req']);
$Sample_Alias_req1=$_POST['Sample_Alias_req'];
$Experiment_Name_req1 =$_POST['Experiment_Name_req'];
$Sequence_Lane_req1 = check_input_int($_POST['Sequence_Lane_req']);
$Sequence_Data1 = ($_POST['Sequence_Data']);
$Sequencing_Platform1 =  check_input($_POST['Sequencing_Platform']);
$Project1 =check_input($_POST['Project']);
$Sequencing_Provider1 =  check_input($_POST['Sequencing_Provider']);
$createdby1 = check_input($_POST['createdby']);
$timecreation1 = check_input($_POST['timecreation']);
$track_id1 = $_POST['track_id'];
$track_sequence1 = $_POST['track_sequence'];
$track_exp1 = $_POST['track_exp'];

if(!empty($_POST['Specimen_UID_sec'])){
$Specimen_UID_sec1 =check_input ($_POST['Specimen_UID_sec']);}
else $Specimen_UID_sec1 = '';
 
if(!empty($_POST['Date_Sample_Submitted']) && ($_POST['Date_Sample_Submitted'] != '0000-00-00')){
$Date_Sample_Submitted1 = check_date($_POST['Date_Sample_Submitted']);}
else $Date_Sample_Submitted1 ='';

if(!empty($_POST['Run_Plexing'])){
$Run_Plexing1 = check_input($_POST['Run_Plexing']);}
else $Run_Plexing1 = '';

if(!empty($_POST['ProviderSeqDirName'])){
$ProviderSeqDirName1 =  check_input($_POST['ProviderSeqDirName']);}
else $ProviderSeqDirName1 = '';

if(!empty($_POST['fastqMatePair1'])){
$fastqMatePair1_1 =  check_input($_POST['fastqMatePair1']);}
else $fastqMatePair1_1 = '';

if(!empty($_POST['fastqMatePair2'])){
$fastqMatePair2_1 =  check_input($_POST['fastqMatePair2']);}
else $fastqMatePair2_1 = '';

if(!empty($_POST['Date_Run_Performed']) && ($_POST['Date_Run_Performed'] != '0000-00-00')){
$Date_Run_Performed1 = check_date($_POST['Date_Run_Performed']);}
else $Date_Run_Performed1 ='';

if(!empty($_POST['Run_Number'])){
$Run_Number1 = check_input_int($_POST['Run_Number']);}
else $Run_Number1 = '';

if(!empty($_POST['Date_Data_Received']) && ($_POST['Date_Data_Received'] != '0000-00-00')){
$Date_Data_Received1 = check_date($_POST['Date_Data_Received']);}
else $Date_Data_Received1 ='';

if(!empty($_POST['Total_Reads_Millions'])){
$Total_Reads_Millions1 = check_input_float($_POST['Total_Reads_Millions']);}
else $Total_Reads_Millions1 = '';

if(!empty($_POST['Read_Type'])){
$Read_Type1 = check_input($_POST['Read_Type']);}
else $Read_Type1 = '';

if(!empty($_POST['Read_Length_Bases'])){
$Read_Length_Bases1 = check_input_int($_POST['Read_Length_Bases']);}
else $Read_Length_Bases1 = '';

if(!empty($_POST['Total_Bases_Billions'])){
$Total_Bases_Billions1 = check_input_int($_POST['Total_Bases_Billions']);}
else $Total_Bases_Billions1 = '';

if(!empty($_POST['Remarks'])){
$Remarks1 =  check_input($_POST['Remarks']);}
else $Remarks1 = '';

//start upload
if(!empty($_FILES['Experimentalists_notes_upload']['name']))
{  
  if ($_FILES["Experimentalists_notes_upload"]["size"] < 100000 && $_FILES["Experimentalists_notes_upload"]["type"]=="text/plain")
    { 
   
     if ($_FILES["Experimentalists_notes_upload"]["error"] > 0)
  {
 $error[12] = urlencode('Please enter a valid file.');
 echo '<div id="error">' . $error[12];
 echo '<div id="error">' . $_FILES["Experimentalists_notes_upload"]["error"] . "<br />";
  }

 else
   {
     $uploadfile1 = $_FILES['Experimentalists_notes_upload']['tmp_name'];   //tmp name selected in directory
     $Experimentalists_notes_upload1 = $_FILES['Experimentalists_notes_upload']['name'];       //name selected in directory
     $filetype1  = $_FILES['Experimentalists_notes_upload']['type'];       // type of file
     $fileuploaded1 = file_get_contents($uploadfile1);  
    
     // Prepare user-submitted values for safe database insert
     $fileuploaded1 = check_input($fileuploaded1);
     $filetype1 = check_input($filetype1);
     $Experimentalists_notes_upload1 =check_input($Experimentalists_notes_upload1);
   }       
  } //if - test size
  else {echo '<div id="error">' . "No file uploaded: size or file type incorrect.";}
}//if - non empty
else 
{
$Experimentalists_notes_upload1='';
$fileuploaded1 = '';
$filetype1 = '';
}
//end upload



if (empty($error)) {

   include_once '../config.inc'; //data for the connection

    $db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

   //Using the correct database
    $db1 = mysql_select_db($dbname, $db) or die(mysql_error($db));



$query4 = 'SELECT Library_Preparation_ID_req, Barcode, Barcode_Type, Primer_Set, Primer_Name, timemodified FROM HPMB_SampleProcessing WHERE Sample_UID_req = "' .$Sample_UID_req1 . '" ORDER by timemodified desc LIMIT 1 ';

$result4 = mysql_query($query4,$db) or die(mysql_error());
  if (!$result4)

 {
    $libr1 = '' ;
    $Barcode_Name1 ='';
    $Barcode_Type1 ='';
    $Primer_Set1   ='';
    $Primer_Name1  ='';
  }
  else
    {
     $row = mysql_fetch_array($result4);
     $libr1 = $row['Library_Preparation_ID_req'] ;
     $Barcode1 = $row['Barcode'] ;
     $Barcode_Type1 = $row['Barcode_Type'] ;
     $Primer_Set1   = $row['Primer_Set'] ;
     $Primer_Name1  = $row['Primer_Name'] ;
    } 

$Sequence_Data_Point1='';
  // insert data into
 $query = 'INSERT INTO HPMB_SequenceMetaInfo SET
   Experiment_Name_req  ="' . $Experiment_Name_req1 . '",
   Specimen_UID_req     ="' . $Specimen_UID_req1 . '",
   Specimen_UID_sec     ="' . $Specimen_UID_sec1 . '",
   Sample_UID_req       ="' . $Sample_UID_req1 . '",
   Sample_Alias_req     ="' . $Sample_Alias_req1 . '",
   SequenceRun_ID_req   ="' . $SequenceRun_ID_req1 . '",
   Sequence_Lane_req    ="' . $Sequence_Lane_req1 . '",
   Sequence_Data        ="' . $Sequence_Data1 . '",
   Sequence_Data_Point  ="' . $Sequence_Data_Point1 . '",
   Date_Sample_Submitted="' . $Date_Sample_Submitted1 . '",
   Sequencing_Provider  ="' . $Sequencing_Provider1 . '",
   ProviderSeqDirName 	="' . $ProviderSeqDirName1 . '",
   fastqMatePair1 	="' . $fastqMatePair1_1 . '",
   fastqMatePair2       ="' . $fastqMatePair2_1 . '",
   Sequencing_Platform  ="' . $Sequencing_Platform1 . '",
   Project              ="' . $Project1 . '",
   Run_Plexing          ="' . $Run_Plexing1  . '",
   Barcode_Type         ="' . $Barcode_Type1  . '",
   Barcode              ="' . $Barcode1  . '",
   Library_Preparation_ID_req="' . $libr1  . '",
   Primer_Name          ="' . $Primer_Name1  . '",
   Primer_Set           ="' . $Primer_Set1  . '",
   Date_Run_Performed   ="' . $Date_Run_Performed1 . '",
   Run_Number           ="' . $Run_Number1  . '",
   Date_Data_Received   ="' . $Date_Data_Received1 . '",
   Total_Reads_Millions ="' . $Total_Reads_Millions1 . '",
   Read_Type            ="' . $Read_Type1 . '",
   Read_Length_Bases    ="' . $Read_Length_Bases1 . '",
   Total_Bases_Billions ="' . $Total_Bases_Billions1 . '",
   Experimentalists_notes_upload = "' . $Experimentalists_notes_upload1 . '",
   fileuploaded         = "' . $fileuploaded1 . '",
   filetype             = "' . $filetype1 . '",
   Remarks              = "' . $Remarks1  . '",
   createdby            = "' . $createdby1 . '",  
   timecreation         = "' . $timecreation1 . '", 
   modifiedby           ="' . $_SESSION['username'] . '", 
   timemodified         = NOW(),
   track_id             ="' . $track_id1 .'",
   track_exp            ="' . $track_exp1 .'",
   track_sequence       ="' . $track_sequence1.'"';

//s

$result = mysql_query($query, $db) or die(mysql_error($db));

echo '<div id="messages">' . 'Sequence MetaInfo updated for Sequence Run ID ' . "'$SequenceRun_ID_req1'" . ' and Unique Experiment Name ' . $Experiment_Name_req1;


} //if no error
}//else if valid
} //no duplicate

function valid_info() //required
{
$error = '';

if(empty($_POST['Specimen_UID_req'])) {
$error = urlencode('Please enter a Specimen UID.');
echo '<div id="error">' . $error;
}

if(empty($_POST['Sample_UID_req'])){
$error = urlencode('Please enter a Sample UID.');
echo '<div id="error">' . $error;
}


if(empty($_POST['Sequencing_Provider'])){
$error = urlencode('Please enter a Sequencing Provider.');
echo '<div id="error">' . $error;
}

if(empty($_POST['Sequencing_Platform'])){
$error = urlencode('Please enter a Sequencing Platform.');
echo '<div id="error">' . $error;
}

if(empty($_POST['Project'])){
$error = urlencode('Please enter a Project.');
echo '<div id="error">' . $error;
}


if(!empty($_POST['Date_Sample_Submitted']) && ($_POST['Date_Sample_Submitted'] != '00-00-0000')){
 if (check_date($_POST['Date_Sample_Submitted']) == "FALSO"){
 $error = urlencode('Please enter a valid date sample submitted.');
 echo '<div id="error">' . $error;
}
 else $Date_Sample_Submitted=check_date($_POST['Date_Sample_Submitted']);
}

if(!empty($_POST['Date_Run_Performed']) && ($_POST['Date_Run_Performed'] != '00-00-0000')){
 if (check_date($_POST['Date_Run_Performed']) == "FALSO"){
 $error = urlencode('Please enter a valid date run performed.');
 echo '<div id="error">' . $error;
}
 else $Date_Run_Performed=check_date($_POST['Date_Run_Performed']);
}



if(!empty($_POST['Date_Data_Received']) && ($_POST['Date_Data_Received'] != '00-00-0000')){
 if (check_date($_POST['Date_Data_Received']) == "FALSO"){
 $error = urlencode('Please enter a valid date data received.');
 echo '<div id="error">' . $error;
}
 else $Date_Data_Received=check_date($_POST['Date_Data_Received']);
}


 if(!empty($_POST['Run_Number'])){
     if (check_input_int($_POST['Run_Number']) =="FALSO")
     $error= urlencode('Please enter a valid Run Number.');
     echo '<div id="error">' . $error;
 }


 if(!empty($_POST['Read_Length_Bases'])){
     if (check_input_int($_POST['Read_Length_Bases']) =="FALSO")
     $error= urlencode('Please enter a valid Read Length Bases.');
     echo '<div id="error">' . $error;
 }


 if(!empty($_POST['Total_Bases_Billions'])){
     if (check_input_int($_POST['Total_Bases_Billions']) =="FALSO")
     $error= urlencode('Please enter a valid Total Bases Billions.');
     echo '<div id="error">' . $error;
 }


 if(!empty($_POST['Total_Reads_Millions'])){
     if (check_input_float($_POST['Total_Reads_Millions']) =="FALSO")
     $error= urlencode('Please enter a valid Total Reads Millions.');
     echo '<div id="error">' . $error;
 }


if (empty($error)) 
     return TRUE;
else 
   return FALSE;


}// valid_info


function check_date($data)
{
    
    if(!preg_match('/^(\d\d?)-(\d\d?)-(\d\d\d\d)$/', $data, $matches))
     return "FALSO";
    
    elseif (($matches[1]>=1 && $matches[1]<=12) and  ($matches[2]>=1 && $matches[2]<=31) and ($matches[3]>=1970 && $matches[2]<=2030)) 
   {
   $dob1=trim($data);
   list($m, $d, $y) = explode('-', $dob1);
   $mk=mktime(0, 0, 0, $m, $d, $y);
   $data=strftime('%Y-%m-%d',$mk);
   return $data; 
   }
   return "FALSO";
} //function

function check_date_nr($dat)
{
    if ($dat == "empty") return "";
    if(!preg_match('/^(\d\d?)-(\d\d?)-(\d\d\d\d)$/', $dat, $matches))
     return "FALSO";
    
    elseif (($matches[1]>=1 && $matches[1]<=12) and  ($matches[2]>=1 && $matches[2]<=31) and ($matches[3]>=1970 && $matches[2]<=2030)) 
   {
   $dob1=trim($data);
   list($m, $d, $y) = explode('-', $dob1);
   $mk=mktime(0, 0, 0, $m, $d, $y);
   $dat=strftime('%Y-%m-%d',$mk);
   return $dat; 
   }
   return "FALSO";
} //function


function check_input_int($data)
{
   $data = (int)$data;
  if(!is_int($data))
    return "FALSO";
  else
    return $data;
}

function check_input_float($data)
{
  $data = (float) $data;
  if(!is_float($data))
 return "FALSO";
 else
 return $data;
}

function check_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data);
    return $data;
}


?>

</div>
</body>

</html>






