<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, createSequence.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Sequence MetaInfo</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSequence.php">Update</a></li> 
<li><a href="consultSequence.php">Consult</a></li> 
<li><a href="helpSequence.php">Help</a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<BR>&nbsp;<BR>
<BR>&nbsp;<BR>
<BR>&nbsp;<BR>

<?php
session_start();
if ($_SESSION['testStore'] != $_POST['testStore']) {
   echo '<div id="error">'. "Not allowed to duplicate the information.";
}
else
{
 $_SESSION['testStore'] = null;
$_SESSION['form2']= $_POST; 
include_once('../configUser.inc'); 


$_SESSION['new']="1"; //22 vars
$_SESSION['Specimen_UID_req']		= $_POST['Specimen_UID_req'];
$_SESSION['Specimen_UID_sec']		= $_POST['Specimen_UID_sec'];
$_SESSION['Sample_UID_req']		= $_POST['Sample_UID_req'];
$_SESSION['Sequence_Lane_req']		= $_POST['Sequence_Lane_req'];
$_SESSION['Sequence_Data ']		= $_POST['Sequence_Data'];
$_SESSION['Date_Sample_Submitted']	= $_POST['Date_Sample_Submitted'];
$_SESSION['Sequencing_Provider']	= $_POST['Sequencing_Provider'];
$_SESSION['Sequencing_Platform']	= $_POST['Sequencing_Platform'];
$_SESSION['Project']			= $_POST['Project'];
$_SESSION['Run_Plexing']		= $_POST['Run_Plexing'];
//$_SESSION['Primer_Set']			= $_POST['Primer_Set_Name'];
//$_SESSION['Barcode_Type']		= $_POST['Barcode_Type'];
//$_SESSION['Barcode']			= $_POST['Barcode_Name'];
//$_SESSION['Primer_Name']		= $_POST['Primer_Name'];
$_SESSION['Date_Run_Performed']		= $_POST['Date_Run_Performed'];
$_SESSION['Run_Number']			= $_POST['Run_Number'];
$_SESSION['Date_Data_Received']		= $_POST['Date_Data_Received'];
$_SESSION['Total_Reads_Millions']	= $_POST['Total_Reads_Millions'];
$_SESSION['Read_Type']			= $_POST['Read_Type'];
$_SESSION['Read_Length_Bases']		= $_POST['Read_Length_Bases'];
$_SESSION['Total_Bases_Billions']	= $_POST['Total_Bases_Billions'];
$_SESSION['Remarks']			= $_POST['Remarks'];


if (valid_info()) 
{ 


// Now check that the information is valid echo $Specimen_UID_req1;
$Specimen_UID_req1 = check_input($_POST['Specimen_UID_req']);
$Sample_UID_req1 = check_input($_POST['Sample_UID_req']);
$pieces = explode("=", $Sample_UID_req1);

$Sample_UID_req1= $pieces[0];
$Sample_Alias_req1= $pieces[1];

$Sequencing_Platform1 =  check_input($_POST['Sequencing_Platform']);

$Sequencing_Provider1 = check_input($_POST['Sequencing_Provider']);

$Project1 = check_input($_POST['Project']);

if(!empty($_POST['Sequence_Lane_req'])){
$Sequence_Lane_req1 =check_input_int ($_POST['Sequence_Lane_req']);}
else $Sequence_Lane_req1 = '';

if(!empty($_POST['Specimen_UID_sec'])){
$Specimen_UID_sec1 =check_input ($_POST['Specimen_UID_sec']);}
else $Specimen_UID_sec1 = '';

if(!empty($_POST['Date_Sample_Submitted'])){
$Date_Sample_Submitted1 = check_date($_POST['Date_Sample_Submitted']);}
else $Date_Sample_Submitted1 ='';


if(!empty($_POST['Run_Plexing']) && ($_POST['Run_Plexing'] !="Â ") ){
$Run_Plexing1 = check_input($_POST['Run_Plexing']);}
else $Run_Plexing1 = '';

if(!empty($_POST['Date_Run_Performed'])){
$Date_Run_Performed1 = check_date($_POST['Date_Run_Performed']);}
else $Date_Run_Performed1 = '';

if(!empty($_POST['Run_Number'])){
$Run_Number1 = check_input_int($_POST['Run_Number']);}
else $Run_Number1 = '';

if(!empty($_POST['Date_Data_Received'])){
$Date_Data_Received1 = check_date($_POST['Date_Data_Received']);}
else $Date_Data_Received1 = '';

if(!empty($_POST['Total_Reads_Millions'])){
$Total_Reads_Millions1 = check_input_float($_POST['Total_Reads_Millions']);}
else $Total_Reads_Millions1 = '';

if(!empty($_POST['Read_Type'])){
$Read_Type1 = check_input($_POST['Read_Type']);}
else $Read_Type1 = '';

if(!empty($_POST['Read_Length_Bases'])){
$Read_Length_Bases1 = check_input_int($_POST['Read_Length_Bases']);}
else $Read_Length_Bases1 = '';

if(!empty($_POST['Total_Bases_Billions'])){
$Total_Bases_Billions1 = check_input_int($_POST['Total_Bases_Billions']);}
else $Total_Bases_Billions1 = '';

if(!empty($_POST['Remarks'])){
$Remarks1 =  check_input($_POST['Remarks']);}
else $Remarks1 = '';

if(!empty($_POST['ProviderSeqDirName'])){
$ProviderSeqDirName1 =  check_input($_POST['ProviderSeqDirName']);}
else $ProviderSeqDirName1 = '';

if(!empty($_POST['fastqMatePair1'])){
$fastqMatePair1_1 =  check_input($_POST['fastqMatePair1']);}
else $fastqMatePair1_1 = '';

if(!empty($_POST['fastqMatePair2'])){
$fastqMatePair2_1 =  check_input($_POST['fastqMatePair2']);}
else $fastqMatePair2_1 = '';

 //start upload
if(!empty($_FILES['Experimentalists_notes_upload']['name']))
{  
  if ($_FILES["Experimentalists_notes_upload"]["size"] < 100000 && $_FILES["Experimentalists_notes_upload"]["type"]=="text/plain")
    { 
   
     if ($_FILES["Experimentalists_notes_upload"]["error"] > 0)
  {
 $error[12] = urlencode('Please enter a valid file.');
 echo '<div id="error">' . $error[12];
 echo '<div id="error">' . $_FILES["Experimentalists_notes_upload"]["error"] . "<br />";
  }

 else
   {
     $uploadfile1 = $_FILES['Experimentalists_notes_upload']['tmp_name'];   //tmp name selected in directory
     $Experimentalists_notes_upload1 = $_FILES['Experimentalists_notes_upload']['name'];       //name selected in directory
     $filetype1  = $_FILES['Experimentalists_notes_upload']['type'];       // type of file
     $fileuploaded1 = file_get_contents($uploadfile1);  
    
     // Prepare user-submitted values for safe database insert
     $fileuploaded1 = check_input($fileuploaded1);
     $filetype1 = check_input($filetype1);
     $Experimentalists_notes_upload1 =check_input($Experimentalists_notes_upload1);
   }       
  } //if - test size
  else {echo '<div id="error">' . "No file uploaded: size or file type incorrect.";}
}//if - non empty
else 
{
$Experimentalists_notes_upload1='';
$fileuploaded1 = '';
$filetype1 = '';
}
//end upload


 if (empty($error)) {

include_once '../config.inc'; //data for the connection
$db = mysql_connect($hostname, $username, $password) or  die ('Unable to connect. Check your connection parameters.');

//make sure you're using the correct database
 $db1 = mysql_select_db($dbname, $db) or die(mysql_error($db));


$query1 = 'SELECT COUNT(Sample_UID_req) AS Uid FROM HPMB_SequenceMetaInfo WHERE Sample_UID_req="' .$Sample_UID_req1 . '" GROUP by track_id '; 

 $result1 = mysql_query($query1,$db) or die(mysql_error($db));
  if (!$result1)
  {
   $total = 1;
  }
  else
   {
    $row = mysql_fetch_array($result1);
    $total =mysql_num_rows($result1); 
   }
if ($total == 0)
{
$total = 1;
}
else
{

$query2 = 'SELECT * FROM HPMB_SequenceMetaInfo WHERE Sample_UID_req = "' .$Sample_UID_req1 .'" AND track_id = "'
 . $total .'"'; 

$result2 = mysql_query($query2,$db) or die(mysql_error());
  if (!$result2)

 {
    $total = 1;
  }
  else
    {
     $row = mysql_fetch_array($result2);
     $total = $row['track_id'] + 1;
    }  
 }

$Sequence_UID_temp = create_id($Sample_UID_req1);
$SequenceRun_ID_req1 = $Sequence_UID_temp.$total ;

$Sequence_Date_temp = date("m-d-y_H:i:s", time()) ;

$query = 'SELECT COUNT(SequenceRun_ID_req) FROM HPMB_SequenceMetaInfo GROUP by SequenceRun_ID_req ;'; 

 $result = mysql_query($query, $db) or die(mysql_error($db));
  if (!$result)
  {
    echo 'Error counting records from database.';
    exit();
  }
    $row0 = mysql_fetch_array($result);
    $total0 =mysql_num_rows($result);

if ($total0 == 0)
$total0 = 1;
else 
 $total0 = $total0 + 1;

$track_exp1 = $total0 ;
 //get the UID for this seq
 
 $Experiment_Name_req1= create_expname($_SESSION['usernam'],$track_exp1);
 $Sequence_Data1 = $Experiment_Name_req1;

//make sure that the fields Library_Preparation_ID_req, Barcode, Barcode_Type, Primer_Set, Primer_Name are updated from sample
$query4 = 'SELECT Library_Preparation_ID_req, Barcode, Barcode_Type, Primer_Set, Primer_Name, timemodified FROM HPMB_SampleProcessing WHERE Sample_UID_req = "' .$Sample_UID_req1 . '" ORDER by timemodified desc LIMIT 1 ';

$result4 = mysql_query($query4,$db) or die(mysql_error());
  if (!$result4)

 {
    $libr1 = '' ;
    $Barcode_Name1 ='';
    $Barcode_Type1 ='';
    $Primer_Set1   ='';
    $Primer_Name1  ='';
  }
  else
    {
     $row = mysql_fetch_array($result4);
     $libr1 = $row['Library_Preparation_ID_req'] ;
     $Barcode_Name1 = $row['Barcode'] ;
     $Barcode_Type1 = $row['Barcode_Type'] ;
     $Primer_Set1   = $row['Primer_Set'] ;
     $Primer_Name1  = $row['Primer_Name'] ;
    }  
 $Sequence_Data_Point1='';  

  // insert data into
 $query3 = 'INSERT INTO HPMB_SequenceMetaInfo SET
   Experiment_Name_req	="' . $Experiment_Name_req1 . '",
   Specimen_UID_req     ="' . $Specimen_UID_req1 . '",
   Specimen_UID_sec     ="' . $Specimen_UID_sec1 . '",
   Sample_UID_req       ="' . $Sample_UID_req1 . '",
   Sample_Alias_req     ="' . $Sample_Alias_req1 . '",
   SequenceRun_ID_req   ="' . $SequenceRun_ID_req1 . '",
   Sequence_Lane_req    ="' . $Sequence_Lane_req1 . '",
   Sequence_Data        ="' . $Sequence_Data1 . '",
   Sequence_Data_Point  ="' . $Sequence_Data_Point1 . '",
   Date_Sample_Submitted="' . $Date_Sample_Submitted1 . '",
   Sequencing_Provider  ="' . $Sequencing_Provider1 . '",
   ProviderSeqDirName 	="' . $ProviderSeqDirName1 . '",
   fastqMatePair1 	="' . $fastqMatePair1_1 . '",
   fastqMatePair2       ="' . $fastqMatePair2_1 . '",
   Sequencing_Platform  ="' . $Sequencing_Platform1 . '",
   Project              ="' . $Project1 . '",
   Run_Plexing          ="' . $Run_Plexing1  . '",
   Primer_Set           ="' . $Primer_Set1  . '",
   Barcode_Type         ="' . $Barcode_Type1  . '",
   Barcode              ="' . $Barcode_Name1  . '",
   Library_Preparation_ID_req="' . $libr1  . '",
   Primer_Name          ="' . $Primer_Name1  . '",
   Date_Run_Performed   ="' . $Date_Run_Performed1 . '",
   Run_Number           ="' . $Run_Number1  . '",
   Date_Data_Received   ="' . $Date_Data_Received1 . '",
   Total_Reads_Millions ="' . $Total_Reads_Millions1 . '",
   Read_Type            ="' . $Read_Type1 . '",
   Read_Length_Bases    ="' . $Read_Length_Bases1 . '",
   Total_Bases_Billions ="' . $Total_Bases_Billions1 . '",
   Experimentalists_notes_upload = "' . $Experimentalists_notes_upload1 . '",
   fileuploaded         = "' . $fileuploaded1 . '",
   filetype             = "' . $filetype1 . '",
   Remarks              = "' . $Remarks1  . '",
   createdby            = "' . $_SESSION['usernam'] . '",  
   timecreation         = NOW(), 
   modifiedby           = NULL, 
   timemodified         ="' . '0000-00-0000:00:00' .'",
   track_id             ="' . $total .'",
   track_exp            ="' . $track_exp1 .'",
   track_sequence           = 1';

$result3 = mysql_query($query3, $db) or die(mysql_error($db));

echo '<div id="messages">' . 'New sequence run metadata record created! Sequence Run ID = ' . $SequenceRun_ID_req1 . ' and the Unique Experiment Name is = ' .$Experiment_Name_req1  ;



//Creating directories for analysis -to store input and output files-.
  if ($Read_Type1 == 'paired-end')
  {
    include_once('../configDir.inc'); 
    $dir1="mkdir ".$newSeqDir."INFILE/".$Experiment_Name_req1;
    $dir2="mkdir ".$newSeqDir."INFILE/".$Experiment_Name_req1."/PAIR1";
    $dir3="mkdir ".$newSeqDir."INFILE/".$Experiment_Name_req1;
    $dir4="mkdir ".$newSeqDir."INFILE/".$Experiment_Name_req1."/PAIR2";
    $outdir1=shell_exec($dir1);
    $outdir2=shell_exec($dir2);	
    $outdir3=shell_exec($dir3);
    $outdir4=shell_exec($dir4);
	
    $dir5="mkdir ". $newSeqDir."OUTFILE/".$Experiment_Name_req1;
    $dir6="mkdir ". $newSeqDir."OUTFILE/".$Experiment_Name_req1."/PAIR1";
    $dir7="mkdir ". $newSeqDir."OUTFILE/".$Experiment_Name_req1;
    $dir8="mkdir ". $newSeqDir."OUTFILE/".$Experiment_Name_req1."/PAIR2";
    $outdir5=shell_exec($dir5);
    $outdir6=shell_exec($dir6);	
    $outdir7=shell_exec($dir7);
    $outdir8=shell_exec($dir8);	
  }
  else
   {include_once('../configDir.inc'); 
    $dir1="mkdir ".$newSeqDir."INFILE/".$Experiment_Name_req1;
    $outdir1=shell_exec($dir1);
    $dir2="mkdir ".$newSeqDir."OUTFILE/".$Experiment_Name_req1;
    $outdir2=shell_exec($dir2);	
   }
} //if no error
}//else if valid
} //no duplicate
?>

</div>
</body>

</html>

<?php
function valid_info() //required
{

$error = '';
if(empty($_POST['Specimen_UID_req'])) {
$error = urlencode('Please enter a Specimen UID.');
echo '<div id="error">' . $error;
}

if(empty($_POST['Sample_UID_req'])){
$error = urlencode('Please enter a Sample UID.');
echo '<div id="error">' . $error;
}

if(empty($_POST['Sequencing_Provider'])){
$error = urlencode('Please enter a Sequencing Provider.');
echo '<div id="error">' . $error;
}

if(empty($_POST['Sequencing_Platform'])){
$error = urlencode('Please enter a Sequencing Platform.');
echo '<div id="error">' . $error;
}

if(empty($_POST['Project'])){
$error = urlencode('Please enter a Project.');
echo '<div id="error">' . $error;
}



if (empty($error)) 
     return TRUE;
else 
   return FALSE;
}// valid_info


function check_date($data)
{

    if(!preg_match('/^(\d\d?)-(\d\d?)-(\d\d\d\d)$/', $data, $matches))
     return "FALSO";
    
    elseif (($matches[1]>=1 && $matches[1]<=12) and  ($matches[2]>=1 && $matches[2]<=31) and ($matches[3]>=1970 && $matches[2]<=2030)) 
   {
   $dob1=trim($data);
   list($m, $d, $y) = explode('-', $dob1);
   $mk=mktime(0, 0, 0, $m, $d, $y);
   $data=strftime('%Y-%m-%d',$mk);
   return $data; 
   }
   return "FALSO";
} //function


function check_input_int($data)
{
  $data = (int) $data;
  if(!is_int($data))
 return "FALSO";
 else
 return $data;
}

function check_input_float($data)
{
  $data = (float) $data;
  if(!is_float($data))
 return "FALSO";
 else
 return $data;
}

function check_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data);
    return $data;
}


function check_input1($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data);
    $findme   = ' ';
    $pos = strpos($data, $findme);
    if ($pos !== false) { 
          return "FALSO"; 
          } else {
          return $data; 
  }
}

function check_inputExp($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data);
    $findme   = ' ';
    $pos = strpos($data, $findme);
    if ($pos !== false) { 
          return "FALSO"; 
          } else {  
                
                return $data;   
  }
}


function create_id($res)
{
$result = $res . "_0";
return $result;
}

function create_expname($usuario,$numero)
{
$result = strtoupper(substr($usuario,0,3))."_$numero";
return $result;
}


?>

