<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, sequenceAdd.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/

session_start();
$testStg=md5('salt'.microtime());
$_SESSION['testStore']=$testStg;
$_SESSION['form2']= $_POST; 
include_once '../configUser.inc';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Sequence MetaInfo</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSequence.php">Update</a></li> 
<li><a href="consultSequence.php">Consult</a></li> 
<li><a href="helpSequence.php">Help</a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<?php


if  ($_SESSION['new']=="1"){

$spec1 = $_SESSION['Specimen_UID_req'];
$spec2 = $_SESSION['Specimen_UID_sec'];
$samp  = $_SESSION['Sample_UID_req'];
$seq1  = $_SESSION['Sequence_Lane_req'];
//$seq2  contains the directory name for the sequence, generated automatically
$dats  = $_SESSION['Date_Sample_Submitted'];
$seq3  = $_SESSION['Sequencing_Provider'];
$seq4  = $_SESSION['Sequencing_Platform'];
$provdir = $_SESSION['ProviderSeqDirName'];
$pair1 =  $_SESSION['fastqMatePair1'];
$pair2 =  $_SESSION['fastqMatePair2'];
$proj  = $_SESSION['Project'];
$runp  = $_SESSION['Run_Plexing'];
$datr  = $_SESSION['Date_Run_Performed'];
$runn  = $_SESSION['Run_Number'];
$datd  = $_SESSION['Date_Data_Received'];
$totr  = $_SESSION['Total_Reads_Millions'];
$readt = $_SESSION['Read_Type'];
$readl = $_SESSION['Read_Length_Bases'];
$totb  = $_SESSION['Total_Bases_Billions'];
$rem   = $_SESSION['Remarks'];


} 
 else 
 { 
  $spec1 = '';
  $spec2 = '';
  $samp  = '';
  $seq1  = '';
  $dats  = '';
  $seq3  = '';
  $seq4  = '';
  $provdir = '';
  $pair1 = '';
  $pair2 = '';
  $proj  = '';
  $runp  = '';
  $datr  = '';
  $runn  = '';
  $datd  = '';
  $totr  = '';
  $readt = '';
  $readl = '';
  $totb  = '';
  $rem   = '';
}

include_once '../config.inc'; //data for the connection
$db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//Using the correct database
$db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));

$sql="SELECT Sample_UID_req, Sample_Alias_req FROM (SELECT Sample_UID_req, Sample_Alias_req, timemodified FROM HPMB_SampleProcessing ORDER BY timemodified desc ) AS temp GROUP BY Sample_UID_req";
$result2=mysql_query($sql);


$sql1="SELECT Specimen_UID_req FROM HPMB_SpecimenInfo GROUP by Specimen_UID_req";
$result=mysql_query($sql1);
$result1=mysql_query($sql1);
?>



<title> Add Sequence </title>
</head>

<body>
         <BR>&nbsp;<BR>
         <form id="form2" action="createSequence.php" method="post" enctype="multipart/form-data">     
         
         

              <h3><span> Add Sequence</span></h3>

         

              <fieldset><legend>Create Sequence</legend>

<p>
  <select name=Sample_UID_req>
 <option value="<?php if ($samp !='') echo $samp ;?>">Sample UID = Sample Alias (*). (*) REQUIRED : <?php if ($samp !='') echo $samp;?></option>
<?php
while ($row2 = mysql_fetch_array($result2)) {
?>
<option value="<?php echo $row2['Sample_UID_req']. "=" .$row2['Sample_Alias_req'] ; ?>"><?php echo $row2['Sample_UID_req']. "=" .$row2['Sample_Alias_req']; ?></option>
<?php } ?> 
</select>
</p>

<p>
  <select name=Specimen_UID_req>
 <option value=<?php if ($spec1 !='') echo $spec1 ;?>>Specimen UID (*) : <?php if ($spec1 !='') echo $spec1;?></option>
<?php
while ($row = mysql_fetch_array($result)) {
?>
<option value=<?php echo $row['Specimen_UID_req']; ?>><?php echo $row['Specimen_UID_req']; ?></option>
<?php } ?> 
</select>
</p>

<p>
  <select name=Specimen_UID_sec>
 <option value=<?php if ($spec2 !='') echo $spec2 ;?>>Specimen UID secondary : <?php if ($spec2 !='') echo $spec2;?></option>
<?php
while ($row1 = mysql_fetch_array($result1)) {
?>
<option value=<?php echo $row1['Specimen_UID_req']; ?>><?php echo $row1['Specimen_UID_req']; ?></option>
<?php } ?> 
</select>
</p>     
                 
                     <p>
                       <select name=Sequencing_Provider>
                       <option VALUE=<?php echo $seq3; ?>  >Sequencing Provider (*) : <?php echo $seq3; ?>  
                       <option value="Other">Other</option>
                       </select>
                   </p>                         

                   <p>
                     <p>
                       <select name=Sequencing_Platform>
                       <option VALUE=<?php echo $seq4; ?>  >Sequencing Platform (*) : <?php echo $seq4; ?>  
                       <option value="HiSeq2000">HiSeq2000</option>
                       <option value="GAllx">GAllx</option>
                       <option value="MiSeq">MiSeq</option>
                       <option value="Sanger">Sanger</option>
                       <option value="454">454</option>
                       <option value="Ion Torrent">Ion Torrent</option>
                       <option value="PacBio">PacBio</option>
                       <option value="SOLiD">SOLiD</option>
                       </select>
                   </p> 
                 <p>
                       <select name=Project>
                       <option VALUE=<?php echo $proj; ?> >Project (*) :<?php echo $proj; ?>  
                       <option value="Other">Other</option>
                       </select>
                   </p>   
                        

                   <p>
                        <label for="ProviderSeqDirName">Provider Sequence Directory Name </label>
                        <input type="text" size="100" maxlength="100" name="ProviderSeqDirName" id="ProviderSeqDirName" value="<?php if ($provdir !='') echo $provdir; ?>"  />
                   </p>

                   <p>
                        <label for="fastqMatePair1">Fastq file Mate Pair 1</label>
                        <input type="text" size="50" maxlength="50" name="fastqMatePair1" id="fastqMatePair1" value="<?php if ($pair1 !='') echo $pair1; ?>"  />
                   </p>

                   <p>
                        <label for="fastqMatePair2">Fastq file Mate Pair 2</label>
                        <input type="text" size="50" maxlength="50" name="fastqMatePair2" id="fastqMatePair2" value="<?php if ($pair2 !='') echo $pair2; ?>"  />
                   </p>

                   <p>
                        <label for="Sequence_Lane_req">Sequence Lane  </label>
                        <input type="text" size="11" maxlength="11" name="Sequence_Lane_req" id="Sequence_Lane_req" value="<?php if ($seq1 !='') echo $seq1; ?>  "/>
                   </p>   

                     <p>
                        <label for="Date_Sample_Submitted">Date Sample Submitted. Format (mm-dd-yyyy)</label>
                        <input type="text" size="10" maxlength="10" name="Date_Sample_Submitted" id="Date_Sample_Submitted" value="<?php if ($dats !='') echo $dats; ?>  "/>
                    <p>                                                                                                         


                   <p>
                        <label for="Run_Plexing">Run Plexing</label>
                        <input type="text" size="100" maxlength="100" name="Run_Plexing" id="Run_Plexing" value="<?php if ($runp !='') echo $runp; ?>"  />
                   </p>


                    <p>
                        <label for="Date_Run_Performed">Date Run Performed. Format (mm-dd-yyyy)</label>
                        <input type="text" size="10" maxlength="10" name="Date_Run_Performed" id="Date_Run_Performed" value="<?php if ($datr !='') echo $datr; ?> "/>
                   </p>     
<p>

                        <label for="Run_Number">Run Number</label>

                        <input type="text" size="11" maxlength="11" name="Run_Number" id="Run_Number" value="<?php if ($runn !='') echo $runn; ?> "/>

                   </p>     
<p>
                        <label for="Date_Data_Received">Date Data Received. Format (mm-dd-yyyy)</label>
                        <input type="text" size="10" maxlength="10" name="Date_Data_Received" id="Date_Data_Received" value="<?php if ($datd !='') echo $datd; ?> "/>

                   </p>  
<p>
                        <label for="Total_Reads_Millions">Total Reads Millions</label>

                        <input type="text" size="10" maxlength="10" name="Total_Reads_Millions" id="Total_Reads_Millions" value="<?php if ($totr !='') echo $totr; ?> "/>

                   </p>

                   <p>
                     <select name=Read_Type>
                       <option VALUE=<?php echo $readt; ?>  >Read Type: <?php echo $readt; ?>  
                       <option value="single-end">single-end</option>
                       <option value="paired-end">paired-end</option>
                     </select>
                   </p>     

                     <p>
                       <select name=Read_Length_Bases>
                       <option VALUE=<?php echo $readl; ?>  >Read Length Bases: <?php echo $readl; ?>  
                       <option value="35">35</option>
                       <option value="51">51</option>
                       <option value="75">75</option>
                       <option value="100">100</option>
                       <option value="150">150</option>
  		       <option value="Other">Other</option>
                       </select>
                   </p>      

                  
		   <p>
                        <label for="Total_Bases_Billions">Total Bases Billions</label>
                        <input type="text" size="11" maxlength="11" name="Total_Bases_Billions" id="Total_Bases_Billions" value="<?php if ($totb !='') echo $totb; ?> "/>
                   </p>      

		   <p>
                        <label for="Experimentalists_notes_upload">Upload notes: </label>
                        <input type="file" accept="text/txt" name="Experimentalists_notes_upload" id="Experimentalists_notes_upload" />
                   </p>     

                   <p>
               		 <input type="hidden" name="testStore" value=<?php echo $testStg ;?> />     
		   </p>
       
                    <p class="submit"><button type="submit">Add Sequence</button></p>   
                          
                   <input type="hidden" name="submit" value="1"/>
                   

              </fieldset>                         

                             

         </form>     

  </body>
</html>


