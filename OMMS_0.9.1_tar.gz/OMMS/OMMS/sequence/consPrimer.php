<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, consPrimer.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone"></h1> 
<h2 class="lineone">Omics Metadata Management Software </h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSequence.php">Update</a></li> 
<li><a href="consultSequence.php">Consult</a></li> 
<li><a href="helpSequence.php">Help</a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<BR>&nbsp;<BR>

<?php 
$string = $_GET['id'];
$error = array();
if (!empty($string)){
    $data = trim($string);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $Primer_Name = htmlspecialchars($data);
   
 if (empty($error)) { 

  include_once '../config.inc'; //data for the connection
  $db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

  //Using the correct database
   $db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));

  $query2 = 'SELECT * FROM Primers WHERE Primer_Name = "' . $data . '" '; 

  $result2 = mysql_query($query2,$db) or die(mysql_error());
  if (!$result2)
  {
    echo '<div id="error">' . 'Error no such record exist from database.';
    exit();
  }
 
     $total =mysql_num_rows($result2);
 if ($total == 0)
 {
 echo '<div id="error">' . 'Error no such record exist from database.';
 exit();
 }
 echo "<table border='1'>
<tr>
</tr>";

while($row = mysql_fetch_array($result2))
  {
  echo "<tr>";
  echo "<th>Primer Name </th>";
  echo "<td>" . $row['Primer_Name'] . "</td>";
  echo "<tr>";
  echo "<th>Primer Sequence </th>";
  echo "<td>" . $row['Primer_Sequence'] . "</td>";
  echo "<tr>";
  echo " <th>Notes </th>";
  echo "<td>" . $row['Primer_Notes'] . "</td>";
  echo "<tr>";
  }
echo "</table>";
?>

<?php
mysql_close($db);



}//empty errors array
} //else no empty UID
?>

