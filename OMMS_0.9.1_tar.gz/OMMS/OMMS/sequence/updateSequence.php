<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, updateSequence.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Sequence MetaInfo</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSequence.php">Update</a></li> 
<li><a href="consultSequence.php">Consult</a></li> 
<li><a href="helpSequence.php">Help</a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<BR>&nbsp;<BR>

<?php
session_start();
$_SESSION['form2']= $_POST; 
include_once '../configUser.inc';

if(isset($_POST['SequenceRun_ID_req']) )
{
$_SESSION['SequenceRun_ID_req'] = $_POST['SequenceRun_ID_req'];

} 
 else 
 {
$_SESSION['SequenceRun_ID_req'] ='';
}


echo "<h3><span>Update Sequence MetaInfo</span></h3>";
echo '<div id="messages2">' . 'Select the Sequence Run ID to Update ';
echo "<table border='1'>
<tr> 
 <th>Sequence Run ID </th>
  <th>Sample Alias </th>
  <th>Results folder </th>
  <th>Date Sample Submitted </th>
  <th>Library Name </th>
  <th>Barcode </th>
  <th>File Pair1 </th>
  <th>File Pair2 </th>
  <th>Sequencing Provider </th>
  <th>Run Plexing </th>
  <th>Upload Complete    </th>
</tr>";

include_once '../config.inc'; //data for the connection
$db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//Using the correct database
$db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));

$result = mysql_query("SELECT SequenceRun_ID_req, Sample_Alias_req, Experiment_Name_req, Date_Sample_Submitted, Library_Preparation_ID_req, Barcode, fastqMatePair1, fastqMatePair2, Sequencing_Provider, Run_Plexing,  Received FROM (SELECT SequenceRun_ID_req, Sample_Alias_req, Experiment_Name_req, Date_Sample_Submitted, Library_Preparation_ID_req, Barcode, fastqMatePair1, fastqMatePair2, Sequencing_Provider, Run_Plexing,  Received, track_sequence FROM HPMB_SequenceMetaInfo ORDER BY SequenceRun_ID_req, track_sequence DESC) AS temp GROUP BY SequenceRun_ID_req", $db);

while (list($SequenceRun_ID_req, $Sample_Alias_req, $Experiment_Name_req, $Date_Sample_Submitted, $Library_Preparation_ID_req, $Barcode, $fastqMatePair1, $fastqMatePair2,  $Sequencing_Provider, $Run_Plexing,  $Received) = mysql_fetch_row($result)) {
    echo " <tr>\n" ;
      echo "  <td><a href=\"upd2.php?id=$SequenceRun_ID_req\">$SequenceRun_ID_req</a></td>\n" .
          "   <td>$Sample_Alias_req</td>\n" .
          "   <td>$Experiment_Name_req</td>\n" .
          "   <td>$Date_Sample_Submitted</td>\n" .
          "   <td>$Library_Preparation_ID_req</td>\n" .
          "   <td>$Barcode</td>\n" .
          "   <td>$fastqMatePair1</td>\n" .
          "   <td>$fastqMatePair2</td>\n" .
          "   <td>$Sequencing_Provider</td>\n" .
          "   <td>$Run_Plexing</td>\n" .
          "  <td>$Received</a></td>\n" .
          " </tr>\n";
}

?>



