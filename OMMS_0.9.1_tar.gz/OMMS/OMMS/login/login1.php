<?php
/*
Copyright 2012, Martha Perez-Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, login1.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
  <head>
    <title>Log in</title>
    <meta http-equiv="content-type"
        content="text/html; charset=utf-8"/>
   <link rel="stylesheet" type="text/css" href="../style.css" /> 
<head>
<?php


  if (isset($_POST['action'])  and $_POST['action'] == 'login')
  {
    if (valid_info()) 
{ 
    
  
include_once '../config.inc'; //data for the connection

  $db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//Using the correct database
 $db1 = mysql_select_db($dbname, $db) or die(mysql_error($db));
 $username = check_input($_POST['username']);
 $password = md5(check_input($_POST['password']));

  $sql = "SELECT username, password FROM user
      WHERE username='$username' AND password='$password'";

  $result1 = mysql_query($sql,$db) or die(mysql_error($db));
  $row = mysql_fetch_array($result1);

  if ($row['password'] != $password)
  {
      unset($_SESSION['loggedIn']);
      unset($_SESSION['username']);
      unset($_SESSION['password']);
      $_SESSION['loggedIn'] = FALSE;
      $error= 'The specified user name or password was incorrect.';
             echo '<div id="error">' . $error;
      $_SESSION['loggedIn']=FALSE;
  }
  else
    {
   session_start();
      $_SESSION['loggedIn'] = TRUE;
      $_SESSION['usernam'] = $_POST['username'];
      $_SESSION['password'] = $_POST['password'];
      $error= 'You are connected to the systsem: ';
      echo '<div id="error">' . $_SESSION['username'] ;
      header('Location: ../index.rap.php' );
      $_SESSION['loggedIn']=TRUE;
    }

} //valid
} //if 'action' = login


function valid_info()
{ 
$error='';
if (!isset($_POST['username']) or $_POST['username'] == '' or
      !isset($_POST['password']) or $_POST['password'] == '')
    {
      $error = 'Please fill in both fields';
      echo '<div id="error">' . $error;
   
    }
   
  if (empty($error)) 
    return TRUE;
  else 
  return FALSE; 
}


function check_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>
