<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, download1.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/

session_start(); 
//data for valid user and session
include_once '../configUser.inc'; 
$string = $_GET['id'];
$error = array();
if (!empty($string)){
    $data = trim($string);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $SequenceRun_ID_req = htmlspecialchars($data);
    $pieces = explode("-", $SequenceRun_ID_req);
    $SequenceRun_ID_req= $pieces[0];
    $ticket= $pieces[1];

 if (empty($error)) { 
  include_once '../config.inc'; //data for the connection
  $db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

  //Using the correct database
  $db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));

  $query2 = 'SELECT * FROM Analysis_Configuration WHERE SequenceRun_ID_req = "' . $SequenceRun_ID_req . '" AND ticket = "' . $ticket . '" '; 


  $result2 = mysql_query($query2,$db) or die(mysql_error());

  if (!$result2)
  {
    echo '<div id="error">' . 'Error no such record exist from database.';
    exit();
  }
   $row = mysql_fetch_array($result2);

   $name="$row[Result_Alignment]";
   $bowt2="$row[bowtie2]";
   $toph="$row[tophat]";

  if ($bowt2 == 'yes')
    {$name .= '.sam';}
  if ($toph == 'yes')
    {$name .= '/tophat_out/accepted_hits.bam';}

  mysql_close($db);

  $name1=$name;


$type="application/octet-stream"; // file type
header("Pragma: public");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Cache-Control: public");
header("Content-Description: File Transfer");
header("Content-Type: " . $type);
header("Content-Length: " .(string)(filesize($name1)) );
header('Content-Disposition: attachment; filename="'.basename($name1).'"');
header("Content-Transfer-Encoding: binary\n");
readfile($name1);
exit();


}//empty errors array
} //else no empty UID


?>
