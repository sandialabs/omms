<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, detailedInfo.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Results</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul>  
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li id="active"><a href="result.php" id="current">Results</a></li>
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<BR>&nbsp;<BR>


<?php

    session_start(); 
//data for valid user and session
include_once '../configUser.inc'; 
$string = $_GET['id'];
$error = array();
if (!empty($string)){
    $data = trim($string);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $SequenceRun_ID_req = htmlspecialchars($data);
   
 if (empty($error)) { //check where it is closed


echo "<h3><span>Analysis Configurations for Sequence MetaInfo</span></h3>";
echo '<div id="messages2">' . 'Select the Sequence Run ID to download analysis results'; 
echo "<table border='1'>
<tr> 
  <th>Analysis Number </th>
  <th>Sequence Run ID </th>
  <th>Results </th>
  <th>Experiment Name </th>
  <th>Output format </th>
  <th>Blast </th>
  <th>Bowtie 2 </th>
  <th>TopHat </th>
  <th>Created by </th>
  <th>Time created </th>
</tr>";

include_once '../config.inc'; //data for the connection
$db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//Using the correct database
$db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));

$result = mysql_query("SELECT ticket, SequenceRun_ID_req, Result_Alignment, infileP, outputFormat, blast, bowtie2, tophat, createdby, timecreation FROM Analysis_Configuration WHERE SequenceRun_ID_req =  \"$data\" ORDER BY ticket ASC", $db);

while (list($ticket,$SequenceRun_ID_req,$Result_Alignment,$infileP,  $outputFormat, $blast, $bowtie2, $tophat, $createdby, $timecreation) = mysql_fetch_row($result)) {
    echo " <tr>\n" ;
      echo "  <td><a href=\"download1.php?id=$SequenceRun_ID_req-$ticket\">$ticket</a></td>\n" .
          "   <td>$SequenceRun_ID_req</td>\n" .
          "   <td>$Result_Alignment</td>\n" .
          "   <td>$infileP</td>\n" .  
          "   <td>$outputFormat</td>\n" .
          "   <td>$blast</td>\n" .
          "   <td>$bowtie2</td>\n" . 
 	  "   <td>$tophat</td>\n" . 
          "   <td>$createdby</td>\n" .
          "   <td>$timecreation</td>\n" .
          " </tr>\n";
}

}//error
}//empty string
?>
