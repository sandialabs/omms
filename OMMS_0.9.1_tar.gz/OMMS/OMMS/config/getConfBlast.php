<?php
/*
Copyright 2012, Martha Perez-Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, getConfBlast.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
    session_start(); 
//data for valid user and session
include_once '../configUser.inc'; 

//default directories
include_once '../configDir.inc'; 

$_SESSION['new']="1"; 
$_SESSION['eValue']		= $_POST['eValue'];
$_SESSION['dbName']		= $_POST['dbName'];
$_SESSION['outFormat']		= $_POST['outFormat'];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Analysis - BLAST</h1>
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="pointConf.php" id="current">Select Input </a></li>
<li><a href="blastConf.php">BLAST </a></li> 
<li><a href="bowtie2Conf.php">Bowtie 2 </a></li>
<li><a href="tophatConf.php">TopHat </a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<BR>&nbsp;<BR>
<BR>&nbsp;<BR>
<BR>&nbsp;<BR>

<?php
if (valid_info()) 
{ 

$error='';
$SequenceRun_ID_req1 = $_POST['SequenceRun_ID_req'];
$infile1 = $_POST['infileP'];
$prefix1 = $_POST['prefixP'];
$server1 = $_POST['server'];
$Read_Type= $_POST['Read_Type'];
$Project1 =$_POST['Project'];
$blastType =$_POST['rundata'];
$Sequence_Data = $_POST['Sequence_Data'];
$Sequence_Data_Point = $_POST['Sequence_Data_Point'];
$ProviderSeqDirName = $_POST['ProviderSeqDirName'];
$fastqMatePair1 = $_POST['fastqMatePair1'];
$fastqMatePair2 = $_POST['fastqMatePair2'];
$eValue =  check_input($_POST['eValue']);
$dbname1 = check_input($_POST['dbName']);
$output1 = check_input_int($_POST['outFormat']);
if ($output1==20) $output1=0; 

if ($infile1 == '/') {
 $error = urlencode('Please enter a valid experiment name for this sequence to generate infile. Update Sequence MetaInfo.');
 echo '<div id="error">' . $error;
}

if ($prefix1 == '/') {
  $error = urlencode('Please enter a valid experiment name for this sequence to generate prefix. Update Sequence MetaInfo.');
  echo '<div id="error">' . $error;
}



 if (empty($error)) {

 include_once '../config.inc'; //data for the connection

 $db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

 //Using the correct database
 $db1 = mysql_select_db($dbname, $db) or die(mysql_error($db));
 $createdby1= $_SESSION['usernam'];

 $query1 = 'SELECT COUNT(SequenceRun_ID_req) FROM Analysis_Configuration WHERE SequenceRun_ID_req="' .$SequenceRun_ID_req1 . '" '; 

 $result1 = mysql_query($query1,$db) or die(mysql_error($db));
  if (!$result1)
  {
   $total = 1;
  }
  else
   {
    $row = mysql_fetch_array($result1);
    $total =mysql_result($result1, 0, 0);
   }
 if ($total == 0)
 {
 $total = 1;
 }
 else
 {

 $query2 = 'SELECT * FROM Analysis_Configuration WHERE SequenceRun_ID_req="' .$SequenceRun_ID_req1  .'" AND ticket = "'
 . $total .'"'; 

 $result2 = mysql_query($query2,$db) or die(mysql_error());
  if (!$result2)

 {
    $total = 1;
  }
  else
    {
     $row = mysql_fetch_array($result2);
     $total = $row['ticket'] + 1;
    }  
 }


$track_exp1 = $total ;

 //get the UID for this specimen
 $ticketnum = $track_exp1;
 $Sequence_Data2= $infile1."-".$total;
 	
$timecreation1=date("m-d-y_H:i:s", time()) ;
$namef= $Sequence_Data_Point.$infile1."-".$total;
$namef1=$infile1."-".$total;
$infile2 =  $Sequence_Data_Point.$infile1;
$pieces = explode("INFILE", $Sequence_Data_Point);
$Result_Alignment=$pieces[0]."OUTFILE";


if ($Read_Type == 'single-end' ) //single-end
{
        $inf1="$Sequence_Data_Point$infile1";
        $pref1= "$Result_Alignment/$infile1/$infile1-$total";
	$cmd = "$blastType -query $inf1 -db $blastdb$dbname1 -out $pref1 -outfmt $output1 -evalue $eValue " ;
        $res=shell_exec($cmd);
}

else
{
        $inf1= "$Sequence_Data_Point$infile1PAIR1/$infile1";
        $pref1 = "$Result_Alignment/$infile1/PAIR1/$infile1-$total";
        $inf2= "$Sequence_Data_Point$infile1PAIR2/$infile1";
        $pref2 = "$Result_Alignment/$infile1/PAIR2/$infile1-$total";

	$cmd1 = "$blastType -query $inf1 -db $blastdb$dbname1 -out $pref1 -outfmt $output1 -evalue $eValue " ;
        $res1=shell_exec($cmd1); 
	$cmd2 = "$blastType -query $inf2 -db $blastdb$dbname1 -out $pref2 -outfmt $output1 -evalue $eValue " ;
        $res2=shell_exec($cmd2); 
}


$tophat1 ="no";
$bowtie2_1="no";
$cuff="no";

  // insert data into Analysis_Configuration
 $query = 'INSERT INTO Analysis_Configuration SET
   SequenceRun_ID_req    ="' . $SequenceRun_ID_req1 . '",
   ticket                ="' . $ticketnum . '",
   Sequence_Data         ="' . $Sequence_Data . '",
   Sequence_Data_Point   ="' . $Sequence_Data_Point . '",
   Result_Alignment	 ="' . $pref1 . '",
   Read_Type             ="' . $Read_Type . '",
   infileP               ="' . $infile1 . '",
   prefixP               ="' . $prefix1 . '",
   outputFormat          ="' . $output1 . '",
   dbname	         ="' . $dbname1 . '",
   bin_path              ="' . $bin_path1 . '",
   bowtie2               ="' . $bowtie2_1 . '",
   processors            ="' . $processors1 . '",
   timeBT2               ="' . $timeBT2_1 . '",
   errorBW2 		 ="' . $errorBW2_1  . '",
   tophat	         ="' . $tophat1  . '",
   cufflinks             ="' . $cuff  . '",
   quality               ="' . $quality1  . '",
   blast                 ="' . $blastType . '",
   evalue                ="' . $eValue .'",
   server                ="' . $server1.'",
   timecreation          ="'.  $timecreation1 .'",  
   createdby             ="' . $createdby1 . '"';


$result = mysql_query($query, $db) or die(mysql_error($db));


echo '<div id="messages">' . 'Running blast for Sequence Run ID ' . "'$SequenceRun_ID_req1'" . '. The Blast results file is '. "'$pref1'";

?>
<BR>&nbsp;<BR>
<?php



} //if no error
}//else if valid
?>

</div>
</body>

</html>

<?php

function valid_info() //required
{
$error = '';


if(empty($_POST['infileP'])){
$error = urlencode('Please enter infile name. No spaces.');
echo '<div id="error">' . $error;
}

 if (!empty($_POST['infileP'])){
 if (check_input1($_POST['infileP']) == "FALSO"){
 $error = urlencode('Please enter a valid input file.No spaces.');
 echo '<div id="error">' . $error;
}
}

if(empty($_POST['prefixP'])){
$error = urlencode('Please enter an output file. No spaces.');
echo '<div id="error">' . $error;
}

if(!empty($_POST['prefixP'])){
     if (check_input1($_POST['prefixP']) =="FALSO"){
     $error= urlencode('Please enter a valid prefix name. No spaces.');
     echo '<div id="error">' . $error;
}


if(empty($_POST['dbName'])) {
$error = urlencode('Please select db.');
echo '<div id="error">' . $error;
}

if(empty($_POST['eValue'])){
 $error = urlencode('Please enter evalue.');
 echo '<div id="error">' . $error;
}

if(empty($_POST['outFormat'])){
 $error = urlencode('Please enter output format.');
 echo '<div id="error">' . $error;
}

}

if (empty($error)) 
     return TRUE;
else 
   return FALSE;


}// valid_info

function check_input_int($data)
{
  $data = (int) $data;
  if(!is_int($data))
 return "FALSO";
 else
 return $data;
}


function check_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data);
    return $data;
}

function check_input1($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data);
    $findme   = ' ';
    $pos = strpos($data, $findme);
    if ($pos !== false) { 
          return "FALSO"; 
          } else {
          return $data; 
  }



}


?>

</div>
</body>

</html>
