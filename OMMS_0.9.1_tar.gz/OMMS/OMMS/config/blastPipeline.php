<?php
/*
Copyright 2012, Martha Perez-Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, blastPipeline.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Analysis - BLAST</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="pointConf.php" id="current">Select Input </a></li>
<li><a href="blastConf.php">BLAST </a></li> 
<li><a href="bowtie2Conf.php">Bowtie 2 </a></li> 
<li><a href="tophatConf.php">TopHat </a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<BR>&nbsp;<BR>

<?php 
if  ($_SESSION['new']=="1"){

$eval = $_SESSION['eValue'];
$dbn = $_SESSION['dbName'];
$outfmt  = $_SESSION['outFormat'];

}

else
{
$eval = '';
$dbn = '';
$outfmt = '';
}

//default directories
 

$string = $_GET['id'];
$error = array();
if (!empty($string)){
    $data = trim($string);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $SequenceRun_ID_req = htmlspecialchars($data);
   
 if (empty($error)) { //check where it is closed

include_once '../config.inc'; //data for the connection
$db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//make sure you're using the correct database
 $db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));

$query2 = 'SELECT * FROM HPMB_SequenceMetaInfo WHERE SequenceRun_ID_req = "' . $data . '" '; 

 $result2 = mysql_query($query2,$db) or die(mysql_error());
  if (!$result2)
  {
    echo '<div id="error">' . 'Error no such record exist from database.';
    exit();
  }
   // $row = mysql_fetch_array($result2);
     $total =mysql_num_rows($result2);
if ($total == 0)
{
echo '<div id="error">' . 'Error no such record exist from database.';
exit();
}
 $SequenceRun_ID_req=$data;


while ($row2=mysql_fetch_array($result2)) {
    $Experiment_Name_req1=$row2["Experiment_Name_req"];
    $Primer1=$row2["Primer_Name"];
    $Primer_Set1=$row2["Primer_Set"];
    $Barcode1=$row2["Barcode"];
    $seqDat=$row2["Sequence_Data"];
    $seqDatPoint=$row2["Sequence_Data_Point"];
    $project=$row2["Project"];
    $prov=$row2["ProviderSeqDirName"];
    $fast1=$row2["fastqMatePair1"];
    $fast2=$row2["fastqMatePair2"];
    $Read_Type=$row2["Read_Type"]; 
    $receiv=$row2["Received"]; 
}
include_once('../configDir.inc');
$server1='draco';


}//empty errors array
} //else no empty UID
//pass the needed information for Analysis Configuration: SequenceRunID_req and Sequence_Data directory
?>

<?php

function change_date_format($data){

       list($year,$month,$day) = explode("-",$data);
       $newdata = $month."-".$day."-".$year;
       return $newdata;
}

$sql='SELECT dbname FROM dbblast ORDER by dbname';
$result=mysql_query($sql);
mysql_close($db);
?>

<BR>&nbsp;<BR>

<title> Analysis Configuration </title>
</head>

<body>
         <form id="form2" action="getConfBlast.php" method="post" enctype="multipart/form-data">     

         

              <h3><span> BLAST Options</span></h3>

              <fieldset><legend>BLAST Configuration</legend>
                        <p>
                   <label for="options"><?php echo "READ TYPE: ". $Read_Type ;?> </label>
                 </p>   

                    <p>
                        blastn <input type="radio" name="rundata" value="blastn" checked /> 
                        blastp <input type="radio" name="rundata" value="blastp"/> 
                        blastx <input type="radio" name="rundata" value="blastx"/> 
                   </p>    
    

		<p>
 		<select name=dbName>
 		<option value=<?php echo $dbn ;?>>Database (*). (*) REQUIRED :<?php echo $dbn ;?></option>
		<?php
		while ($row = mysql_fetch_array($result)) {
		?>
		<option value=<?php echo $row['dbname']; ?>><?php echo $row['dbname']; ?></option>
		<?php } ?> 
		</select>
		</p>
                 
		   <p>
                        <label for="eValue">Evalue (*)</label>

                        <input type="text" size="10" maxlength="10" name="eValue" id="eValue" value= <?php $eight = substr($eval, 0, 10); if ($eight!=0.0) echo $eight ; else echo 0.0; ?> />

                   </p>

  		 <p>
                       <select name=outFormat>
                       <option VALUE="<?php  echo $outfmt ; ?>">Output Format (*) : <?php  echo $outfmt ; ?>
                       <option value=20>pairwise</option>
  		       <option value=1>query-anchored showing identities</option>
  		       <option value=2>query-anchored no identities</option>
  		       <option value=3>flat query-anchored, show identities</option>
  		       <option value=4>flat query-anchored, no identities</option>
                       <option value=5>XML Blast output</option>
		       <option value=6>tabular</option>
                       <option value=7>tabular with comment lines</option>
                       <option value=8>Text ASN.1</option>
  		       <option value=9>Binary ASN.1</option>
                       <option value=10>Comma-separated values</option>
		       <option value=11>BLAST archive format (ASN.1)</option>
                       </select> 
                   </p>         

                                                       
            <p> 
                <input type="hidden" name="infileP" value=<?php echo $Experiment_Name_req1;?> />  
                <input type="hidden" name="prefixP" value=<?php echo $Experiment_Name_req1 ;?> />   
                <input type="hidden" name="SequenceRun_ID_req" value=<?php echo $SequenceRun_ID_req ;?> />  
                <input type="hidden" name="Primer_Set" value=<?php echo $Primer_Set1 ;?> />  
                <input type="hidden" name="Barcode" value=<?php echo $Barcode1 ;?> /> 
                <input type="hidden" name="Primer_Name" value=<?php echo $Primer1 ;?> />  
                <input type="hidden" name="Sequence_Data" value=<?php echo $seqDat;?> />  
		<input type="hidden" name="Sequence_Data_Point" value=<?php echo $seqDatPoint;?> />   
                <input type="hidden" name="ProviderSeqDirName" value=<?php echo $prov;?> />  
                <input type="hidden" name="fastqMatePair1" value=<?php echo $fast1 ;?> /> 
                <input type="hidden" name="fastqMatePair2" value=<?php echo $fast2 ;?> />  
                <input type="hidden" name="server" value=<?php echo $server1 ;?> /> 
                <input type="hidden" name="Project" value=<?php echo $project ;?> /> 
                <input type="hidden" name="Read_Type" value=<?php echo $Read_Type ;?> /> 
            </p>              
                    <p class="submit"><button type="submit">Go</button></p>            
                   <input type="hidden" name="submit" value="1"/>    
              </fieldset>                                     
         </form>     
  </body>
</html>


