<?php
/*
Copyright 2012, Martha Perez-Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, getConfTophat.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/

session_start(); 

//data for valid user and session
include_once '../configUser.inc'; 

//default directories
include_once '../configDir.inc'; 
$_SESSION['new']="1"; 
$_SESSION['cufflinks']		= $_POST['cufflinks'];
$_SESSION['dbName']		= $_POST['dbName'];

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Analysis - TopHat</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="pointConf.php" id="current">Select Input </a></li>
<li><a href="blastConf.php">BLAST </a></li> 
<li><a href="bowtie2Conf.php">Bowtie 2 </a></li>
<li><a href="tophatConf.php">TopHat </a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<BR>&nbsp;<BR>
<BR>&nbsp;<BR>
<BR>&nbsp;<BR>

<?php
if (valid_info()) 
{ 

$error='';
$SequenceRun_ID_req1 = $_POST['SequenceRun_ID_req'];
$infile1 = $_POST['infileP'];
$prefix1 = $_POST['prefixP'];
$server1 = $_POST['server'];
$Read_Type= $_POST['Read_Type'];
$Project1 =$_POST['Project'];
$output1 ="bam";
$cuff =$_POST['cufflinks'];
$Sequence_Data = $_POST['Sequence_Data'];
$Sequence_Data_Point = $_POST['Sequence_Data_Point'];
$ProviderSeqDirName = $_POST['ProviderSeqDirName'];
$fastqMatePair1 = $_POST['fastqMatePair1'];
$fastqMatePair2 = $_POST['fastqMatePair2'];

$dbname1 = check_input($_POST['dbName']);

if ($infile1 == '/') {
 $error = urlencode('Please enter a valid experiment name for this sequence to generate infile. Update Sequence MetaInfo.');
 echo '<div id="error">' . $error;
}

if ($prefix1 == '/') {
  $error = urlencode('Please enter a valid experiment name for this sequence to generate prefix. Update Sequence MetaInfo.');
  echo '<div id="error">' . $error;
}


 if (empty($error)) {

include_once '../config.inc'; //data for the connection

 $db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//make sure you're using the correct database
 $db1 = mysql_select_db($dbname, $db) or die(mysql_error($db));
$createdby1= $_SESSION['usernam'];

$query1 = 'SELECT COUNT(SequenceRun_ID_req) FROM Analysis_Configuration WHERE SequenceRun_ID_req="' .$SequenceRun_ID_req1 . '" '; 

 $result1 = mysql_query($query1,$db) or die(mysql_error($db));
  if (!$result1)
  {
   $total = 1;
  }
  else
   {
    $row = mysql_fetch_array($result1);
    $total =mysql_result($result1, 0, 0);
   }
if ($total == 0)
{
$total = 1;
}
else
{
$query2 = 'SELECT * FROM Analysis_Configuration WHERE SequenceRun_ID_req="' .$SequenceRun_ID_req1  .'" AND ticket = "'
 . $total .'"'; 

$result2 = mysql_query($query2,$db) or die(mysql_error());
  if (!$result2)

 {
    $total = 1;
  }
  else
    {
     $row = mysql_fetch_array($result2);
     $total = $row['ticket'] + 1;
    }  
 }


$track_exp1 = $total ;

 //get the UID for this specimen
 $ticketnum = $track_exp1;
 $Sequence_Data2= $infile1."-".$total;
$bowtie2_1 ="no";
$timeBT2_1 ="no";
$errorBT2_1 ="no";
$timecreation1=date("m-d-y_H:i:s", time()) ;
$namef= $Sequence_Data_Point.$infile1."-".$total;
$namef1=$infile1."-".$total;
$infile2 =  $Sequence_Data_Point.$infile1;
$pieces = explode("INFILE", $Sequence_Data_Point);
$Result_Alignment=$pieces[0]."OUTFILE";


if ($Read_Type == 'single-end') //single-end   
{
	$inf1="$Sequence_Data_Point$infile1";
	$pref1= "$Result_Alignment/$infile1/$infile1-$total";

        $crd1="mkdir $pref1";
	$crd2="mkdir $pref1/tophat_out";
        $rd1=shell_exec($crd1);
        $rd2=shell_exec($crd2);
	$cmd = "tophat -o $pref1/tophat_out $bowtie2db$dbname1 $inf1 " ;
      	$res=shell_exec($cmd);

  if ($cuff == 'yes')
     {
        $crd1="mkdir $pref1/cufflinks";
	$cd2="cd $pref1/cufflinks";
        $rd3=shell_exec($crd1);
        $rd4=shell_exec($cd2);
        $cmd1 = "cufflinks -o $pref1/cufflinks $pref1/tophat_out/accepted_hits.bam" ;
        $res1=shell_exec($cmd1); 
        $cufflinks1='yes';
     }


}

else
{
	$inf1  = "$Sequence_Data_Point"."PAIR1/$infile1";
	$pref1 = "$Result_Alignment/$infile1/PAIR1/$infile1-$total";
	$inf2  = "$Sequence_Data_Point"."PAIR2/$infile1";
	$crd1="mkdir $pref1";
	$crd2="mkdir $pref1/tophat_out";
        $rd1=shell_exec($crd1);
        $rd2=shell_exec($crd2);
	$cmd1 = "tophat -o $pref1/tophat_out $bowtie2db$dbname1 $inf1 $inf2" ; 	
        $res1=shell_exec($cmd1);

     if ($cuff == 'yes')
  {
        $crd1="mkdir $pref1/cufflinks";
        $md= "chmod 775 $pref1/cufflinks";
	$cd2="cd $pref1/cufflinks";
        $rd3=shell_exec($crd1);
        $rd4=shell_exec($cd2);
        $cmd1 = "cufflinks -o $pref1/cufflinks $pref1/tophat_out/accepted_hits.bam" ;
        $res1=shell_exec($cmd1); 
        $cufflinks1='yes';
  } 

}


$tophat1 = "yes";
 $query = 'INSERT INTO Analysis_Configuration SET
   SequenceRun_ID_req    ="' . $SequenceRun_ID_req1 . '",
   ticket                ="' . $ticketnum . '",
   Sequence_Data         ="' . $Sequence_Data . '",
   Sequence_Data_Point   ="' . $Sequence_Data_Point . '",
   Result_Alignment	 ="' . $pref1 . '",
   Read_Type             ="' . $Read_Type . '",
   infileP               ="' . $infile1 . '",
   prefixP               ="' . $prefix1 . '",
   outputFormat          ="' . $output1 . '",
   dbname	         ="' . $dbname1 . '",
   bin_path              ="' . $cuff . '", 
   bowtie2               ="' . $bowtie2_1 . '",
   processors            ="' . $processors . '",
   timeBT2               ="' . $timeBT2_1 . '",
   errorBW2 		 ="' . $errorBT2_1  . '",
   tophat	         ="' . $tophat1  . '",
   cufflinks	         ="' . $cufflinks1  . '",
   quality               ="' . $quality1  . '",
   blast                 ="' . $blastType . '",
   evalue                ="' . $eValue .'",
   server                ="' . $server1.'",
   timecreation          ="'.  $timecreation1 .'",  
   createdby             ="' . $createdby1 . '"';


$result = mysql_query($query, $db) or die(mysql_error($db));
echo '<div id="messages">' . 'Running TopHat for Sequence Run ID ' . "'$SequenceRun_ID_req1'" . '. The TopHat/Cufflinks results are on'. "'$pref1'" ;

?>
<BR>&nbsp;<BR>
<?php


} //if no error
}//else if valid
?>

</div>
</body>

</html>

<?php

function valid_info() //required
{
$error = '';


if(empty($_POST['infileP'])){
$error = urlencode('Please enter infile name. No spaces.');
echo '<div id="error">' . $error;
}

 if (!empty($_POST['infileP'])){
 if (check_input1($_POST['infileP']) == "FALSO"){
 $error = urlencode('Please enter a valid input file.No spaces.');
 echo '<div id="error">' . $error;
}
}

if(empty($_POST['prefixP'])){
$error = urlencode('Please enter an output file. No spaces.');
echo '<div id="error">' . $error;
}

if(!empty($_POST['prefixP'])){
     if (check_input1($_POST['prefixP']) =="FALSO"){
     $error= urlencode('Please enter a valid prefix name. No spaces.');
     echo '<div id="error">' . $error;
   }
  }

if(!empty($_POST['processor'])){
 if (check_input_int($_POST['processor']) =="FALSO"){
     $error= urlencode('Please enter a valid integer.');
     echo '<div id="error">' . $error;
      }
     }

if(empty($_POST['dbName'])) {
$error = urlencode('Please select db.');
echo '<div id="error">' . $error;
}


if (empty($error)) 
     return TRUE;
else 
   return FALSE;


}// valid_info


function check_input_int($data)
{
   $data = (int)$data;
  if(!is_int($data))
    return "FALSO";
  else
    return $data;
}


function check_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data);
    return $data;
}

function check_input1($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data);
    $findme   = ' ';
    $pos = strpos($data, $findme);
    if ($pos !== false) { 
          return "FALSO"; 
          } else {
          return $data; 
  }
}


?>

</div>
</body>

</html>
