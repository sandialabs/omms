<?php
/*
Copyright 2012, Martha Perez-Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, tophatConf.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Analysis - TopHat</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="pointConf.php" id="current">Select Input </a></li>
<li><a href="blastConf.php">BLAST </a></li> 
<li><a href="bowtie2Conf.php">Bowtie 2 </a></li> 
<li><a href="tophatConf.php">TopHat </a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<BR>&nbsp;<BR>
<?php
session_start();
include_once '../configUser.inc';

if(isset($_POST['SequenceRun_ID_req']) )
{
$_SESSION['SequenceRun_ID_req'] = $_POST['SequenceRun_ID_req'];

} 
 else 
 {
$_SESSION['SequenceRun_ID_req'] ='';
}

echo "<h3><span>TopHat Configuration for Sequence MetaInfo</span></h3>";
echo '<div id="messages2">' . 'Select the Sequence Run ID to configure TopHat run';
echo "<table border='1'>
<tr> 
  <th>Sequence Run ID </th>
  <th>Experiment Name </th>
   <th>Date Sample Submitted </th>
  <th>Project </th>
  <th>Provider Sequence Directory </th>
  <th>Fastq mate pair 1 </th>
  <th>Fastq mate pair 2 </th>  
  <th>Sequence Data </th>
  <th>Sequence Data Pointer </th>
  <th>Read Type </th>
  <th>Sequence Complete </th>
</tr>";

include_once '../config.inc'; //data for the connection
$db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//make sure you're using the correct database
$db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));

$result = mysql_query("SELECT SequenceRun_ID_req, Experiment_Name_req, Date_Sample_Submitted, Project, ProviderSeqDirName, Sequence_Data,Sequence_Data_Point, fastqMatePair1, fastqMatePair2, Read_Type, Received FROM (SELECT SequenceRun_ID_req, Experiment_Name_req, Date_Sample_Submitted, Project, ProviderSeqDirName,Sequence_Data,Sequence_Data_Point, fastqMatePair1, fastqMatePair2, Read_Type, Received, track_sequence FROM HPMB_SequenceMetaInfo ORDER BY SequenceRun_ID_req, track_sequence DESC) AS temp GROUP BY SequenceRun_ID_req", $db);

while (list($SequenceRun_ID_req, $Experiment_Name_req, $Date_Sample_Submitted, $Project, $ProviderSeqDirName,$Sequence_Data,$Sequence_Data_Point, $fastqMatePair1, $fastqMatePair2,  $Read_Type, $Received) = mysql_fetch_row($result)) {
    echo " <tr>\n" ;
      echo "  <td><a href=\"tophatPipeline.php?id=$SequenceRun_ID_req\">$SequenceRun_ID_req</a></td>\n" .
          "   <td>$Experiment_Name_req</td>\n" .
          "   <td>$Date_Sample_Submitted</td>\n" .
          "   <td>$Project</td>\n" .
          "   <td>$ProviderSeqDirName</td>\n" .
          "   <td>$fastqMatePair1</td>\n" .
          "   <td>$fastqMatePair2</td>\n" .
  	  "   <td>$Sequence_Data</td>\n" .
          "   <td>$Sequence_Data_Point</td>\n" .
          "   <td>$Read_Type</td>\n" .
          "  <td>$Received</a></td>\n" .
          " </tr>\n";
}

?>
