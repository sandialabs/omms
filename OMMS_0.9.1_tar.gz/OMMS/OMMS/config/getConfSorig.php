<?php
/*
Copyright 2012, Martha Perez-Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, getConfSorig.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Analysis - Select Input</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="pointConf.php" id="current">Select Input </a></li>
<li><a href="blastConf.php">BLAST </a></li> 
<li><a href="bowtie2Conf.php">Bowtie 2 </a></li> 
<li><a href="tophatConf.php">TopHat </a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<BR>&nbsp;<BR>


<?php
if (valid_info()) 
{ 
$error='';
$SequenceRun_ID_req1 = $_POST['SequenceRun_ID_req'];
$Sequence_Data1 = $_POST['Sequence_Data'];
$Sequence_Data_Point1 = $_POST['Sequence_Data_Point'];
$Read_Type = $_POST['Read_Type'];
$infile1 = check_input1($_POST['infileP']);
$uplraw  = check_input1($_POST['ProviderSeqDirName']);

$data = trim($SequenceRun_ID_req1);
$data = stripslashes($data);
$data = strip_tags($data);

 if (empty($error)) {

include_once '../config.inc'; //data for the connection

 $db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//Using the correct database
 $db1 = mysql_select_db($dbname, $db) or die(mysql_error($db));


if(!empty($_POST['ProviderSeqDirName']) && !empty($_POST['Read_type'])  && !empty($_POST['fastqMatePair1'])){
$upload1=$_POST['Project'];
$fileuploaded1 = $_POST['ProviderSeqDirName'];
$filetype1 = $_POST['fastqMatePair1'];
}
else 
{
$upload1='';
$fileuploaded1 = '';
$filetype1 = '';

}

$findme="pair";
$pos1 = strpos($Read_Type, $findme);
if ($pos1 === false ) {//single-end
$NewSequence =$_POST['singleplex'];
$point="ln $NewSequence $Sequence_Data_Point1$infile1";

$pnt=shell_exec($point);
$pointd="ls $Sequence_Data_Point1$infile1";
$pnt=shell_exec($pointd);

    if ($pnt==NULL){
      echo '<div id="error">' . 'Check the name of the directory and file. There was a problem';
          }
    else {
      echo '<div id="messages">' . 'Input file selected';
       
$query1 = 'SELECT COUNT(SequenceRun_ID_req) AS Uid FROM HPMB_SequenceMetaInfo WHERE SequenceRun_ID_req="' . $data . '" '; 

 $result1 = mysql_query($query1,$db) or die(mysql_error($db));
  if (!$result1)
  {
    echo '<div id="error">' . 'Error no such record exist from database.';
    exit();
  }
  else
   {
    $row = mysql_fetch_array($result1);
    $total =mysql_result($result1, 0, 0);
   }
if ($total == 0)
{
echo '<div id="error">' . 'Error no such record exist from database.';
exit();
}


$query2 = 'SELECT * FROM HPMB_SequenceMetaInfo WHERE SequenceRun_ID_req = "' . $data . '" AND track_sequence = "'
 . $total .'"'; 

 $result2 = mysql_query($query2,$db) or die(mysql_error());
  if (!$result2)
  {
    echo 'Error selecting records from database.';
    exit();
  }
    
    $SequenceRun_ID_req1 = $data;
    $row2 = mysql_fetch_array($result2);
    $Experiment_Name_req1 = "$row2[Experiment_Name_req]"; 
    $Specimen_UID_req1 =    "$row2[Specimen_UID_req]"; 
    $Specimen_UID_sec1 =    "$row2[Specimen_UID_sec]"; 
    $Sample_UID_req1   =    "$row2[Sample_UID_req]"; 
    $Sequence_Lane_req =    "$row2[Sequence_Lane_req]";
    if ($row2['Date_Sample_Submitted'] == '0000-00-00' ) {$Date_Sample_Submitted='00-00-0000'; }
    else { $Date_Sample_Submitted = change_date_format( $row2['Date_Sample_Submitted']);}
    $Specimen_UID_sec    = "$row2[Specimen_UID_sec]";
    $Sequencing_Provider = "$row2[Sequencing_Provider]";
    $Sequencing_Platform = "$row2[Sequencing_Platform]";
    $ProviderSeqDirName1 = "$row2[ProviderSeqDirName]";
    $fastqMatePair1_1    = "$row2[fastqMatePair1]";
    $fastqMatePair2_1    = "$row2[fastqMatePair2]";
    $Project1            = "$row2[Project]";
    $Run_Plexing         = "$row2[Run_Plexing]";
    if ($row2['Date_Run_Performed'] == '0000-00-00' ) {$Date_Run_Performed ='00-00-0000' ;}
    else { $Date_Run_Performed = change_date_format( $row2['Date_Run_Performed']);}
    $Run_Number          = "$row2[Run_Number]";
    if ($row2['Date_Run_Performed'] == '0000-00-00' ) {$Date_Data_Received ='00-00-0000';}
    else { $Date_Data_Received = change_date_format( $row2['Date_Data_Received']);}
    $Total_Reads_Millions = "$row2[Total_Reads_Millions]";
    $Read_Type1           = "$row2[Read_Type]";
    $Read_Length_Bases    = "$row2[Read_Length_Bases]";
    $Total_Bases_Billions = "$row2[Total_Bases_Billions]";
    $Experimentalists_notes_upload = "$row2[Experimentalists_notes_upload]";
    $fileuploaded         = "$row2[fileuploaded]";
    $filetype             = "$row2[filetype]";
    $Remarks              = "$row2[Remarks]";
    $createdby            = $row2['createdby'] ;
    $timecreation         = $row2['timecreation']; 
    $modifiedby           = $row2['modifiedby'];
    $timemodified         = $row2['timemodified'];
    $track_id1            = $row2['track_id'];
    $track_sequence1      = $row2['track_sequence'] ; 
    $track_exp1           = $row2['track_exp'];



$receiv1='YES';
$query = 'UPDATE HPMB_SequenceMetaInfo SET
   Sequence_Data        ="' . $Sequence_Data1 . '",
   Sequence_Data_Point  ="' . $Sequence_Data_Point1 . '",
   Received             ="' . $receiv1 . '"
   WHERE
   SequenceRun_ID_req   ="' . $SequenceRun_ID_req1 . '"
   AND track_id             ="' . $track_id1 .'"
   AND track_exp            ="' . $track_exp1 .'"
   AND track_sequence       ="' . $track_sequence1.'"';


$result3 = mysql_query($query, $db) or die(mysql_error($db));

echo '<div id="messages">' . 'Updated directories for Sequence Run ID: ' . $SequenceRun_ID_req1 . ' and the Unique Experiment Name:   ' .$Experiment_Name_req1  ;
       }

}
else //paired-end
   {
$NewSequence1 =$_POST['pair1'];
$NewSequence2 =$_POST['pair2'];

$point1="ln $NewSequence1 ".$Sequence_Data1."PAIR1/". $infile1;
$point2="ln $NewSequence1 ".$Sequence_Data1."PAIR2/". $infile1;
$pnt1=shell_exec($point1);
$pnt2=shell_exec($point2);


//


   }



} //if no error
}//else if valid
?>

</div>
</body>

</html>

<?php

function valid_info() //required
{
$error = '';


if(empty($_POST['ProviderSeqDirName'])){
$error = urlencode('Please enter a directory to select input.');
 echo '<div id="error">' . $error;
}

 if (!empty($_POST['ProviderSeqDirName'])){
 if (check_input1($_POST['ProviderSeqDirName']) == "FALSO"){
 $error = urlencode('Please enter a valid directory to select input. No spaces.');
 echo '<div id="error">' . $error;
}
}




if (empty($error)) 
     return TRUE;
else 
   return FALSE;


}// valid_info


function check_input_int($data)
{
   $data = (int)$data;
  if(!is_int($data))
    return "FALSO";
  else
    return $data;
}


function check_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data);
    return $data;
}


function check_input1($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data);
    $findme   = ' ';
    $pos = strpos($data, $findme);
    if ($pos !== false) { 
          return "FALSO"; 
          } else {
          return $data; 
  }
}
?>
