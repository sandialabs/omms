#!/bin/bash
# installer for OMMS

#Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

#This file, installer.sh, is part of the OMMS.

#The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

#The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

#You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.


# check the current path
currentPath=`pwd`
scriptsDir="OMMS/"
dbDir="DBOMMS/"

# Fill in missing values with defaults
SOURCE1=${SOURCE1:-"$currentPath/$scriptsDir/"}
SOURCE2=${SOURCE2:-"$currentPath/$dbDir/"}
DESTINATION=${DESTINATION:-/var/lib/mysql/}
ROOTDIR=${ROOTDIR:-/var/www/html/}

echo "_________________________________________"
echo ""
echo Installing OMMS ...
echo "_________________________________________"
echo ""

echo "Press <enter> to extract the OMMS."
read -n1 key1
if [[ $key1 == "" ]]; then 
	if [ "$(ls -A $SOURCE1 2> /dev/null)" == "" ]; then
        echo "Make sure the OMMS directory is on this path"
        exit
        else
        
	# "Reading" variables to move directories
	# The -n option to echo suppresses newline.
	echo -n "Enter the Root directory to contain OMMS. Default: < $ROOTDIR >"
	read pathOMMS 

	# test if read is empty
	if [ "$pathOMMS" == "" ]
 	then
 	PATHOMMS=${ROOTDIR}
 	else
 	PATHOMMS="${pathOMMS}/"
	fi

	echo "$PATHOMMS$scriptsDir" > $currentPath/uninstallOMMS.txt

	echo "RootDir $PATHOMMS"

	echo -n "Enter the Mysql directory to contain database DBOMMS. Default: < $DESTINATION >"
	read pathDB 

	# test if read is empty
	if [ "$pathDB" == "" ]
 	then
 	PATHDB=${DESTINATION}
 	else
 	PATHDB="${pathDB}/"
	fi

	echo "MysqlDir $PATHDB"

	echo "$PATHDB$dbDir" >> $currentPath/uninstallOMMS.txt

	if [[ -d $PATHOMMS ]]; then
    	mv -v \
    	$SOURCE1 $PATHOMMS
 	else echo Not finding $PATHOMMS
	fi    

	owner=`ls -ld $PATHOMMS | awk '{print $3}'`
	group=`ls -ld $PATHOMMS | awk '{print $4}'`

	chown -R $owner.$group $PATHOMMS$scriptsDir
	chmod -R 777 $PATHOMMS$scriptsDir
	chmod +t $PATHOMMS$scriptsDir

	if [[ -d $PATHDB ]]; then
     	mv -v \
    	$SOURCE2 $PATHDB
 	else echo No finding $PATHDB
	fi    

	chown -R mysql.mysql $PATHDB$dbDir
	chmod -R 755 $PATHDB$dbDir

        fi
else
echo "Leaving OMMS installation."
exit
fi


echo "_________________________________________"
echo ""
echo Configuring OMMS...

echo "_________________________________________"
echo ""

# Update the config files
# 1. config.inc replace the password for your mysql configuration
lineP="PASSWORD" 
lineU="root"

echo -n "Enter the user to access databases in MySQL. Default < root > "
read userDB 

# test if read is empty
if [ -z "$userDB" ] 
 then
 USERDB="root"
 else
 USERDB=${userDB}
 sed -i.bak "s/${lineU}/${USERDB}/g" "${PATHOMMS}${scriptsDir}config.inc" 
fi

echo -n "Enter the password for the user to access databases in MySQL. "
read -s passwdDB 
echo ""
# test if read is empty
if [ -z "$passwdDB" ] 
 then
 PASSWDDB=""
 else
 PASSWDDB=${passwdDB}
fi

 sed -i.bak "s/${lineP}/${PASSWDDB}/g" "${PATHOMMS}${scriptsDir}config.inc"

#2. configDir.inc replace the localhost 
line1="localhost" 

echo -n "Enter the localhost. Default < localhost > "
read localHost 

# test if read is empty
if [ -z "$localHost" ] 
 then
 LOCALH=${line1}
 else
 LOCALH=${localHost}
fi

 sed -i.bak "s/${line1}/${LOCALH}/g" "${PATHOMMS}${scriptsDir}configUser.inc"

#3. configDir.inc replace the directories and create inside the analysis location: INFILE and OUTFILE 
lineA="ANALYSIS" 
lineB="SEQUENCES"
lineC="BLASTDB"
lineD="BOWTIE2INDEX"

#Analysis location
analysisDir=""
while [ "$analysisDir" == "" ]; do
   echo -n "Enter the location for Analysis Directory; e.g. /data1/analysis/ "
   read analysisDir 
done

# test if read directory exists
if [ -d "$analysisDir" ]
  then
  echo The directory ${analysisDir} exists. OK
  else
  echo Creating directory ${analysisDir}. OK
  mkdir -p ${analysisDir} 
fi

 # chown root.root ${analysisDir}  
  chmod 777 ${analysisDir}
  chmod +t ${analysisDir}  
  ANALYSISDIR="${analysisDir}/"

sed -i.bak "s_${lineA}_${ANALYSISDIR}_g" "${PATHOMMS}${scriptsDir}configDir.inc"

    if [ -d "$ANALYSISDIR" ]; then
      cd ${ANALYSISDIR}
      mkdir -p INFILE 2> /dev/null
      mkdir -p OUTFILE 2> /dev/null
      cd ..
      chmod -R 777 ${ANALYSISDIR}
      chmod -R +t ${ANALYSISDIR}  
      chown -R "$owner.$group" ${ANALYSISDIR}
     # echo  "$owner.$group" 
    else
        echo Directory ${ANALYSISDIR} does not exist.
    fi

echo "$ANALYSISDIR" >> $currentPath/uninstallOMMS.txt


#Sequences location
seqsDir=""
while [ "$seqsDir" == "" ]; do
   echo -n "Enter the location for Sequences Directory; e.g. /data1/seqs/ "
   read seqsDir 
done
 

# test if read directory exists
if [ -d "$seqsDir" ]
  then
  echo The directory ${seqsDir} exists. OK
  else
  echo Creating directory ${seqsDir}. OK
  mkdir -p ${seqsDir}
fi

SEQSDIR="${seqsDir}/"

if [ -d "$SEQSDIR" ]
    then
    chmod -R 777 ${SEQSDIR}
    chmod -R +t ${SEQSDIR}  
    chown -R $owner.$group ${SEQSDIR}
    else
    echo Directory ${SEQSDIR} does not exist. 
fi

 sed -i.bak "s_${lineB}_${SEQSDIR}_g" "${PATHOMMS}${scriptsDir}configDir.inc"


echo "$SEQSDIR" >> $currentPath/uninstallOMMS.txt

cp $currentPath/uninstallOMMS.txt $PATHOMMS$scriptsDir
cp $currentPath/uninstaller.sh $PATHOMMS$scriptsDir

#BLAST Databases location
echo -n "Enter the location for BLAST Databases. Default < /usr/bin/blast/db/ > "
read dbDir 

# test if read is empty
if [ "$dbDir" == "" ] 
 then
 DBDIR="/usr/bin/blast/db/"
 else
 DBDIR="${dbDir}/" 
fi
 sed -i.bak "s_${lineC}_${DBDIR}_g" "${PATHOMMS}${scriptsDir}configDir.inc"


#Bowtie 2 indices location
echo -n "Enter the location for Bowtie 2 Indices. Default < /usr/bin/bowtie2/index/ > "
read indDir 

# test if read is empty
if [ "$indDir" == "" ] 
 then
 INDDIR="/usr/bin/bowtie2/index/"
 else
 INDDIR="${indDir}/" 
fi
 sed -i.bak "s_${lineD}_${INDDIR}_g" "${PATHOMMS}${scriptsDir}configDir.inc"


#if BLAST and Bowtie2 are in /usr/bin, the path is ok, otherwise display a message
blastN=`which blastn`
blastP=`which blastp`
blastX=`which blastx`

 
# test if variable from which is empty
if [ -z "$blastN" ] 
 then
 echo "The BLAST program blastn should be installed in a directory within your path. Install it for Analysis portal functionality."
 else
   echo "The BLAST program blastn is installed in ${blastN}. OK"    
 fi

# test if variable from which is empty
if [ -z "$blastP" ] 
 then
 echo "The BLAST program blastp should be installed in a directory within your path. Install it for Analysis portal functionality."
 else
   echo "The BLAST program blastp is installed in ${blastP}. OK"   
 fi

# test if variable from which is empty
if [ -z "$blastX" ] 
 then
 echo "The BLAST program blastx should be installed in a directory within your path. Install it for Analysis portal functionality."
 else
   echo "The BLAST program blastx is installed in ${blastX}. OK"   
 fi


bowtie2E=`which bowtie2`
 
# test if variable from which is empty
if [ -z "$bowtie2E" ] 
 then
 echo "The Bowtie 2 program should be installed in a directory within your path. Install it for Analysis portal functionality."
 else
   echo "The Bowtie 2 program is installed in ${bowtie2E}. OK"    
 fi


# Verify the paths for TopHat and Cufflinks executables as well

topH=`which tophat`
 
# test if variable from which is empty
if [ -z "$topH" ] 
 then
 echo "The TopHat program should be installed in a directory within your path. Install it for Analysis portal functionality."
 else
   echo "The TopHat program is installed in ${topH}. OK"   
 fi


cuffL=`which cufflinks | sed 's/cufflinks//g' `
 
# test if variable from which is empty
if [ -z "$cuffL" ] 
 then
 echo "The Cufflinks program should be installed in a directory within your path. Install it for Analysis portal functionality."
 else
   echo "The Cufflinks program is installed in ${cuffL}. OK"   
 fi


