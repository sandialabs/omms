<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, update2.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Sample Processing</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSample.php">Update</a></li> 
<li><a href="consultSample.php">Consult</a></li> 
<li><a href="helpSample.php">Help</a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<BR>&nbsp;<BR>
<BR>&nbsp;<BR>
<BR>&nbsp;<BR>

<?php
session_start();
if ($_SESSION['testStore'] != $_POST['testStore']) {
   echo '<div id="error">'. "Not allowed to duplicate the information.";
}
else
{
 $_SESSION['testStore'] = null;
include_once 'configUser.inc';

if (valid_info()) 
{ 
$createdby1 = check_input($_POST['createdby']);
$timecreation1 = check_input($_POST['timecreation']);
$track_id1 = $_POST['track_id'];
$track_sample1 = $_POST['track_sample'];

$Specimen_UID_req1 =  check_input($_POST['Specimen_UID_req']); 
$Sample_UID_req1 =  $_POST['Sample_UID_req']; 

$Purification_Nucleic_Acid_Method_req1 = check_input($_POST['Purification_Nucleic_Acid_Method_req']);

$Purified_By_req1 =  check_input($_POST['Purified_By_req']);
$Primer_Set_Name1 = check_input($_POST['Primer_Set']);
$Barcode_Name1 = check_input($_POST['Barcode_Name']);

if(!empty($_POST['Sample_Alias_req'])){
$Sample_Alias_req1 = check_input($_POST['Sample_Alias_req']);}
else $Sample_Alias_req1 = '';


if(!empty($_POST['Nucleic_Acid_req'])){
$Nucleic_Acid_req1 =  check_input($_POST['Nucleic_Acid_req']);}
else $Nucleic_Acid_req1 = '';

if(!empty($_POST['Target_Nucleic_Acid_req'])){
$Target_Nucleic_Acid_req1 =  check_input($_POST['Target_Nucleic_Acid_req']);}
else $Target_Nucleic_Acid_req1 = '';


if(!empty($_POST['Barcode_Type'])){
$Barcode_Type1 =check_input ($_POST['Barcode_Type']);}
else $Barcode_Type1 = '';

if(!empty($_POST['Primer_Name'])){
$Primer_Name1 = check_input($_POST['Primer_Name']);}
else $Primer_Name1 = '';

if(!empty($_POST['Library_Preparation_ID_req'])){
$Library_Preparation_ID_req1 =  check_input($_POST['Library_Preparation_ID_req']);}
else $Library_Preparation_ID_req1 = '';

if(!empty($_POST['Library_Preparation_Method_req'])){
$Library_Preparation_Method_req1 =  check_input($_POST['Library_Preparation_Method_req']);}
else $Library_Preparation_Method_req1 = '';


if(!empty($_POST['Library_Prepared_By_req'])){
$Library_Prepared_By_req1 =  check_input($_POST['Library_Prepared_By_req']);}
else $Library_Prepared_By_req1 = '';


if(!empty($_POST['Sequencing_Provider_req'])){
$Sequencing_Provider_req1 = check_input($_POST['Sequencing_Provider_req']);}
else $Sequencing_Provider_req1 = '';


if(!empty($_POST['Sample_Alias_req'])){
$Sample_Alias_req1 = check_input($_POST['Sample_Alias_req']);}
else $Sample_Alias_req1 = '';

$Sent_By_req1 = check_input($_POST['Sent_By_req']);

if(!empty($_POST['Date_Nucleic_Acid_Purified_req']) && ($_POST['Date_Nucleic_Acid_Purified_req'] != '00-00-0000') ){
$Date_Nucleic_Acid_Purified_req1 = check_date($_POST['Date_Nucleic_Acid_Purified_req']);}
else $Date_Nucleic_Acid_Purified_req1 = '';

if(!empty($_POST['Date_Library_Prepared_req']) && ($_POST['Date_Library_Prepared_req'] != '00-00-0000')){
$Date_Library_Prepared_req1 = check_date($_POST['Date_Library_Prepared_req']);}
else $Date_Library_Prepared_req1 = '';


if(!empty($_POST['Date_at_Sequencing_Provider_req']) && ($_POST['Date_at_Sequencing_Provider_req'] != '00-00-0000')){
$Date_at_Sequencing_Provider_req1 = check_date($_POST['Date_at_Sequencing_Provider_req']);}
else $Date_at_Sequencing_Provider_req1 = '';


if(!empty($_POST['Library_Nucleic_Acid_Input_Nanograms_req'])){
$Library_Nucleic_Acid_Input_Nanograms_req1 = check_input_float($_POST['Library_Nucleic_Acid_Input_Nanograms_req']);}
else $Library_Nucleic_Acid_Input_Nanograms_req1 = '';


if(!empty($_POST['Library_Prep_Final_Volume_Microliters_req'])){
$Library_Prep_Final_Volume_Microliters_req1 = check_input_float($_POST['Library_Prep_Final_Volume_Microliters_req']);}
else $Library_Prep_Final_Volume_Microliters_req1 = '';


if(!empty($_POST['Final_Library_Concentration_Nanograms_Microliter_req'])){
$Final_Library_Concentration_Nanograms_Microliter_req1 = check_input_float($_POST['Final_Library_Concentration_Nanograms_Microliter_req']);}
else $Final_Library_Concentration_Nanograms_Microliter_req1 = '';

if(!empty($_POST['Specimen_UID_sec'])){
$Specimen_UID_sec1 = ($_POST['Specimen_UID_sec']);}
else $Specimen_UID_sec1 = '';

if(!empty($_POST['QC_Result'])){
$QC_Result1 =  check_inputS($_POST['QC_Result']);}
else $QC_Result1 = '';


if(!empty($_POST['Nucleic_Acid_Modification_Method'])){
$Nucleic_Acid_Modification_Method1 = check_input($_POST['Nucleic_Acid_Modification_Method']);}
else $Nucleic_Acid_Modification_Method1 = '';

if(!empty($_POST['Nucleic_Acid_Modified_By'])){
$Nucleic_Acid_Modified_By1 = check_input($_POST['Nucleic_Acid_Modified_By']);}
else $Nucleic_Acid_Modified_By1 = '';

if(!empty($_POST['Date_Nucleic_Acid_Modified']) && ($_POST['Date_Nucleic_Acid_Modified'] != '00-00-0000')){
$Date_Nucleic_Acid_Modified1 = check_date($_POST['Date_Nucleic_Acid_Modified']);}
else $Date_Nucleic_Acid_Modified1 = '';

if(!empty($_POST['Modified_Nucleic_Acid_Type'])){
$Modified_Nucleic_Acid_Type1 = check_input($_POST['Modified_Nucleic_Acid_Type']);}
else $Modified_Nucleic_Acid_Type1 = '';

if(!empty($_POST['Modified_Nucleic_Acid_Yield_Nanograms'])){
$Modified_Nucleic_Acid_Yield_Nanograms1 = check_input($_POST['Modified_Nucleic_Acid_Yield_Nanograms']);}
else $Modified_Nucleic_Acid_Yield_Nanograms1 = '';

if(!empty($_POST['Modified_Nucleic_Acid_QC_Result'])){
$Modified_Nucleic_Acid_QC_Result1 =  check_inputS($_POST['Modified_Nucleic_Acid_QC_Result']);}
else $Modified_Nucleic_Acid_QC_Result1 = '';

if(!empty($_POST['Suppression_Method'])){
$Suppression_Method1 =  check_input($_POST['Suppression_Method']);}
else $Suppression_Method1 = '';

if(!empty($_POST['Suppressed_By'])){
$Suppressed_By1 =  check_input($_POST['Suppressed_By']);}
else $Suppressed_By1 = '';

if(!empty($_POST['Date_Nucleic_Acid_Suppressed']) && ($_POST['Date_Nucleic_Acid_Modified'] != '00-00-0000')){
$Date_Nucleic_Acid_Suppressed1 = check_date($_POST['Date_Nucleic_Acid_Suppressed']);}
else $Date_Nucleic_Acid_Suppressed1 = '';

if(!empty($_POST['Suppressed_Nucleic_Acid_Yield_Nanograms'])){
$Suppressed_Nucleic_Acid_Yield_Nanograms1 =  check_input_float($_POST['Suppressed_Nucleic_Acid_Yield_Nanograms']);}
else $Suppressed_Nucleic_Acid_Yield_Nanograms1 = '';

if(!empty($_POST['Suppressed_Nucleic_Acid_QC_Result'])){
$Suppressed_Nucleic_Acid_QC_Result1 =  check_inputS($_POST['Suppressed_Nucleic_Acid_QC_Result']);}
else $Suppressed_Nucleic_Acid_QC_Result1 = '';

if(!empty($_POST['Library_Nucleic_Acid_QC_Result'])){
$Library_Nucleic_Acid_QC_Result1 =  check_inputS($_POST['Library_Nucleic_Acid_QC_Result']);}
else $Library_Nucleic_Acid_QC_Result1 = '';

if(!empty($_POST['Average_Insert_Size_basepairs'])){
$Average_Insert_Size_basepairs1 =  check_input($_POST['Average_Insert_Size_basepairs']);}
else $Average_Insert_Size_basepairs1 = '';

//start upload
if(!empty($_FILES['Experimentalist_Informatician_notes_upload']['name']))
{  
  if ($_FILES["Experimentalist_Informatician_notes_upload"]["size"] < 100000 && $_FILES["Experimentalist_Informatician_notes_upload"]["type"]=="text/plain")
    { 
   
     if ($_FILES["Experimentalist_Informatician_notes_upload"]["error"] > 0)
  {
 $error[12] = urlencode('Please enter a valid file.');
 echo '<div id="error">' . $error[12];
 echo '<div id="error">' . $_FILES["Experimentalist_Informatician_notes_upload"]["error"] . "<br />";
  }

 else
   {
     $uploadfile1 = $_FILES['Experimentalist_Informatician_notes_upload']['tmp_name'];   //tmp name selected in directory
     $Experimentalists_notes_upload1 = $_FILES['Experimentalist_Informatician_notes_upload']['name'];       //name selected in directory
     $filetype1  = $_FILES['Experimentalist_Informatician_notes_upload']['type'];       // type of file
     $fileuploaded1 = file_get_contents($uploadfile1);  
    
     // Prepare user-submitted values for safe database insert
     $fileuploaded1 = check_input($fileuploaded1);
     $filetype1 = check_input($filetype1);
     $Experimentalists_notes_upload1 =check_input($Experimentalists_notes_upload1);
   }       
  } //if - test size
  else {echo '<div id="error">' . "No file uploaded: size or file type incorrect.";}
}//if - non empty
else 
{
$Experimentalists_notes_upload1='';
$fileuploaded1 = '';
$filetype1 = '';
}
//end upload


 if (empty($error)) {

include_once '../config.inc'; //data for the connection

 $db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//make sure you're using the correct database
 $db1 = mysql_select_db($dbname, $db) or die(mysql_error($db));



$query = 'INSERT INTO HPMB_SampleProcessing SET
   Specimen_UID_req                               ="' . $Specimen_UID_req1 . '",
   Specimen_UID_sec                               ="' . $Specimen_UID_sec1 . '",
   Sample_UID_req                                 ="' . $Sample_UID_req1 . '",
   Sample_Alias_req                               ="' . $Sample_Alias_req1 . '",
   Nucleic_Acid_req                               ="' . $Nucleic_Acid_req1 . '",
   Target_Nucleic_Acid_req                        ="' . $Target_Nucleic_Acid_req1  . '",
   Purification_Nucleic_Acid_Method_req           ="' . $Purification_Nucleic_Acid_Method_req1 . '",
   Purified_By_req                                ="' . $Purified_By_req1  . '",
   Date_Nucleic_Acid_Purified_req                 ="' . $Date_Nucleic_Acid_Purified_req1 . '",
   Purified_Nucleic_Acid_Yield_Nanograms          ="' . $Purified_Nucleic_Acid_Yield_Nanograms1 . '",
   QC_Result                                      ="' . $QC_Result1 . '",
   Nucleic_Acid_Modification_Method               ="' . $Nucleic_Acid_Modification_Method1 . '",
   Nucleic_Acid_Modified_By                       ="' . $Nucleic_Acid_Modified_By1 . '",
   Date_Nucleic_Acid_Modified                     ="' . $Date_Nucleic_Acid_Modified1  . '",
   Modified_Nucleic_Acid_Type                     ="' . $Modified_Nucleic_Acid_Type1  . '",
   Modified_Nucleic_Acid_Yield_Nanograms          ="' . $Modified_Nucleic_Acid_Yield_Nanograms1 . '",
   Modified_Nucleic_Acid_QC_Result                ="' . $Modified_Nucleic_Acid_QC_Result1  . '",
   Suppression_Method                             ="' . $Suppression_Method1  . '",
   Suppressed_By                                  ="' . $Suppressed_By1 . '",
   Date_Nucleic_Acid_Suppressed                   ="' . $Date_Nucleic_Acid_Suppressed1 . '",
   Suppressed_Nucleic_Acid_Yield_Nanograms        = "' . $Suppressed_Nucleic_Acid_Yield_Nanograms1 . '",
   Suppressed_Nucleic_Acid_QC_Result              ="' . $Suppressed_Nucleic_Acid_QC_Result1  . '",
   Primer_Set         				  ="' . $Primer_Set_Name1  . '",
   Barcode_Type         			  ="' . $Barcode_Type1  . '",
   Barcode              			  ="' . $Barcode_Name1  . '",
   Primer_Name          			  ="' . $Primer_Name1  . '",
   Library_Preparation_ID_req                     ="' . $Library_Preparation_ID_req1  . '",
   Library_Preparation_Method_req                 ="' . $Library_Preparation_Method_req1 . '",
   Library_Prepared_By_req                        ="' . $Library_Prepared_By_req1 . '",
   Date_Library_Prepared_req                      ="' . $Date_Library_Prepared_By_req1 . '",
   Library_Nucleic_Acid_Input_Nanograms_req       = "' . $Library_Nucleic_Acid_Input_Nanograms_req1 . '", 
   Library_Prep_Final_Volume_Microliters_req      ="' . $Library_Prep_Final_Volume_Microliters_req1  . '",
   Final_Library_Concentration_Nanograms_Microliter_req        ="' . $Final_Library_Concentration_Nanograms_Microliter_req1  . '",
   Library_Nucleic_Acid_QC_Result                 ="' . $Library_Nucleic_Acid_QC_Result1 . '",
   Average_Insert_Size_basepairs                  = "' . $Average_Insert_Size_basepairs1 . '",
   Sequencing_Provider_req                        ="' . $Sequencing_Provider_req1 . '",
   Date_at_Sequencing_Provider_req                ="' . $Date_at_Sequencing_Provider_req1 . '",
   Sent_By_req                                    = "' . $Sent_By_req1 . '",
   Experimentalist_Informatician_notes_upload     = "' . $Experimentalists_notes_upload1 . '",
   fileuploaded                                   = "' . $fileuploaded1 . '",
   filetype                                       = "' . $filetype1 . '",
   createdby                                      = "' . $createdby1 . '",  
   timecreation                                   = "' . $timecreation1 . '",
   modifiedby                                     = "' . $_SESSION['usernam'] . '", 
   timemodified                                   = NOW(),
   track_id                                       ="' . $track_id1 .'",
   track_sample                                   = "' . $track_sample1.'"';


$result = mysql_query($query, $db) or die(mysql_error($db));

echo '<div id="messages">' . 'Sample Processing Data updated for Sample UID = ' . "'$Sample_UID_req1'";



} //if no error
}//else if valid
} //no duplicate

function valid_info() //required
{
$error = '';

if(empty($_POST['Specimen_UID_req'])) {
$error = urlencode('Please enter a Specimen UID.');
echo '<div id="error">' . $error;
}

if(empty($_POST['Purification_Nucleic_Acid_Method_req'])){
 $error = urlencode('Please enter Purification Nucleic Acid Method.');
 echo '<div id="error">' . $error;
}

if(empty($_POST['Purified_By_req'])){
 $error = urlencode('Please enter Purified By.');
 echo '<div id="error">' . $error;
}

if(empty($_POST['Primer_Set'])){
     $error= urlencode('Please enter a Primer Set.');
     echo '<div id="error">' . $error;
 }

if(empty($_POST['Barcode_Name'])){
     $error= urlencode('Please enter a Barcode.');
     echo '<div id="error">' . $error;
 }



 if(!empty($_POST['Library_Nucleic_Acid_Input_Nanograms_req'])){
     if (check_input_float($_POST['Library_Nucleic_Acid_Input_Nanograms_req']) =="FALSO")
     $error= urlencode('Please enter a valid Library Nucleic Acid Input Nanograms.');
     echo '<div id="error">' . $error;
 }

 if(!empty($_POST['Library_Prep_Final_Volume_Microliters_req'])){
     if (check_input_float($_POST['Library_Prep_Final_Volume_Microliters_req']) =="FALSO")
     $error= urlencode('Please enter a valid Library Prep Final Volume Microliters.');
     echo '<div id="error">' . $error;
 }

 if(!empty($_POST['Final_Library_Concentration_Nanograms_Microliter_req'])){
     if (check_input_float($_POST['Final_Library_Concentration_Nanograms_Microliter_req']) =="FALSO")
     $error= urlencode('Please enter a valid Final Library Concentration Nanograms Microliter.');
     echo '<div id="error">' . $error;
 }


if (empty($error)) 
     return TRUE;
else 
   return FALSE;

}// valid_info


function check_date($data)
{

    if(!preg_match('/^(\d\d?)-(\d\d?)-(\d\d\d\d)$/', $data, $matches))
     return "FALSO";
    
    elseif (($matches[1]>=1 && $matches[1]<=12) and  ($matches[2]>=1 && $matches[2]<=31) and ($matches[3]>=1970 && $matches[2]<=2030)) 
   {
   $dob1=trim($data);
   list($m, $d, $y) = explode('-', $dob1);
   $mk=mktime(0, 0, 0, $m, $d, $y);
   $data=strftime('%Y-%m-%d',$mk);
   return $data; 
   }
   return "FALSO";
} //function


function check_input_age($data)
{
  $data = (int)$data;
  if(!is_int($data))
    return "FALSO";
  else
    return $data;
}

function check_input_float($data)
{
 $data = (float) $data;
  if(!is_float($data))
 return "FALSO";
 else
 return $data;
}

function check_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data);
    return $data;
}

function check_inputS($data)
{
    //$data = strip_tags($data);
    $data = trim($data);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $data = htmlspecialchars($data);

if (strlen($data) > 5000) {
    // truncate string
    $stringCut = substr($data, 0, 5000);
    $data= $stringCut;
}   
    return $data;
}

?>

</div>
</body>

</html>






