<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, updateSample.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Sample Processing</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSample.php">Update</a></li> 
<li><a href="consultSample.php">Consult</a></li> 
<li><a href="helpSample.php">Help</a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<BR>&nbsp;<BR>

<?php
session_start();
include_once '../configUser.inc';

if(isset($_POST['Sample_UID_req']) )
{
$_SESSION['Sample_UID_req'] = $_POST['Sample_UID_req'];

} 
 else 
 {
$_SESSION['Sample_UID_req'] ='';
}

    
echo "<h3><span>Update Sample Processing</span></h3>";
echo '<div id="messages2">' . 'Select the Sample Unique ID to Update ';
echo "<table border='1'>
<tr>
  <th>Sample UID </th>
  <th>Sample Alias </th>
  <th>Library Name </th>
  <th>Barcode </th>
  <th>Target Nucleic Acid </th>
  <th>Purification Nucleic Acid Method </th>
  <th>Purified By </th>
  <th>Suppression Method          </th>
</tr>";

include_once '../config.inc'; //data for the connection
$db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//Using the correct database
$db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));

$result = mysql_query("SELECT Sample_UID_req, Sample_Alias_req, Library_Preparation_ID_req, Barcode, Target_Nucleic_Acid_req, Purification_Nucleic_Acid_Method_req, Purified_By_req, Suppression_Method, track_sample FROM (SELECT Sample_UID_req, Sample_Alias_req, Library_Preparation_ID_req, Barcode, Target_Nucleic_Acid_req, Purification_Nucleic_Acid_Method_req, Purified_By_req, Suppression_Method, track_sample FROM HPMB_SampleProcessing ORDER BY Sample_UID_req, track_sample DESC) AS temp2 GROUP by Sample_UID_req ", $db);

while (list($Sample_UID_req, $Sample_Alias_req, $Library_Preparation_ID_req, $Barcode, $Target_Nucleic_Acid_req,$Purification_Nucleic_Acid_Method_req, $Purified_By_req, $Suppression_Method ) = mysql_fetch_row($result)) {
    echo " <tr>\n" ;
      echo "  <td><a href=\"upd2.php?id=$Sample_UID_req\">$Sample_UID_req</a></td>\n" .
          "   <td>$Sample_Alias_req</td>\n" .
          "   <td>$Library_Preparation_ID_req</td>\n" .
          "   <td>$Barcode</td>\n" .
          "   <td>$Target_Nucleic_Acid_req</td>\n" .
          "   <td>$Purification_Nucleic_Acid_Method_req</td>\n" .
          "   <td>$Purified_By_req</td>\n" .
          "   <td>$Suppression_Method</td>\n" .
          " </tr>\n";
}

?>





