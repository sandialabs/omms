<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, generateSampleIdCsv.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/

    session_start();
    include_once('../configUser.inc');
    include_once('../config.inc');

$string = $_GET['id'];
$error = array();
if (!empty($string)){
    $data1 = trim($string);
    $data1 = stripslashes($data1);
    $data1 = strip_tags($data1);
    $Sample_UID_req = htmlspecialchars($data1);
   
 if (empty($error)) { 

    include_once '../config.inc'; //data for the connection
   
    $query1 = 'SELECT * FROM HPMB_SampleProcessing WHERE Sample_UID_req = "' . $data1 . '" ORDER BY timemodified DESC '; 

    $db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');


   //Using the correct database
   $db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));

   $result1 = mysql_query($query1,$db) or die(mysql_error());

   if (!$result1)
   {
    echo '<div id="error">' . 'Error no records exist from database.';
    exit();
   }

  $fields = mysql_num_fields ( $result1 );

 for ( $i = 0; $i < $fields; $i++ )
 {
    $header .= mysql_field_name($result1 , $i ) . ',';
 }

 while( $row = mysql_fetch_row( $result1 ) )
 {
    $line = '';
    foreach( $row as $val  )
    {                                            
        if ( ( !isset( $val  ) ) || ( $val  == "" ) )
        {
            $val  = "\t";
        }
        else
        { 
            $val  = str_replace( '"' , '""' , $val  );
            $val  = '"' . $val  . '"' . ',';
        }
        $line .= $val ;
    }
    $data .= trim( $line ) . "\n";
 }
 $data = str_replace( "\r" , "" , $data );

 if ( $data == "" )
 {
    $data = "\n(0) Records Found!\n";                        
 }

}//empty errors array
} //else no empty UID

$filename = date("Ymd")."_Sampl_$Sample_UID_req.csv";
header("Content-type: application/csv");
header("Content-Disposition: attachment; filename=$filename");
header("Pragma: no-cache");
header("Expires: 0");
print "$header\n$data";

?>




