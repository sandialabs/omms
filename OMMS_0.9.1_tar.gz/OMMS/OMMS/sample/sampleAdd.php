<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, sampleAdd.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/

session_start(); 
$testStg=md5('salt'.microtime());
$_SESSION['testStore']=$testStg;
include_once '../configUser.inc'; //data for valid user and session
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Sample Processing</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSample.php">Update</a></li> 
<li><a href="consultSample.php">Consult</a></li> 
<li><a href="helpSample.php">Help</a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<style type="text/css"><!--
#other{
    display: none;
}
--></style>
<script type="text/javascript"><!--
function checkOther(select){
    if( select[select.selectedIndex].value=="other" ){
        document.getElementById("other").style.display = "inline";
    }else{
        document.getElementById("other").style.display = "none";
    }
}
//--></script>
<?php

if  ($_SESSION['new']=="1"){

$spec1 = $_SESSION['Specimen_UID_req'];
$spec2 = $_SESSION['Specimen_UID_sec'] ;
$sampA = $_SESSION['Sample_Alias_req'];
$nuc1  = $_SESSION['Nucleic_Acid_req'] ;
$targ1 = $_SESSION['Target_Nucleic_Acid_req '] ;
$pur1  = $_SESSION['Purification_Nucleic_Acid_Method_req'] ;
$pur2 =  $_SESSION['Purified_By_req'] ;
$dateN = $_SESSION['Date_Nucleic_Acid_Purified_req'] ;
$pur3  = $_SESSION['Purified_Nucleic_Acid_Yield_Nanograms'] ;//falta, se junto con qc
$res  = $_SESSION['QC_Result'];
$nuc2 = $_SESSION['Nucleic_Acid_Modification_Method'] ;
$nuc3 = $_SESSION['Nucleic_Acid_Modified_By'] ;
$dateM = $_SESSION['Date_Nucleic_Acid_Modified'] ;
$nuc4 = $_SESSION['Modified_Nucleic_Acid_Type'] ;
$nuc5 = $_SESSION['Modified_Nucleic_Acid_Yield_Nanograms'] ;
$nuc6 = $_SESSION['Modified_Nucleic_Acid_QC_Result'] ;
$sup1 = $_SESSION['Suppression_Product_Name'] ;//falta, se junto con qc
$sup2 = $_SESSION['Suppression_Method'] ;
$sup3 = $_SESSION['Suppressed_By'] ;
$dateSu = $_SESSION['Date_Nucleic_Acid_Suppressed'] ;
$sup4 = $_SESSION['Suppressed_Nucleic_Acid_Yield_Nanograms'] ;
$sup5 = $_SESSION['Suppressed_Nucleic_Acid_QC_Result'] ;
$prims = $_SESSION['Primer_Set'];
$bart  = $_SESSION['Barcode_Type'];
$bar   = $_SESSION['Barcode'];
$primn = $_SESSION['Primer_Name'];
$lib1 = $_SESSION['Library_Preparation_ID_req'] ;
$lib2 = $_SESSION['Library_Preparation_Method_req'];
$lib3 = $_SESSION['Library_Prepared_By_req'] ;
$dateL = $_SESSION['Date_Library_Prepared_req'] ;
$lib4 = $_SESSION['Library_Nucleic_Acid_Input_Nanograms_req'];
$lib5 = $_SESSION['Library_Prep_Final_Volume_Microliters_req'] ;
$lib6 = $_SESSION['Final_Library_Concentration_Nanograms_Microliter_req'] ;
$lib7 = $_SESSION['Library_Nucleic_Acid_QC_Result'] ;
$avg = $_SESSION['Average_Insert_Size_basepairs'] ;
$seqP = $_SESSION['Sequencing_Provider_req'] ;
$dateSe = $_SESSION['Date_at_Sequencing_Provider_req'];
$sent = $_SESSION['Sent_By_req'];

}
else 
{
$spec1 = '';
$spec2 = '';
$sampA ='';
$nuc1  ='';
$targ1 ='';
$pur1  = '';
$pur2 =  '';
$dateN = '';
$pur3  = '';
$res  = '';
$nuc2 = '';
$nuc3 = '';
$dateM = '';
$nuc4 = '';
$nuc5 = '';
$nuc6 = '';
$sup1 = '';
$sup2 = '';
$sup3 = '';
$dateSu ='';
$sup4 = '';
$sup5 = '';
$prims = '';
$primsn = '';
$bart  = '';
$bar   = '';
$primn = '';
$lib1 ='';
$lib2 = '';
$lib3 = '';
$dateL = '';
$lib4 = '';
$lib5 = '';
$lib6 = '';
$lib7 = '';
$avg = '';
$seqP = '';
$dateSe = '';
$sent = '';
}

include_once '../config.inc'; //data for the connection
$db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//Using the correct database
$db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));

$sql='SELECT Specimen_UID_req FROM HPMB_SpecimenInfo GROUP by Specimen_UID_req';
$result=mysql_query($sql);
$result1=mysql_query($sql);

$sql2a="SELECT Primer_Set_Name FROM PrimerSets";
$result2a=mysql_query($sql2a);


$sql2="SELECT Primer_Name, Primer_Id FROM Primers";
$result2b=mysql_query($sql2);


$sql3="SELECT Barcode_Name,Barcode_Seq FROM Barcode";
$result3=mysql_query($sql3);

?>

<title> Add Sample </title>
</head>
<body>
   <BR>&nbsp;<BR>
         <form id="form2" action="createSample.php" method="post" enctype="multipart/form-data">     
              <h3><span> Add Sample</span></h3>
              <fieldset><legend>Create Sample</legend>

<p>
  <select name=Specimen_UID_req>
 <option value=<?php echo $spec1 ;?>>Specimen UID (*). (*) REQUIRED : <?php echo $spec1 ;?></option>
<?php
while ($row = mysql_fetch_array($result)) {
?>
<option value=<?php echo $row['Specimen_UID_req']; ?>><?php echo $row['Specimen_UID_req']; ?></option>
<?php } ?> 
</select>
</p>

<p>
  <select name=Specimen_UID_sec>
 <option value=<?php echo $spec2 ;?>>Specimen UID secondary : <?php echo $spec2 ;?></option>
<?php
while ($row1 = mysql_fetch_array($result1)) {
?>
<option value=<?php echo $row1['Specimen_UID_req']; ?>><?php echo $row1['Specimen_UID_req']; ?></option>
<?php } ?> 
</select>
</p>


                   <p>
                        <label for="Sample_Alias_req">Sample Alias </label>
                        <input type="text" size="30" maxlength="30" name="Sample_Alias_req" id="Sample_Alias_req" value="<?php  echo $sampA ; ?>" />
                  </p>                         

                   <p>
                   <label for="Nucleic_Acid_req">Nucleic Acid </label>
                   <input type="text" size="30" maxlength="30" name="Nucleic_Acid_req" id="Nucleic_Acid_req" value="<?php  echo $nuc1 ; ?>" />

                   </p>     

		   <p>		
                        <label for="Target_Nucleic_Acid_req">Target Nucleic Acid  </label>
                        <input type="text" size="30" maxlength="30" name="Target_Nucleic_Acid_req" id="Target_Nucleic_Acid_req" value="<?php  echo $targ1 ; ?>" />
                   </p>    
    
		   <p>
                       <select name=Purification_Nucleic_Acid_Method_req onchange="checkOther(this)">
                       <option VALUE="<?php  echo $pur1 ; ?>">Purification Method (*) : <?php  echo $pur1 ; ?>
                       <option value="DNA">DNA</option>
                       <option value="total RNA">total RNA</option>
                       <option value="mRNA">mRNA</option>
                       <option value="small RNA">small RNA</option>
                       <option value="other">Other</option>
                       </select>
                       <input id="other" type="text" size="100" maxlength="100" name="other_purif" />
                   </p>         
 

		   <p>
                        <label for="Purified_By_req">Purified By (*) </label>
                        <input type="text" size="30" maxlength="30" name="Purified_By_req" id="Purified_By_req" value="<?php  echo $pur2; ?>" />
                   </p>     

		  <p>
		  <select name=Primer_Set>
		  <option value=<?php echo $prims ;?>>Primer Set (*) :<?php echo $prims ;?></option>
<?php
while ($row2a = mysql_fetch_array($result2a)) {
?>
<option value=<?php echo $row2a['Primer_Set_Name']; ?>><?php echo $row2a['Primer_Set_Name']; ?></option>
<?php } ?> 
</select>
</p>

		<p>
 	 	<select name=Primer_Name>
 	 	<option value=<?php echo $primn ;?>>Primer Name : <?php echo $primn ;?></option>
<?php
while ($row2b= mysql_fetch_array($result2b)) {
?>
<option value=<?php echo $row2b['Primer_Name']; ?>><?php echo $row2b['Primer_Name'];  ?></option>
<?php } ?> 
</select>
</p>



                    <p>
                     <select name=Barcode_Type>
                       <option VALUE=<?php echo $bart; ?>>Barcode Type: <?php echo $bart; ?>  
                       <option value="internal">internal</option>
                       <option value="external">external</option>
                     </select>
                   </p>     

<p>
 <select name=Barcode_Name>
  <option value=<?php echo $bar;?>>Barcode (*) : <?php echo $bar;?></option>
<?php
while ($row3 = mysql_fetch_array($result3)) {
?>
<option value=<?php echo $row3['Barcode_Name'];?>><?php echo $row3['Barcode_Name']; ?></option>
<?php } ?> 
</select>
</p>



                     <p>
                        <label for="Date_Nucleic_Acid_Purified_req">Date Nucleic Acid Purified. Format (mm-dd-yyyy)</label>
                        <input type="text" size="10" maxlength="10" name="Date_Nucleic_Acid_Purified_req" id="Date_Nucleic_Acid_Purified_req" value="<?php  echo $dateN; ?>" />
                                    </p>                                                                                                         

		  <p>
 		 <tr>
   		 <th><label for="QC_Result">QC Notes Purification</label></th>
     		 <td><textarea name="QC_Result" id="QC_Result"maxlength="5000"  wrap="hard" value= <?php  echo '<textarea>'.$res.'</textarea>'; ?> </textarea></td>
   		 </tr>
		 </p>
  
  		 <p>
                       <select name=Nucleic_Acid_Modification_Method>
                       <option VALUE="<?php  echo $nuc2; ?>">Modification Method:<?php  echo $nuc2; ?>
                       <option value="size selection">size selection</option>
                       <option value="cDNA synthesis">cDNA synthesis</option>
                       <option value="RiboZero">RiboZero</option>
                       <option value="RiboMinus">RiboMinus</option>
                       <option value="polyA tailing">polyA tailing</option>
                       <option value="polyA capture">polyA capture</option>
                       </select>
                  </p>  

   
		  <p>
                        <label for="Nucleic_Acid_Modified_By">Nucleic Acid Modified By</label>
                        <input type="text" size="30" maxlength="100" name="Nucleic_Acid_Modified_By" id="Nucleic_Acid_Modified_By" value="<?php  echo $nuc3; ?>"/>
                  </p>     


		  <p>
                        <label for="Date_Nucleic_Acid_Modified">Date Nucleic Acid Modified. Format (mm-dd-yyyy)</label>
                        <input type="text" size="10" maxlength="10" name="Date_Nucleic_Acid_Modified" id="Date_Nucleic_Acid_Modified" value="<?php  echo $dateM; ?>"/>
		 </p>  


		 <p>
                        <label for="Modified_Nucleic_Acid_Type">Modification Product</label>
                        <input type="text" size="30" maxlength="30" name="Modified_Nucleic_Acid_Type" id="Modified_Nucleic_Acid_Type" value="<?php  echo $nuc4; ?>"/>
                 </p>     

		 <p>
                        <label for="Modified_Nucleic_Acid_Yield_Nanograms">Modified Nucleic Acid Yield Nanograms</label>
                        <input type="text" size="30" maxlength="30" name="Modified_Nucleic_Acid_Yield_Nanograms" id="Modified_Nucleic_Acid_Yield_Nanograms" value="<?php  echo $nuc5; ?>"/>
                 </p>     

		<p>
		<tr>
  		<th><label for="Modified_Nucleic_Acid_QC_Result">QC Notes Modification</label></th>
      		<td><textarea name="Modified_Nucleic_Acid_QC_Result" id="Modified_Nucleic_Acid_QC_Result" maxlength="5000"  wrap="hard" value= <?php  echo '<textarea>'.$nuc6.'</textarea>'; ?></textarea></td>
    		</tr>
		</p>

		<p>
                       <select name=Suppression_Method>
                       <option VALUE="<?php  echo $sup2; ?>">Suppression Method: <?php  echo $sup2; ?>
                       <option value="hydroxyapatite spin-column">hydroxyapatite spin-column</option>
                       <option value="capture">capture</option>
                       </select>
                </p> 


		<p>
                        <label for="Suppressed_By">Suppressed By</label>
                        <input type="text" size="30" maxlength="30" name="Suppressed_By" id="Suppressed_By" value="<?php  echo $sup3; ?>"/>
                </p>   
         	
		<p>
                        <label for="Date_Nucleic_Acid_Suppressed">Date Nucleic Acid Suppressed. Format (mm-dd-yyyy)</label>
                        <input type="text" size="10" maxlength="10" name="Date_Nucleic_Acid_Suppressed" id="Date_Nucleic_Acid_Suppressed" value="<?php  echo $dateSu; ?>"/>
		</p>                                                                                                         

                
		<p>
                        <label for="Suppressed_Nucleic_Acid_Yield_Nanograms">Suppressed Nucleic Acid Yield Nanograms</label>
                        <input type="text" size="10" maxlength="10" name="Suppressed_Nucleic_Acid_Yield_Nanograms" id="Suppressed_Nucleic_Acid_Yield_Nanograms" value="<?php  echo $sup4; ?>"/>
                </p>     


 		<p>
 		<tr>
  	        <th><label for="Suppressed_Nucleic_Acid_QC_Result">QC Notes Suppression</label></th>
      		<td><textarea name="Suppressed_Nucleic_Acid_QC_Result" id="Suppressed_Nucleic_Acid_QC_Result" maxlength="5000"  wrap="hard"  value= <?php  echo '<textarea>'.$sup5.'</textarea>'; ?> </textarea></td>
    		</tr>
		</p>
  

		<p>
                        <label for="Library_Preparation_ID_req">Library Name </label>
                        <input type="text" size="30" maxlength="30" name="Library_Preparation_ID_req" id="Library_Preparation_ID_req" value="<?php  echo $lib1; ?>" />

                </p>     


		<p>
                       <select name=Library_Preparation_Method_req>
                       <option VALUE="<?php  echo $lib2; ?>">Library Preparation Method: <?php  echo $lib2; ?>
                       <option value="nuGEN">nuGEN</option>
                       <option value="Nextera">Nextera</option>
                       </select>
                </p>         
 

		<p>
                        <label for="Library_Prepared_By_req">Library Prepared By </label>
                        <input type="text" size="30" maxlength="30" name="Library_Prepared_By_req" id="Library_Prepared_By_req" value="<?php  echo $lib3; ?>"/>                  
		</p>     

   		 <p>
                        <label for="Date_Library_Prepared_req">Date Library Prepared. Format (mm-dd-yyyy)</label>
                        <input type="text" size="10" maxlength="10" name="Date_Library_Prepared_req" id="Date_Library_Prepared_req" value="<?php  echo $dateL; ?>"/>
                 <p>             

		<p>
                        <label for="Library_Nucleic_Acid_Input_Nanograms_req">Library Nucleic Acid Input Nanograms </label>
                        <input type="text" size="10" maxlength="10" name="Library_Nucleic_Acid_Input_Nanograms_req" id="Library_Nucleic_Acid_Input_Nanograms_req" value="<?php  echo $lib4; ?>"/>
               </p>     

		<p>
                        <label for="Library_Prep_Final_Volume_Microliters_req">Library Prep Final Volume Microliters </label>
                        <input type="text" size="10" maxlength="10" name="Library_Prep_Final_Volume_Microliters_req" id="Library_Prep_Final_Volume_Microliters_req" value="<?php  echo $lib5; ?>"/>
               </p>     

		<p>
                        <label for="Final_Library_Concentration_Nanograms_Microliter_req">Final Library Concentration Nanograms Microliter </label>
                        <input type="text" size="10" maxlength="10" name="Final_Library_Concentration_Nanograms_Microliter_req" id="Final_Library_Concentration_Nanograms_Microliter_req" value="<?php  echo $lib6; ?>"/>
                </p>     

		<p>
 <tr>
      <th><label for="Library_Nucleic_Acid_QC_Result">QC Notes Library</label></th>
      <td><textarea name="Library_Nucleic_Acid_QC_Result" id="Library_Nucleic_Acid_QC_Result" maxlength="5000"  wrap="hard" value= <?php  echo '<textarea>'.$lib7.'</textarea>'; ?> </textarea></td>
    </tr>
		</p>


		<p>
                        <label for="Average_Insert_Size_basepairs">Average Insert Size basepairs</label>
                        <input type="text" size="10" maxlength="10" name="Average_Insert_Size_basepairs" id="Average_Insert_Size_basepairs" value="<?php  echo $avg; ?>" />

               </p>  

		<p>
                        <label for="Sequencing_Provider_req">Sequencing Provider </label>
                        <input type="text" size="30" maxlength="30" name="Sequencing_Provider_req" id="Sequencing_Provider_req" value="<?php  echo $seqP; ?>" />
               </p>     

                <p>
                      <label for="Date_at_Sequencing_Provider_req">Date at Sequencing Provider. Format (mm-dd-yyyy)</label>
                      <input type="text" size="10" maxlength="10" name="Date_at_Sequencing_Provider_req" id="Date_at_Sequencing_Provider_req" value="<?php  echo $dateSe; ?>" />
                </p>               

                <p>
                        <label for="Sent_By_req">Sent By</label>
                        <input type="text" size="30" maxlength="30" name="Sent_By_req" id="Sent_By_req" value="<?php  echo $sent; ?>"/>
                </p>     
   

		<p>
                        <label for="Experimentalist_Informatician_notes_upload">Upload notes: </label>
                        <input type="file" accept="text/txt" name="Experimentalist_Informatician_notes_upload" id="Experimentalist_Informatician_notes_upload" />                   
		</p>     
         

		<p>
                <input type="hidden" name="testStore" value=<?php echo $testStg ;?> />     
		</p>
          
                <p class="submit"><button type="submit">Add Sample</button></p>   
                          
                <input type="hidden" name="submit" value="1"/>
                   
              </fieldset>                         
                             
         </form>     
  </body>
</html>



