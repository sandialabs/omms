<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, cons2new.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Sample Processing</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li id="active"><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSample.php">Update</a></li> 
<li><a href="consultSample.php">Consult</a></li> 
<li><a href="helpSample.php">Help</a></li> 
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 
</ul> 
</div> 
<BR>&nbsp;<BR>

<?php 
$string = $_GET['id'];
$error = array();
if (!empty($string)){
    $data = trim($string);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $Sample_UID_req = htmlspecialchars($data);
   
   if (empty($error)) { //check where it is closed

   include_once '../config.inc'; //data for the connection
   $db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

   //Using the correct database
   $db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));

   $query2 = 'SELECT * FROM HPMB_SampleProcessing WHERE Sample_UID_req = "' . $data . '" ORDER BY timemodified DESC LIMIT 1'; 

 $result2 = mysql_query($query2,$db) or die(mysql_error());
  if (!$result2)
  {
    echo '<div id="error">' . 'Error no such record exist from database.';
    exit();
  }
 
  $total =mysql_num_rows($result2);
  if ($total == 0)
  {
  echo '<div id="error">' . 'Error no such record exist from database.';
  exit();
  }

$message = "<a href=\"generateSampleIdCvs.php?id=$Sample_UID_req\">Spreadsheet for full sample history</a>";
echo $message;
echo "<table border='1'>
<tr>
</tr>";

while($row = mysql_fetch_array($result2))
  {
  echo "<tr>";
  echo " <th>Sample UID</th>";
  echo "<td>" . $row['Sample_UID_req'] . "</td>";
  echo "<tr>";
  echo " <th>Sample Alias</th>";
  echo "<td>" . $row['Sample_Alias_req'] . "</td>";
  echo "<tr>";
  echo " <th>Specimen UID</th>"; 
  echo "<td>" . $row['Specimen_UID_req'] . "</td>";
  echo "<tr>";
  echo "<th>Specimen sec</th>"; 
  echo "<td>" . $row['Specimen_UID_sec'] . "</td>";
  echo "<tr>";
  echo "<th>Nucleic Acid</th>"; 
  echo "<td>" . $row['Nucleic_Acid_req'] . "</td>";
  echo "<tr>";
  echo "<th>Target Nucleic Acid</th>"; 
  echo "<td>" . $row['Target_Nucleic_Acid_req'] . "</td>";
  echo "<tr>";
  echo " <th>Purification Method</th>";
  echo "<td>" . $row['Purification_Nucleic_Acid_Method_req'] . "</td>";
  echo "<tr>";
  echo " <th>Purified By</th>";
  echo "<td>" . $row['Purified_By_req'] . "</td>";
  echo "<tr>";
  echo " <th>Date Nucleic Acid Purified</th>";
  echo "<td>" . change_date_format( $row['Date_Nucleic_Acid_Purified_req']) . "</td>";
  echo "<tr>";
  echo "<th>Library Name</th>"; 
  echo "<td>" . $row['Library_Preparation_ID_req'] . "</td>";
  echo "<tr>";
  echo " <th>Library Preparation Method</th>";
  echo "<td>" . $row['Library_Preparation_Method_req'] . "</td>";
  echo "<tr>";
  echo " <th>Library Prepared By</th>";
  echo "<td>" . $row['Library_Prepared_By_req'] . "</td>";
  echo "<tr>";
  echo " <th>Library Nucleic Acid Input Nanograms</th>";
  echo "<td>" . $row['Library_Nucleic_Acid_Input_Nanograms_req'] . "</td>";
  echo "<tr>";
  echo " <th>Library Prep Final Volume Microliters</th>";
  echo "<td>" . $row['Library_Prep_Final_Volume_Microliters_req'] . "</td>";
  echo "<tr>";
  echo " <th>Final Library Concentration Nanograms Microliter </th>";
  echo "<td>" . $row['Final_Library_Concentration_Nanograms_Microliter_req'] . "</td>" ;
  echo "<tr>";
  echo " <th>Sequencing Provider</th>";
  echo "<td>" . $row['Sequencing_Provider_req'] . "</td>";
  echo "<tr>";
  echo " <th>Date at Sequencing Provider</th>"; 
  echo "<td>" . change_date_format( $row['Date_at_Sequencing_Provider_req']) . "</td>" ;
  echo "<tr>";
  echo " <th>Sent By</th>";
  echo "<td>" . $row['Sent_By_req'] . "</td>" ;
  echo "<tr>";
  echo "<th>Experimentalist Notes</th>";
  echo "<td><a href='consNotes.php?id=" . $row['Sample_UID_req'] ."'>". $row['Experimentalist_Informatician_notes_upload'] ."</a></td>";
  echo "<tr>";
  echo " <th>Created By</th>"; 
  echo "<td>" . $row['createdby'] . "</td>";
  echo "<tr>";
  echo " <th>Time Creation</th>";
  echo "<td>" . $row['timecreation'] . "</td>" ;
  echo "<tr>";
  echo " <th>Modified By</th>"; 
  echo "<td>" . $row['modifiedby'] . "</td>" ;
  echo "<tr>";
  echo " <th>Time Modified</th>";
  echo "<td>" . $row['timemodified'] . "</td>" ;
  echo "<tr>";
  //echo "<th>Sample track</th>"; 
  //echo "<td>" . $row['track_sample'] . "</td>" ;
  //echo "</tr>";
  }
echo "</table>";

mysql_close($db);



}//empty errors array
} //else no empty UID

function change_date_format($data){

       list($year,$month,$day) = explode("-",$data);
       $newdata = $month."-".$day."-".$year;
       return $newdata;
}
?>
