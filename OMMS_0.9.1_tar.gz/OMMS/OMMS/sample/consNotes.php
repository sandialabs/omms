<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, consNotes.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/

session_start(); 
$string = $_GET['id'];
$error = array();
if (!empty($string)){
    $data = trim($string);
    $data = stripslashes($data);
    $data = strip_tags($data);
    $Sample_UID_req = htmlspecialchars($data);
   
 if (empty($error)) { 

include_once '../config.inc'; //data for the connection
$db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//Using the correct database
 $db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));

$query2 = 'SELECT * FROM HPMB_SampleProcessing WHERE Sample_UID_req = "' . $data . '" ORDER BY timemodified desc LIMIT 1'; 

 $result2 = mysql_query($query2,$db) or die(mysql_error());
  if (!$result2)
  {
    echo '<div id="error">' . 'Error no such record exist from database.';
    exit();
  }
     $total =mysql_num_rows($result2);
if ($total == 0)
{
echo '<div id="error">' . 'Error no such record exist from database.';
exit();
}

$notes = mysql_result($result2,0,"fileuploaded");
$nameN = mysql_result($result2,0,"Experimentalist_Informatician_notes_upload");
$typeN = mysql_result($result2,0,"filetype");



header ("Content-type: $typeN");
header ("Content-Disposition: attachment; filename=$nameN");
header ("Content-Description: PHP Generated Data");
echo $notes;



mysql_close($db);

}//empty errors array
} //else no empty UID


?>


