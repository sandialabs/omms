<?php
/*
Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

This file, sampleAddSpecID.php, is part of the OMMS.

The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.
*/

session_start(); 
$testStg=md5('salt'.microtime());
$_SESSION['testStore']=$testStg;
include_once '../configUser.inc';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>OMMS </title> 
<link rel="stylesheet" type="text/css" href="../style.css" /> 
</head> 
<body> 
<div id="wrap"> 
<div id="header"> 
<div id="logo"> 
<h1 class="lineone">Sample Processing</h1> 
<h2 class="lineone"></h2> 
<h3 class="lineone"></h3> 
</div> 
</div> 
<div id ="navigation"> 
<ul> 
<li id="active"><a href="../index.rap.php" >Home</a></li>
<li ><a  onClick="history.go(-1);" id="current">Back</a></li>
<li><a href="selectAdd.php">Create New</a></li>
<li><a href="updateSample.php">Update</a></li> 
<li><a href="consultSample.php">Consult</a></li>
<li><a href="helpSample.php">Help</a></li>  
<li class="last"><a href="../login/indexLogout.php">Logout</a></li> 

</ul> 
</div> 
<style type="text/css"><!--
#other{
    display: none;
}
--></style>
<script type="text/javascript"><!--
function checkOther(select){
    if( select[select.selectedIndex].value=="other" ){
        document.getElementById("other").style.display = "inline";
    }else{
        document.getElementById("other").style.display = "none";
    }
}
//--></script>
<?php 
$string = $_GET['id'];
$error = array();
if (!empty($string)){
    $data = trim($string);
    $data = stripslashes($data);
    $data = strip_tags($data);
   
 if (empty($error)) { 

include_once '../config.inc'; //data for the connection
$db = mysql_connect($hostname, $username, $password) or
    die ('Unable to connect. Check your connection parameters.');

//Using the correct database
 $db1 = mysql_select_db($dbname,$db) or die(mysql_error($db));
$query1 = 'SELECT COUNT(Sample_UID_req) AS Uid FROM HPMB_SampleProcessing WHERE Sample_UID_req="' . $data . '" '; 

 $result1 = mysql_query($query1,$db) or die(mysql_error($db));
  if (!$result1)
  {
    echo '<div id="error">' . 'Error no such record exist from database.';
    exit();
  }
    $row = mysql_fetch_array($result1);
    $total =mysql_result($result1, 0, 0);
if ($total == 0)
{
echo '<div id="error">' . 'Error no such record exist from database.';
exit();
}

$query2 = 'SELECT * FROM HPMB_SampleProcessing WHERE Sample_UID_req = "' . $data . '" AND track_sample = "'
 . $total .'"'; 

 $result2 = mysql_query($query2,$db) or die(mysql_error());
  if (!$result2)
  {
    echo 'Error selecting records from database.';
    exit();
  }
    
    $row2 = mysql_fetch_array($result2);
    $Sample_UID_req = $data;
    $Specimen_UID_req = "$row2[Specimen_UID_req]"; 
    $Specimen_UID_sec = "$row2[Specimen_UID_sec]";
    $Sample_Alias_req = "$row2[Sample_Alias_req]"; 
    $Nucleic_Acid_req = "$row2[Nucleic_Acid_req]";
    $Target_Nucleic_Acid_req = "$row2[Target_Nucleic_Acid_req]";
    $Purification_Nucleic_Acid_Method_req = "$row2[Purification_Nucleic_Acid_Method_req]";
    $Purified_By_req = "$row2[Purified_By_req]";

    if ($row2['Date_Nucleic_Acid_Purified_req'] == '0000-00-00' ) {$Date_Nucleic_Acid_Purified_req='00-00-0000'; }
    else { $Date_Nucleic_Acid_Purified_req = change_date_format( $row2['Date_Nucleic_Acid_Purified_req']);}
    $QC_Result           = "$row2[QC_Result]";
    $Nucleic_Acid_Modification_Method    = "$row2[Nucleic_Acid_Modification_Method]";
    $Nucleic_Acid_Modified_By          = "$row2[Nucleic_Acid_Modified_By]";
    if ($row2['Date_Nucleic_Acid_Modified'] == '0000-00-00' ) {$Date_Nucleic_Acid_Modified='00-00-0000'; }
    else { $Date_Nucleic_Acid_Modified = change_date_format( $row2['Date_Nucleic_Acid_Modified']); }
    $Modified_Nucleic_Acid_Type = "$row2[Modified_Nucleic_Acid_Type]";
    $Modified_Nucleic_Acid_Yield_Nanograms = "$row2[Modified_Nucleic_Acid_Yield_Nanograms]";
    $Modified_Nucleic_Acid_QC_Result    = "$row2[Modified_Nucleic_Acid_QC_Result]";
    $Suppression_Method          = "$row2[Suppression_Method]";
    $Suppressed_By          = "$row2[Suppressed_By]";
    if ($row2['Date_Nucleic_Acid_Suppressed'] == '0000-00-00' ) {$Date_Nucleic_Acid_Suppressed='00-00-0000'; }
    else { $Date_Nucleic_Acid_Suppressed = change_date_format( $row2['Date_Nucleic_Acid_Suppressed']);}
    $Suppressed_Nucleic_Acid_Yield_Nanograms = "$row2[Suppressed_Nucleic_Acid_Yield_Nanograms]";
    $Suppressed_Nucleic_Acid_QC_Result      = "$row2[Suppressed_Nucleic_Acid_QC_Result]";
    $prims = "$row2[Primer_Set]";
    $bart  = "$row2[Barcode_Type]";
    $bar   = "$row2[Barcode]";
    $primn = "$row2[Primer_Name]";
    $Library_Preparation_ID_req   = "$row2[Library_Preparation_ID_req]";
    $Library_Preparation_Method_req    = "$row2[Library_Preparation_Method_req]";
    $Library_Prepared_By_req        = "$row2[Library_Prepared_By_req]";
    if ($row2['Date_Library_Prepared_req'] == '0000-00-00' ) {$Date_Library_Prepared_req='00-00-0000'; }
    else {$Date_Library_Prepared_req      = "$row2[Date_Library_Prepared_req]"; }
    $Library_Nucleic_Acid_Input_Nanograms_req        = "$row2[Library_Nucleic_Acid_Input_Nanograms_req]";
    $Library_Prep_Final_Volume_Microliters_req   = "$row2[Library_Prep_Final_Volume_Microliters_req]";
    $Final_Library_Concentration_Nanograms_Microliter_req = "$row2[Final_Library_Concentration_Nanograms_Microliter_req]";
    $Library_Nucleic_Acid_QC_Result          = "$row2[Library_Nucleic_Acid_QC_Result]";
    $Average_Insert_Size_basepairs          = "$row2[Average_Insert_Size_basepairs]";
    $Sequencing_Provider_req         = "$row2[Sequencing_Provider_req]";
    if ($row2['Date_at_Sequencing_Provider_req'] == '0000-00-00' ) {$Date_at_Sequencing_Provider_req='00-00-0000'; }
    else { $Date_at_Sequencing_Provider_req = change_date_format( $row2['Date_at_Sequencing_Provider_req']); }
    $Sent_By_req         = "$row2[Sent_By_req]";
    $Experimentalists_notes_upload = "$row2[Experimentalist_Informatician_notes_upload]";
    $fileuploaded         =  "$row2[fileuploaded]";
    $filetype             = "$row2[filetype]";


$sql2a="SELECT Primer_Set_Name FROM PrimerSets";
$result2a=mysql_query($sql2a);

$sql2="SELECT Primer_Name, Primer_Id FROM Primers";
$result2b=mysql_query($sql2);

$sql3="SELECT Barcode_Name,Barcode_Seq FROM Barcode";
$result3=mysql_query($sql3);

}//empty errors array
} //else no empty UID
?>

<title> Create Sample </title>
</head>

<body>
       <BR>&nbsp;<BR>
         <form id="form2" action="createSample.php" method="post" enctype="multipart/form-data">     
              <h3><span> Create Sample</span></h3>

                <fieldset><legend>Create Sample</legend>
                 
                   <p class="first">
                        <label for="Specimen_UID_req" >Specimen UID (*). (*) REQUIRED</label>
                        <input type="text" size="30" maxlength="30" name="Specimen_UID_req" id="Specimen_UID_req" value=<?php $one = substr($Specimen_UID_req, 0, 30); if ($one !='') echo $one ; else echo "&nbsp;"; ?> />
                   </p>

                  <p>
                        <label for="Specimen_UID_sec">Specimen UID secondary</label>
                        <input type="text" size="30" maxlength="30" name="Specimen_UID_sec" id="Specimen_UID_sec" value=<?php $two = substr($Specimen_UID_sec, 0, 30);  echo "'$two'";?>/>
                   </p>   

                  
                   <p>
                        <label for="Sample_Alias_req">Sample Alias</label>
                        <input type="text" size="30" maxlength="30" name="Sample_Alias_req" id="Sample_Alias_req" value=<?php $three = substr($Sample_Alias_req, 0, 30);  echo "'$three'";?>/>
                   </p>                         

                   <p>
                        <label for="Nucleic_Acid_req">Nucleic Acid </label>
                        <input type="text" size="30" maxlength="30" name="Nucleic_Acid_req" id="Nucleic_Acid_req" value=<?php $four = substr($Nucleic_Acid_req, 0, 30);  echo "'$four'";?>/>
                   </p>     

<p>
                        <label for="Target_Nucleic_Acid_req">Target Nucleic Acid </label>
                        <input type="text" size="30" maxlength="30" name="Target_Nucleic_Acid_req" id="Target_Nucleic_Acid_req" value=<?php $five = substr($Target_Nucleic_Acid_req, 0, 30);  echo "'$five'";?> />
                   </p>     

<p>
                       <select name=Purification_Nucleic_Acid_Method_req onchange="checkOther(this)">
                       <option VALUE=<?php $six = substr($Purification_Nucleic_Acid_Method_req, 0, 30);  echo "'$six'"; ?>>Purification Method (*): <?php  echo $six; ?>
                       <option value="DNA">DNA</option>
                       <option value="total RNA">total RNA</option>
                       <option value="mRNA">mRNA</option>
                       <option value="small RNA">small RNA</option>
                       <option value="other">Other</option>
                       </select>
                       <input id="other" type="text" size="100" maxlength="100" name="other_purif" />
                   </p>      


                   <p>
                        <label for="Purified_By_req">Purified By (*)</label>
                        <input type="text" size="30" maxlength="30" name="Purified_By_req" id="Purified_By_req" value=<?php $seven = substr($Purified_By_req, 0, 30);  echo "'$seven'";?> />
                   </p>     

<p>
 <select name=Primer_Set>
 <option value=<?php echo $prims ;?>>Primer Set (*) Required:<?php echo $prims ;?></option>
<?php
while ($row2a = mysql_fetch_array($result2a)) {
?>
<option value=<?php echo $row2a['Primer_Set_Name']; ?>><?php echo $row2a['Primer_Set_Name']; ?></option>
<?php } ?> 
</select>
</p>

<p>
 <select name=Primer_Name>
 <option value=<?php echo $primn ;?>>Primer Name :  <?php echo $primn ;?></option>
<?php
while ($row2b = mysql_fetch_array($result2b)) {
?>
<option value=<?php echo $row2b['Primer_Name']; ?>><?php echo $row2b['Primer_Name'];  ?></option>
<?php } ?> 
</select>
</p>

                    <p>
                     <select name=Barcode_Type>
                       <option VALUE= <?php echo $Barcode_Type; ?>>Barcode Type: <?php echo $bart; ?> 
                       <option value="internal">internal</option>
                       <option value="external">external</option>
                     </select>
                   </p>     

<p>
 <select name=Barcode_Name>
  <option value=<?php echo $bar;?>>Barcode (*) Required: <?php echo $bar;?></option>
<?php
while ($row3 = mysql_fetch_array($result3)) {
?>
<option value=<?php echo $row3['Barcode_Name'];?>><?php echo $row3['Barcode_Name']; ?></option>
<?php } ?> 
</select>
</p>

                  <p>
                    <label for="Date_Nucleic_Acid_Purified_req">Date Nucleic Acid Purified. Format (mm-dd-yyyy)</label>
                    <input type="text" size="10" maxlength="10" name="Date_Nucleic_Acid_Purified_req" id="Date_Nucleic_Acid_Purified_req" value=<?php if ($Date_Nucleic_Acid_Purified_req !='') echo $Date_Nucleic_Acid_Purified_req ; else echo "&nbsp;";?> />                                    			  </p>                                                                                                        


		<p>
 		<tr>
  	 	<th><label for="QC_Result">QC Notes Purification</label></th>
      		<td><textarea name="QC_Result" id="QC_Result" maxlength="5000"  wrap="hard" value= <?php  echo '<textarea>'.$QC_Result.'</textarea>'; ?>  </textarea></td>
    		</tr>
		</p>


 		<p>
                       <select name=Nucleic_Acid_Modification_Method>
                       <option VALUE=<?php $six1=substr($Nucleic_Acid_Modification_Method,0,30); echo "'$six1'";?>>Modification Method: <?php echo $six1; ?>
                       <option value="size selection">size selection</option>
                       <option value="cDNA synthesis">cDNA synthesis</option>
                       <option value="RiboZero">RiboZero</option>
                       <option value="RiboMinus">RiboMinus</option>
                       <option value="polyA tailing">polyA tailing</option>
                       <option value="polyA capture">polyA capture</option>
                       </select>
                </p>  

    
		<p>
                        <label for="Nucleic_Acid_Modified_By">Nucleic Acid Modified By</label>
                        <input type="text" size="30" maxlength="30" name="Nucleic_Acid_Modified_By" id="Nucleic_Acid_Modified_By" value=<?php $twelve = substr($Nucleic_Acid_Modified_By, 0, 30);  echo "'$twelve'";?> />
                </p>     


		  <p>

                        <label for="Date_Nucleic_Acid_Modified">Date Nucleic Acid Modified. Format (mm-dd-yyyy)</label>
                        <input type="text" size="10" maxlength="10" name="Date_Nucleic_Acid_Modified" id="Date_Nucleic_Acid_Modified" value=<?php if ($Date_Nucleic_Acid_Modified !='') echo $Date_Nucleic_Acid_Modified ; else echo "&nbsp;";?> />
                  </p>  


		   <p>

                        <label for="Modified_Nucleic_Acid_Type">Modification Product</label>
                        <input type="text" size="30" maxlength="30" name="Modified_Nucleic_Acid_Type" id="Modified_Nucleic_Acid_Type" value=<?php $thirteen = substr($Modified_Nucleic_Acid_Type, 0, 30);  echo "'$thirteen'";?> />

                   </p>
     
		   <p>
                        <label for="Modified_Nucleic_Acid_Yield_Nanograms">Modified Nucleic Acid Yield Nanograms</label>
                        <input type="text" size="30" maxlength="30" name="Modified_Nucleic_Acid_Yield_Nanograms" id="Modified_Nucleic_Acid_Yield_Nanograms" value=<?php $fourteen = substr($Modified_Nucleic_Acid_Yield_Nanograms, 0, 30);  echo "'$fourteen'";?> />
                   </p>     


 		<p>
 		<tr>
    		  <th><label for="Modified_Nucleic_Acid_QC_Result">QC Notes Modification</label></th>
    		  <td><textarea name="Modified_Nucleic_Acid_QC_Result" id="Modified_Nucleic_Acid_QC_Result" maxlength="5000"  wrap="hard" value= <?php  echo '<textarea>'.$Modified_Nucleic_Acid_QC_Result.'</textarea>'; ?>  </textarea></td>
  		</tr>
		</p>
  
		<p>
                       <select name=Suppression_Method>
                       <option VALUE=<?php $six2=substr($Suppression_Method,0,30); echo "'$six2'";?>>Supression Method: <?php echo $six2;  ?>
                       <option value="hydroxyapatite spin-column">hydroxyapatite spin-column</option>
                       <option value="capture">capture</option>
                       </select>
                </p> 

		<p>
                        <label for="Suppressed_By">Suppressed By</label>
                        <input type="text" size="30" maxlength="30" name="Suppressed_By" id="Suppressed_By" value=<?php $eighteen = substr($Suppressed_By, 0, 30);  echo "'$eighteen'";?> />
                </p>   

        	<p>
                        <label for="Date_Nucleic_Acid_Suppressed">Date Nucleic Acid Suppressed. Format (mm-dd-yyyy)</label>
                        <input type="text" size="10" maxlength="10" name="Date_Nucleic_Acid_Suppressed" id="Date_Nucleic_Acid_Suppressed" value=<?php if ($Date_Nucleic_Acid_Suppressed !='') echo $Date_Nucleic_Acid_Suppressed ; else echo "&nbsp;";    ?> />
                </p>                                                                                                         

                
		<p>
                        <label for="Suppressed_Nucleic_Acid_Yield_Nanograms">Suppressed Nucleic Acid Yield Nanograms</label>
                        <input type="text" size="10" maxlength="10" name="Suppressed_Nucleic_Acid_Yield_Nanograms" id="Suppressed_Nucleic_Acid_Yield_Nanograms" value=<?php $nineteen = substr($Suppressed_Nucleic_Acid_Yield_Nanograms, 0, 10);   if ($nineteen!=0.0) echo "'$nineteen'"; else echo 0.0;?> />
               </p>     


 		<p>
 		<tr>
      		<th><label for="Suppressed_Nucleic_Acid_QC_Result">QC Notes Suppression</label></th>
      		<td><textarea name="Suppressed_Nucleic_Acid_QC_Result" id="Suppressed_Nucleic_Acid_QC_Result" maxlength="5000"  wrap="hard" value= <?php  echo '<textarea>'.$Suppressed_Nucleic_Acid_QC_Result.'</textarea>'; ?>  </textarea></td>
    		</tr>
		</p>
   
		<p>
                        <label for="Library_Preparation_ID_req">Library Name</label>
                        <input type="text" size="30" maxlength="30" name="Library_Preparation_ID_req" id="Library_Preparation_ID_req" value=<?php $twentytwo = substr($Library_Preparation_ID_req, 0, 30);  echo "'$twentytwo'";?> />
                </p>     

		<p>
                       <select name=Library_Preparation_Method_req>
                       <option VALUE=<?php echo $Library_Preparation_Method_req; ?>>Library Preparation Method :<?php echo $Library_Preparation_Method_req; ?>
                       <option value="nuGEN">nuGEN</option>
                       <option value="Nextera">Nextera</option>
                       </select>
                </p>         
 
		<p>
                        <label for="Library_Prepared_By_req">Library Prepared By </label>
                        <input type="text" size="30" maxlength="30" name="Library_Prepared_By_req" id="Library_Prepared_By_req" value=<?php $twenty4 = substr($Library_Prepared_By_req, 0, 30);  echo "'$twenty4'";?> />
                </p>     

 		<p>
                        <label for="Date_Library_Prepared_req">Date Library Prepared . Format (mm-dd-yyyy)</label>
                        <input type="text" size="10" maxlength="10" name="Date_Library_Prepared_req" id="Date_Library_Prepared_req" value=<?php if ($Date_Library_Prepared_req !='') echo $Date_Library_Prepared_req ; else echo "&nbsp;";  ?> />
                </p>             

		<p>
                        <label for="Library_Nucleic_Acid_Input_Nanograms_req">Library Nucleic Acid Input Nanograms </label>
                        <input type="text" size="10" maxlength="10" name="Library_Nucleic_Acid_Input_Nanograms_req" id="Library_Nucleic_Acid_Input_Nanograms_req" value=<?php $twenty5 = substr($Library_Nucleic_Acid_Input_Nanograms_req, 0, 10);  if ($twenty5!=0.0) echo "'$twenty5'"; else echo 0.0;?> />

                </p>     

		<p>

                        <label for="Library_Prep_Final_Volume_Microliters_req">Library Prep Final Volume Microliters </label>
                        <input type="text" size="10" maxlength="10" name="Library_Prep_Final_Volume_Microliters_req" id="Library_Prep_Final_Volume_Microliters_req" value=<?php $twenty6 = substr($Library_Prep_Final_Volume_Microliters_req, 0, 10); if ($twenty6!=0.0) echo "'$twenty6'"; else echo 0.0;?> />
                </p>     

		<p>
                        <label for="Final_Library_Concentration_Nanograms_Microliter_req">Final Library Concentration Nanograms Microliter </label>
                        <input type="text" size="10" maxlength="10" name="Final_Library_Concentration_Nanograms_Microliter_req" id="Final_Library_Concentration_Nanograms_Microliter_req" value=<?php $twenty7 = substr($Final_Library_Concentration_Nanograms_Microliter_req, 0, 10); if ($twenty7!=0.0) echo "'$twenty7'"; else echo 0.0;?> />
                </p>     


 		<p>
 		<tr>
      		<th><label for="Library_Nucleic_Acid_QC_Result">QC Notes Library</label></th>
      		<td><textarea name="Library_Nucleic_Acid_QC_Result" id="Library_Nucleic_Acid_QC_Result" maxlength="5000"  wrap="hard" value= <?php  echo '<textarea>'.$Library_Nucleic_Acid_QC_Result.'</textarea>'; ?>  </textarea></td>
    		</tr>
		</p>
   
   

		<p>
                        <label for="Average_Insert_Size_basepairs">Average Insert Size basepairs</label>
                        <input type="text" size="10" maxlength="10" name="Average_Insert_Size_basepairs" id="Average_Insert_Size_basepairs" value=<?php $thirty = substr($Average_Insert_Size_basepairs, 0, 10);  if ($thirty!=0.0) echo "'$thirty'"; else echo 0.0;?> />

                </p>  

		<p>
                        <label for="Sequencing_Provider_req">Sequencing Provider </label>
                        <input type="text" size="30" maxlength="30" name="Sequencing_Provider_req" id="Sequencing_Provider_req" value=<?php $thirtyone = substr($Sequencing_Provider_req, 0, 30);  echo "'$thirtyone'";?> />
  
               </p>     

                     <p>
                      <label for="Date_at_Sequencing_Provider_req">Date at Sequencing Provider. Format (mm-dd-yyyy)</label>
                      <input type="text" size="10" maxlength="10" name="Date_at_Sequencing_Provider_req" id="Date_at_Sequencing_Provider_req" value=<?php  if ($Date_at_Sequencing_Provider_req !='') echo $Date_at_Sequencing_Provider_req ; else echo "&nbsp;";  ?> />
                     </p>               


                    <p>
                        <label for="Sent_By_req">Sent By </label>
                        <input type="text" size="30" maxlength="30" name="Sent_By_req" id="Sent_By_req" value=<?php $thirtytwo = substr($Sent_By_req, 0, 30);  echo "'$thirtytwo'";?> />
                   </p>     


                    <p>
                        <label for="Experimentalist_Informatician_notes_upload">Upload notes: </label>
                        <input type="file" accept="text/txt" name="Experimentalist_Informatician_notes_upload" id="Experimentalist_Informatician_notes_upload" value= <?php $twenty=substr($Experimentalists_notes_upload,0,200); echo "'$twenty'"; ?>/>    
                   </p>    

		   <p>
                       <input type="hidden" name="testStore" value=<?php echo $testStg ;?> />     
                   </p>

                   <p class="submit"><button type="submit">Add Sample</button></p>         
                   <input type="hidden" name="submit" value="1"/>

              </fieldset>                         
         </form>     
</div>
</body>

</html>


<?php

function change_date_format($data){

       list($year,$month,$day) = explode("-",$data);
       $newdata = $month."-".$day."-".$year;
       return $newdata;
}
?>
