#!/bin/bash

#Copyright 2012, Martha Perez Arriaga and Amy J. Powell.  This program, OMICS METADATA MANAGEMENT SOFTWARE (OMMS), is distributed under the terms of the GNU General Public License.

#This file, uninstaller.sh, is part of the OMMS.

#The OMMS is free software:  you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

#The OMMS is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

#You should have received a copy of the GNU General Public License along with the OMMS. If not, see <http://www.gnu.org/licenses/>.


#uninstall OMMS
echo "_________________________________________"
echo ""
echo Uninstalling OMMS ...
echo "_________________________________________"
echo ""


echo ""
echo ""
        while read dir1; do  
          if [ -d "$dir1" ] 
            then
            echo This program will remove $dir1 and contents 
            else
            echo $dir1 does not exist 
          fi
        done < uninstallOMMS.txt 
echo ""
echo ""

echo "Press <enter> to unistall the OMMS."
read -n1 key1
if [[ $key1 = "" ]]; then 
 	while read dir1; do    
              if [ -d "$dir1" ] 
                then
        	 echo $dir1  
 		  echo "Erasing $dir1 and contents."
        	  rm -rf $dir1
              else
               echo "$dir1 does not exist"
              fi
 	done < uninstallOMMS.txt 
else
echo "Leaving OMMS uninstallation. Nothing done."
exit
fi
